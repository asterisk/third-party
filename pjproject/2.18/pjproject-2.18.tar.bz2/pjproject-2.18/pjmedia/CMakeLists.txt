list(APPEND CMAKE_MESSAGE_CONTEXT "pjmedia")

# ##############################################################################
# Module options

include(Pj/Option)
include(CMakeDependentOption)

#
# General features
#

# Include sRTP (Secure Real-time Transport Protocol)
cmake_dependent_option(PJMEDIA_WITH_SRTP
  "Enable SRTP support" ON
  "TARGET Pj::Dep::SRTP" OFF
)

# Include resampling implementation
# Undo a value an earlier configure forced: libsamplerate if that was asked
# for (it now stops below when unusable), else the default. A value set
# since is kept.
get_property(_pj_doc CACHE PJMEDIA_WITH_RESAMPLE PROPERTY HELPSTRING)
if(_pj_doc MATCHES "\\(forced\\)$")
  set(_pj_value "$CACHE{PJMEDIA_WITH_RESAMPLE}")
  if(_pj_value STREQUAL "none")
    set(_pj_value "")
    if("$CACHE{_PJ_PJMEDIA_WITH_RESAMPLE_UNFORCED}" STREQUAL "libsamplerate")
      set(_pj_value libsamplerate)
    endif()
  endif()
  if(_pj_value)
    set_property(CACHE PJMEDIA_WITH_RESAMPLE PROPERTY VALUE ${_pj_value})
    string(REGEX REPLACE " ?\\(forced\\)$" "" _pj_doc "${_pj_doc}")
    set_property(CACHE PJMEDIA_WITH_RESAMPLE PROPERTY HELPSTRING "${_pj_doc}")
  else()
    unset(PJMEDIA_WITH_RESAMPLE CACHE)
  endif()
  unset(_PJ_PJMEDIA_WITH_RESAMPLE_UNFORCED CACHE)
  unset(_pj_value)
endif()
unset(_pj_doc)
pj_option(PJMEDIA_WITH_RESAMPLE "Enable resampling implementation"
  REQUIRED
  DEFAULT libresample
  ALLOWED_VALUES none libresample libsamplerate speex
)

# The resampler searches without pj_find_optional(), and before the Speex
# AEC's search for SpeexDSP, so a changed root is followed from here
pj_retry_on_new_root(PJMEDIA_WITH_RESAMPLE SampleRate)
pj_retry_on_new_root(PJMEDIA_WITH_SPEEX_AEC SpeexDSP)

if(PJMEDIA_WITH_RESAMPLE STREQUAL "libresample")
  if(NOT TARGET Pj::Dep::Resample)
    pj_force_set(PJMEDIA_WITH_RESAMPLE "none" "libresample not found")
  endif()
elseif(PJMEDIA_WITH_RESAMPLE STREQUAL "libsamplerate")
  find_package(SampleRate ${PJ_FIND_QUIET})
  if(NOT SampleRate_FOUND)
    message(FATAL_ERROR "PJMEDIA_WITH_RESAMPLE=libsamplerate cannot be used: "
      "libsamplerate not found or cannot be linked. Set "
      "PJMEDIA_WITH_RESAMPLE to libresample, speex or none.")
  endif()
elseif(PJMEDIA_WITH_RESAMPLE STREQUAL "speex")
  if(NOT TARGET Pj::Dep::Speex)
    message(FATAL_ERROR "Resampling backend cannot be set to `speex`, \
                         because Speex is not available")
  endif()
  # Modern speex (1.2+) ships the resampler in libspeexdsp, separate from
  # libspeex. When using system speex we therefore also need SpeexDSP.
  # The bundled speex keeps the resampler in-tree so nothing extra is
  # required there.
  get_target_property(_pj_speex_provider Pj::Dep::Speex PJ_DEP_PROVIDER)
  if(_pj_speex_provider STREQUAL "system")
    find_package(SpeexDSP REQUIRED)
    set(_pj_resample_speex_needs_speexdsp TRUE)
  endif()
  unset(_pj_speex_provider)
endif()

#
# Acoustic Echo Cancellation (AEC)
#

# Speex Acoustic Echo Cancellation (AEC)
# older versions forced this off when libspeexdsp was missing
get_property(_pj_doc CACHE PJMEDIA_WITH_SPEEX_AEC PROPERTY HELPSTRING)
if(_pj_doc MATCHES "\\(forced\\)$")
  unset(PJMEDIA_WITH_SPEEX_AEC CACHE)
endif()
unset(_pj_doc)
# Off by default on iOS, as in PJ_CONFIG_IPHONE: CoreAudio cancels echo itself
if(IOS)
  set(_pj_speex_aec_default OFF)
else()
  set(_pj_speex_aec_default ON)
endif()
cmake_dependent_option(PJMEDIA_WITH_SPEEX_AEC
  "Enable Speex Acoustic Echo Cancellation (AEC) support"
  ${_pj_speex_aec_default}
  "TARGET Pj::Dep::Speex" OFF
)
unset(_pj_speex_aec_default)
# As with the resampler, only system speex needs SpeexDSP for the AEC
if(PJMEDIA_WITH_SPEEX_AEC)
  get_target_property(_pj_speex_provider Pj::Dep::Speex PJ_DEP_PROVIDER)
  if(_pj_speex_provider STREQUAL "system")
    pj_find_optional(PJMEDIA_WITH_SPEEX_AEC OFF SpeexDSP)
    set(_pj_speex_aec_needs_speexdsp ${PJMEDIA_WITH_SPEEX_AEC})
  endif()
  unset(_pj_speex_provider)
endif()

# tells PjConfig.cmake whether consumers need SpeexDSP
if(_pj_resample_speex_needs_speexdsp OR _pj_speex_aec_needs_speexdsp)
  set(PJMEDIA_NEEDS_SPEEXDSP TRUE PARENT_SCOPE)
else()
  set(PJMEDIA_NEEDS_SPEEXDSP FALSE PARENT_SCOPE)
endif()

# WebRTC Acoustic Echo Cancellation (AEC)
cmake_dependent_option(PJMEDIA_WITH_WEBRTC_AEC
  "Enable WebRTC Acoustic Echo Cancellation (AEC) support" ON
  "TARGET Pj::Dep::WebRTC" OFF
)

# PJMEDIA_WITH_WEBRTC_AEC3 is declared in third_party/CMakeLists.txt, which
# imports the library only when it is ON. Keep the option visible when its
# provider is none or C++ is off. third_party already said why when it left
# the library out.
if(NOT TARGET Pj::Dep::WebRTC_AEC3)
  get_property(_pj_aec3_left_out GLOBAL PROPERTY PJ_WEBRTC_AEC3_LEFT_OUT)
  if(PJMEDIA_WITH_WEBRTC_AEC3 AND NOT _pj_aec3_left_out)
    message(STATUS
      "[!] WebRTC AEC3 needs PJ_WITH_CXX and a provider. leaving it out")
  endif()
  unset(_pj_aec3_left_out)
  set(PJMEDIA_WITH_WEBRTC_AEC3 OFF)
endif()

#
# Video support
#

# The default for PJMEDIA_HAS_VIDEO, which config_site.h can override
option(PJMEDIA_WITH_VIDEO "Enable video support" ON)

# libyuv
cmake_dependent_option(PJMEDIA_WITH_LIBYUV
  "Enable libyuv support" ON
  "PJMEDIA_WITH_VIDEO;TARGET Pj::Dep::YUV" OFF
)

# ffmpeg
cmake_dependent_option(PJMEDIA_WITH_FFMPEG
  "Enable FFMPEG support" ON
  "PJMEDIA_WITH_VIDEO" OFF
)

set(ffmpeg_libs_required avutil)
set(ffmpeg_libs_optional swscale avcodec avformat avdevice)

pj_find_optional(PJMEDIA_WITH_FFMPEG OFF
  FFMPEG
    COMPONENTS ${ffmpeg_libs_required}
    OPTIONAL_COMPONENTS ${ffmpeg_libs_optional}
)

foreach(lib IN LISTS ffmpeg_libs_required ffmpeg_libs_optional)
  string(TOUPPER "${lib}" lib_upper)
  set(lib_option PJMEDIA_WITH_FFMPEG_${lib_upper})

  cmake_dependent_option(${lib_option}
    "Enable FFMPEG `${lib}` component" ON
    "PJMEDIA_WITH_FFMPEG;TARGET FFMPEG::${lib}" OFF
  )
endforeach()

#
# Codecs
#

# G.711 PCMA/PCMU codecs
option(PJMEDIA_WITH_G711_CODEC "Enable G.711 codec" ON)

# Linear/L16 codec family, off by default on iOS as in PJ_CONFIG_IPHONE
if(IOS)
  option(PJMEDIA_WITH_L16_CODEC "Enable L16 codec family" OFF)
else()
  option(PJMEDIA_WITH_L16_CODEC "Enable L16 codec family" ON)
endif()

# GSM codec
cmake_dependent_option(PJMEDIA_WITH_GSM_CODEC
  "Enable GSM codec" ON
  "TARGET Pj::Dep::GSM" OFF
)

# Speex codec
cmake_dependent_option(PJMEDIA_WITH_SPEEX_CODEC
  "Enable Speex codecs" ON
  "TARGET Pj::Dep::Speex" OFF
)

# iLBC codec
cmake_dependent_option(PJMEDIA_WITH_ILBC_CODEC
  "Enable iLBC codec" ON
  "TARGET Pj::Dep::iLBC" OFF
)

# G.722 codec
option(PJMEDIA_WITH_G722_CODEC "Enable G.722 codec" ON)

# G.722.1 codec: off by default, as with autoconf, for licensing reasons (the
# user must obtain a license from Poly). It is enabled with this option or, as
# documented, with PJMEDIA_HAS_G7221_CODEC in config_site.h, which is checked on
# every configure and must also get the library linked.
cmake_dependent_option(PJMEDIA_WITH_G7221_CODEC
  "Enable G.722.1 codec (licensed by Poly)" OFF
  "TARGET Pj::Dep::G7221" OFF
)
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS
  "${PROJECT_SOURCE_DIR}/pjlib/include/pj/config_site.h"
)
block(SCOPE_FOR VARIABLES PROPAGATE _pj_link_g7221)
  include(CheckSourceCompiles)
  set(CMAKE_REQUIRED_INCLUDES "${PROJECT_SOURCE_DIR}/pjlib/include")
  set(CMAKE_REQUIRED_DEFINITIONS -DPJ_AUTOCONF=1)
  set(CMAKE_REQUIRED_QUIET ON)
  unset(PJ_CONFIG_SITE_HAS_G7221 CACHE)
  check_source_compiles(C [[
#include <pj/config_site.h>
#if !defined(PJMEDIA_HAS_G7221_CODEC) || !PJMEDIA_HAS_G7221_CODEC
#  error G.722.1 not enabled
#endif
int main(void) { return 0; }
]] PJ_CONFIG_SITE_HAS_G7221)

  set(_pj_link_g7221 ${PJMEDIA_WITH_G7221_CODEC})
  if(PJ_CONFIG_SITE_HAS_G7221)
    if(TARGET Pj::Dep::G7221)
      message(STATUS "G.722.1 codec enabled by config_site.h")
      set(_pj_link_g7221 ON)
    else()
      message(SEND_ERROR
        "config_site.h enables G.722.1 (PJMEDIA_HAS_G7221_CODEC) but there "
        "is no G.722.1 library: PJ_DEP_G7221=${PJ_DEP_G7221}"
      )
    endif()
  endif()
endblock()
# a provider alone does not enable it
if(NOT _pj_link_g7221)
  pj_dep_fail_if_asked(PJ_DEP_G7221 "" "bundled"
    "G.722.1 is off; enable it with -DPJMEDIA_WITH_G7221_CODEC=ON or "
    "PJMEDIA_HAS_G7221_CODEC in config_site.h")
endif()

# OpenCore AMR-NB Codecs
option(PJMEDIA_WITH_OPENCORE_AMRNB_CODEC "Enable OpenCore AMR-NB codec" ON)
pj_find_optional(PJMEDIA_WITH_OPENCORE_AMRNB_CODEC OFF OpenCoreAMRNB)

# OpenCore AMR-WB Codecs
option(PJMEDIA_WITH_OPENCORE_AMRWB_CODEC "Enable OpenCore AMR-WB codec" ON)
# Re-enabling the option must also re-import OpenCoreAMRWB
pj_retry_on_new_root(PJMEDIA_WITH_OPENCORE_AMRWB_CODEC VisualOnAMRWBEnc)
pj_find_optional(PJMEDIA_WITH_OPENCORE_AMRWB_CODEC OFF OpenCoreAMRWB)
pj_find_optional(PJMEDIA_WITH_OPENCORE_AMRWB_CODEC OFF VisualOnAMRWBEnc)

# Silk codec
option(PJMEDIA_WITH_SILK_CODEC "Enable Skype Silk" ON)
pj_find_optional(PJMEDIA_WITH_SILK_CODEC OFF Silk)

# OPUS codec
option(PJMEDIA_WITH_OPUS_CODEC "Enable OPUS codec" ON)
pj_find_optional(PJMEDIA_WITH_OPUS_CODEC OFF OPUS)

# BCG729 codec
option(PJMEDIA_WITH_BCG729_CODEC "Enable BCG729 codec" ON)
pj_find_optional(PJMEDIA_WITH_BCG729_CODEC OFF BCG729)

# Intel IPP codecs, as autoconf --enable-ipp: this only links IPP and its
# speech codec samples, the codecs are enabled with PJMEDIA_HAS_INTEL_IPP in
# config_site.h. See cmake/FindIPP.cmake for where to point the build.
option(PJMEDIA_WITH_INTEL_IPP "Link the Intel IPP codec libraries" OFF)
pj_retry_on_new_root(PJMEDIA_WITH_INTEL_IPP IPP_SAMPLES)
pj_find_optional(PJMEDIA_WITH_INTEL_IPP OFF IPP)

# Lyra codec
cmake_dependent_option(PJMEDIA_WITH_LYRA_CODEC
  "Enable Lyra codec" ON
  "PJ_WITH_CXX" OFF
)
pj_find_optional(PJMEDIA_WITH_LYRA_CODEC OFF Lyra)

# Android MediaCodec codecs
cmake_dependent_option(PJMEDIA_WITH_ANDROID_MEDIACODEC_CODEC
  "Enable Android MediaCodec codecs" ON
  "ANDROID;PJ_WITH_CXX" OFF
)
pj_find_optional(PJMEDIA_WITH_ANDROID_MEDIACODEC_CODEC OFF MediaNDK)

# Google VP8/VP9 codecs
cmake_dependent_option(PJMEDIA_WITH_VPX_CODEC
  "Enable VPX codecs support" ON
  "PJMEDIA_WITH_VIDEO" OFF
)
pj_find_optional(PJMEDIA_WITH_VPX_CODEC OFF VPX)

# VideoToolbox H.264 codec
cmake_dependent_option(PJMEDIA_WITH_VID_TOOLBOX_CODEC
  "Enable VideoToolbox H.264 codec" ON
  "PJMEDIA_WITH_VIDEO;APPLE" OFF
)
pj_find_optional(PJMEDIA_WITH_VID_TOOLBOX_CODEC OFF VideoToolbox)

# OpenH264 codecs
cmake_dependent_option(PJMEDIA_WITH_OPEN_H264_CODEC
  "Enable OpenH264 codecs support" ON
  "PJMEDIA_WITH_VIDEO;PJ_WITH_CXX" OFF
)
pj_find_optional(PJMEDIA_WITH_OPEN_H264_CODEC OFF OpenH264)

#
# Audio device
#

option(PJMEDIA_WITH_AUDIODEV "Enable audio device support" ON)

# NULL audio backend, off by default as in pjmedia-audiodev/config.h
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_NULL
  "Enable NULL audio device backend" OFF
  "PJMEDIA_WITH_AUDIODEV" OFF
)

# Android Java Native Interface backend
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_JNI
  "Enable JNI audio device backend" ON
  "PJMEDIA_WITH_AUDIODEV;ANDROID" OFF
)

# Android OpenSL ES backend, off by default as in pjmedia-audiodev/config.h
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_OPENSL
  "Enable OpenSL ES audio device backend" OFF
  "PJMEDIA_WITH_AUDIODEV;ANDROID" OFF
)

# Android OBOE backend. Oboe is not bundled; see cmake/FindOboe.cmake for
# where to point the build at an SDK.
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_OBOE
  "Enable OBOE audio device backend" ON
  "PJMEDIA_WITH_AUDIODEV;ANDROID;PJ_WITH_CXX" OFF
)
pj_find_optional(PJMEDIA_WITH_AUDIODEV_OBOE OFF Oboe)

# The backend uses Oboe's C++ API. The NDK supports a static C++ runtime only
# in an app's single C++ shared library, so a shared liboboe.so (the published
# AAR's, which needs libc++_shared.so) cannot go with one.
if(PJMEDIA_WITH_AUDIODEV_OBOE AND Oboe_LIBRARY MATCHES "\\.so$"
   AND CMAKE_ANDROID_STL_TYPE STREQUAL "c++_static")
  message(FATAL_ERROR
    "Oboe (${Oboe_LIBRARY}) is a shared library, which cannot be used with "
    "the static C++ runtime (ANDROID_STL=c++_static). Use the default "
    "c++_shared, a static Oboe built from source as "
    "build/android/build-aar.sh does, or -DPJMEDIA_WITH_AUDIODEV_OBOE=OFF.")
endif()

# macOS/iOS CoreAudio backend
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_COREAUDIO
  "Enable CoreAudio audio device backend" ON
  "PJMEDIA_WITH_AUDIODEV;APPLE" OFF
)
pj_find_optional(PJMEDIA_WITH_AUDIODEV_COREAUDIO OFF CoreAudio)

# Advanced Linux Sound Architecture (ALSA) backend, looked for on any Unix
# without a native backend, as autoconf
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_ALSA
  "Enable ALSA audio device backend" ON
  "PJMEDIA_WITH_AUDIODEV;UNIX;NOT APPLE;NOT ANDROID;NOT CYGWIN" OFF
)
# CMake's FindALSA has no link test of its own
pj_find_optional(PJMEDIA_WITH_AUDIODEV_ALSA OFF ALSA LINK_FUNCTION snd_pcm_open)

# Windows MultiMedia Extensions (WMME) backend
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_WMME
  "Enable WMME audio device backend" ON
  "PJMEDIA_WITH_AUDIODEV;WIN32 OR CYGWIN OR MINGW" OFF
)

# Windows Audio Session API (WASAPI) backend, off by default: on Windows
# desktop WMME is the default and WASAPI is opt-in, see
# PJMEDIA_AUDIO_DEV_HAS_WASAPI in pjmedia-audiodev/config.h.
#
# This stays off for a WindowsStore build too, even though CMake's WIN32 is
# true there. The UWP backend is wasapi_dev.cpp, which is guarded on
# PJ_WIN32_UWP, and nothing in this build system ever defines it: pjlib/
# CMakeLists.txt sets PJ_WIN32 alone and pj/config.h only takes its UWP
# branch when PJ_WIN32_UWP or _WIN32_UWP is defined for it. Turning WASAPI on
# here would therefore select the desktop backend for a Store target. UWP is
# built from the MSVC projects, which do define it.
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_WASAPI
  "Enable WASAPI audio device backend" OFF
  "PJMEDIA_WITH_AUDIODEV;WIN32 OR CYGWIN OR MINGW;PJ_WITH_CXX" OFF
)
pj_find_optional(PJMEDIA_WITH_AUDIODEV_WASAPI OFF WASAPI)

# PortAudio backend, opt-in as autoconf --with-external-pa
cmake_dependent_option(PJMEDIA_WITH_AUDIODEV_PORTAUDIO
  "Enable PortAudio audio device backend" OFF
  "PJMEDIA_WITH_AUDIODEV" OFF
)
pj_find_optional(PJMEDIA_WITH_AUDIODEV_PORTAUDIO OFF PortAudio)

#
# Video device
#

cmake_dependent_option(PJMEDIA_WITH_VIDEODEV
  "Enable video device support" ON
  "PJMEDIA_WITH_VIDEO" OFF
)

# AVI backend
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_AVI
  "Enable AVI video device backend" ON
  "PJMEDIA_WITH_VIDEODEV" OFF
)

# OpenGL backend
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_OPENGL
  "Enable OpenGL video device backend" ON
  "PJMEDIA_WITH_VIDEODEV;ANDROID OR IOS" OFF
)
# The two platforms that have this backend are also the two FindOpenGL cannot
# serve: on iOS the ES implementation is OpenGLES.framework rather than the GL
# and GLES2 libraries it looks for, and on Android it finds no GL library to
# pair with GLES2. Either way the probe fails and the renderer would be
# silently dropped.
#
# PJ_OPENGL_PACKAGE records which one was used. The top-level directory reads
# it to install the matching Find module, and PjConfig.cmake.in to re-resolve
# the same package in an installed tree, so it has to be in the cache to be
# visible outside this directory.
if(IOS OR ANDROID)
  set(PJ_OPENGL_PACKAGE OpenGLES CACHE INTERNAL "OpenGL package to find")
  pj_find_optional(PJMEDIA_WITH_VIDEODEV_OPENGL OFF OpenGLES)
else()
  set(PJ_OPENGL_PACKAGE OpenGL CACHE INTERNAL "OpenGL package to find")
  pj_find_optional(PJMEDIA_WITH_VIDEODEV_OPENGL OFF OpenGL COMPONENTS GLES2)
endif()

if(PJ_OPENGL_PACKAGE STREQUAL OpenGLES)
  set(PJ_OPENGL_LINK_TARGETS OpenGLES::OpenGLES)
else()
  set(PJ_OPENGL_LINK_TARGETS OpenGL::GL OpenGL::GLES2)
endif()

# Android camera capture backend
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_ANDROID
  "Enable Android camera video device backend" ON
  "PJMEDIA_WITH_VIDEODEV;ANDROID" OFF
)

# FFMPEG backend
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_FFMPEG
  "Enable FFMPEG video device backend" ON
  "PJMEDIA_WITH_VIDEODEV;PJMEDIA_WITH_FFMPEG_AVDEVICE" OFF
)

# SDL backend
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_SDL
  "Enable SDL video device backend" ON
  "PJMEDIA_WITH_VIDEODEV" OFF
)
# SDL's own package does no link test; reject a library built for another
# target, e.g. the host's in a cross build
pj_find_optional(PJMEDIA_WITH_VIDEODEV_SDL OFF SDL2 QUIET
  LINK_FUNCTION SDL_Init LINK_LIBRARIES SDL2::SDL2)

# Darwin (AVFoundation) capture backend
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_DARWIN
  "Enable AVFoundation video capture backend" ON
  "PJMEDIA_WITH_VIDEODEV;APPLE" OFF
)
pj_find_optional(PJMEDIA_WITH_VIDEODEV_DARWIN OFF AVFoundation)

# Metal backend, used whenever the frameworks are found, as autoconf
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_METAL
  "Enable Metal video device backend" ON
  "PJMEDIA_WITH_VIDEODEV;APPLE" OFF
)
pj_find_optional(PJMEDIA_WITH_VIDEODEV_METAL OFF Metal)

# QT backend
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_QT
  "Enable QT video device backend" OFF
  "PJMEDIA_WITH_VIDEODEV;APPLE" OFF
)

# V4L2 backend, also available on the BSDs through libv4l2
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_V4L2
  "Enable V4L2 video device backend" ON
  "PJMEDIA_WITH_VIDEODEV;UNIX;NOT APPLE;NOT ANDROID" OFF
)
pj_find_optional(PJMEDIA_WITH_VIDEODEV_V4L2 OFF V4L2)

# DirectShow backend, the Windows camera capture: on by default on Windows, as
# autoconf does for MinGW with video
if(WIN32)
  set(_pj_dshow_default ON)
else()
  set(_pj_dshow_default OFF)
endif()
cmake_dependent_option(PJMEDIA_WITH_VIDEODEV_DSHOW
  "Enable DirectShow video device backend" ${_pj_dshow_default}
  "PJMEDIA_WITH_VIDEODEV;WIN32 OR CYGWIN OR MINGW;PJ_WITH_CXX" OFF
)
unset(_pj_dshow_default)

# The top-level directory writes these into PjConfig.cmake. An option whose
# cmake_dependent_option() condition turned false on a reconfigure is OFF in
# this directory only, while its cache entry keeps the earlier value.
get_cmake_property(_pj_vars VARIABLES)
foreach(_var IN LISTS _pj_vars)
  if(_var MATCHES "^PJMEDIA_WITH_")
    set(${_var} "${${_var}}" PARENT_SCOPE)
  endif()
endforeach()
unset(_pj_vars)

# ##############################################################################
# pjmedia

add_library(pjmedia
  src/pjmedia/ai_port.c
  src/pjmedia/ai_port_openai.c
  src/pjmedia/alaw_ulaw.c
  src/pjmedia/alaw_ulaw_table.c
  src/pjmedia/avi_player.c
  src/pjmedia/avi_writer.c
  src/pjmedia/av_sync.c
  src/pjmedia/bidirectional.c
  src/pjmedia/clock_thread.c
  src/pjmedia/codec.c
  src/pjmedia/conference.c
  src/pjmedia/conf_thread.c
  src/pjmedia/conf_switch.c
  src/pjmedia/converter.c
  src/pjmedia/converter_libswscale.c
  src/pjmedia/converter_libyuv.c
  src/pjmedia/delaybuf.c
  src/pjmedia/echo_common.c
  src/pjmedia/echo_port.c
  src/pjmedia/echo_speex.c
  src/pjmedia/echo_suppress.c
  src/pjmedia/echo_webrtc.c
  $<$<BOOL:${PJ_WITH_CXX}>:src/pjmedia/echo_webrtc_aec3.cpp>
  src/pjmedia/endpoint.c
  src/pjmedia/errno.c
  src/pjmedia/event.c
  src/pjmedia/format.c
  src/pjmedia/ffmpeg_util.c
  src/pjmedia/g711.c
  src/pjmedia/jbuf.c
  src/pjmedia/master_port.c
  src/pjmedia/mem_capture.c
  src/pjmedia/mem_player.c
  src/pjmedia/null_port.c
  src/pjmedia/plc_common.c
  src/pjmedia/port.c
  src/pjmedia/splitcomb.c
  src/pjmedia/resample_resample.c
  src/pjmedia/resample_libsamplerate.c
  src/pjmedia/resample_speex.c
  src/pjmedia/resample_port.c
  src/pjmedia/rtcp.c
  src/pjmedia/rtcp_xr.c
  src/pjmedia/rtcp_fb.c
  src/pjmedia/rtp.c
  src/pjmedia/sdp.c
  src/pjmedia/sdp_cmp.c
  src/pjmedia/sdp_neg.c
  src/pjmedia/session.c
  src/pjmedia/silencedet.c
  src/pjmedia/sound_legacy.c
  src/pjmedia/sound_port.c
  src/pjmedia/stereo_port.c
  src/pjmedia/stream_common.c
  src/pjmedia/stream.c
  src/pjmedia/stream_info.c
  src/pjmedia/tonegen.c
  src/pjmedia/transport_adapter_sample.c
  src/pjmedia/transport_ice.c
  src/pjmedia/transport_loop.c
  src/pjmedia/transport_srtp.c
  src/pjmedia/transport_udp.c
  src/pjmedia/types.c
  src/pjmedia/txt_stream.c
  src/pjmedia/vid_codec.c
  src/pjmedia/vid_codec_util.c
  src/pjmedia/vid_port.c
  src/pjmedia/vid_stream.c
  src/pjmedia/vid_stream_info.c
  src/pjmedia/vid_conf.c
  src/pjmedia/wav_player.c
  src/pjmedia/wav_playlist.c
  src/pjmedia/wav_writer.c
  src/pjmedia/tone_detector.c
  src/pjmedia/wave.c
  src/pjmedia/wsola.c
  src/pjmedia/audiodev.c
  src/pjmedia/videodev.c
)

# headers
target_sources(pjmedia
  PUBLIC
    FILE_SET HEADERS
    BASE_DIRS
      include
    FILES
      include/pjmedia.h
      include/pjmedia/ai_port.h
      include/pjmedia/alaw_ulaw.h
      include/pjmedia/audiodev.h
      include/pjmedia/av_sync.h
      include/pjmedia/avi.h
      include/pjmedia/avi_stream.h
      include/pjmedia/bidirectional.h
      include/pjmedia/circbuf.h
      include/pjmedia/clock.h
      include/pjmedia/codec.h
      include/pjmedia/conference.h
      include/pjmedia/config.h
      include/pjmedia/converter.h
      include/pjmedia/delaybuf.h
      include/pjmedia/doxygen.h
      include/pjmedia/echo.h
      include/pjmedia/echo_port.h
      include/pjmedia/endpoint.h
      include/pjmedia/errno.h
      include/pjmedia/event.h
      include/pjmedia/format.h
      include/pjmedia/frame.h
      include/pjmedia/g711.h
      include/pjmedia/jbuf.h
      include/pjmedia/master_port.h
      include/pjmedia/mem_port.h
      include/pjmedia/null_port.h
      include/pjmedia/plc.h
      include/pjmedia/port.h
      include/pjmedia/resample.h
      include/pjmedia/rtcp.h
      include/pjmedia/rtcp_fb.h
      include/pjmedia/rtcp_xr.h
      include/pjmedia/rtp.h
      include/pjmedia/sdp.h
      include/pjmedia/sdp_neg.h
      include/pjmedia/session.h
      include/pjmedia/signatures.h
      include/pjmedia/silencedet.h
      include/pjmedia/sound.h
      include/pjmedia/sound_port.h
      include/pjmedia/splitcomb.h
      include/pjmedia/stereo.h
      include/pjmedia/stream.h
      include/pjmedia/stream_common.h
      include/pjmedia/symbian_sound_aps.h
      include/pjmedia/tonegen.h
      include/pjmedia/transport.h
      include/pjmedia/transport_adapter_sample.h
      include/pjmedia/transport_ice.h
      include/pjmedia/transport_loop.h
      include/pjmedia/transport_srtp.h
      include/pjmedia/transport_udp.h
      include/pjmedia/txt_stream.h
      include/pjmedia/types.h
      include/pjmedia/vid_codec.h
      include/pjmedia/vid_codec_util.h
      include/pjmedia/vid_conf.h
      include/pjmedia/vid_port.h
      include/pjmedia/vid_stream.h
      include/pjmedia/vid_tee.h
      include/pjmedia/videodev.h
      include/pjmedia/tone_detector.h
      include/pjmedia/wav_playlist.h
      include/pjmedia/wav_port.h
      include/pjmedia/wave.h
      include/pjmedia/wsola.h
)

#
# pjmedia - configuration
#

# compile definitions
# Only what autoconf always passes on the command line too; SRTP, the Speex
# AEC and FFmpeg are written into pjmedia/config_auto.h, see below
target_compile_definitions(pjmedia
  PUBLIC
    # resampling backend
    PJMEDIA_RESAMPLE_IMP=PJMEDIA_RESAMPLE_$<UPPER_CASE:${PJMEDIA_WITH_RESAMPLE}>

    # aec
    PJMEDIA_HAS_WEBRTC_AEC=$<BOOL:${PJMEDIA_WITH_WEBRTC_AEC}>
    PJMEDIA_HAS_WEBRTC_AEC3=$<BOOL:${PJMEDIA_WITH_WEBRTC_AEC3}>

    # video
    PJMEDIA_HAS_LIBYUV=$<BOOL:${PJMEDIA_WITH_LIBYUV}>
)

# external srtp values
if(PJMEDIA_WITH_SRTP)
  get_target_property(srtp_provider Pj::Dep::SRTP PJ_DEP_PROVIDER)
  if(srtp_provider STREQUAL "system")
    get_target_property(srtp_version_major Pj::Dep::SRTP SRTP_VERSION_MAJOR)
    get_target_property(srtp_has_deinit Pj::Dep::SRTP SRTP_HAS_DEINIT)
    get_target_property(srtp_has_shutdown Pj::Dep::SRTP SRTP_HAS_SHUTDOWN)

    target_compile_definitions(pjmedia
      PRIVATE
        PJMEDIA_EXTERNAL_SRTP=${srtp_version_major}
        PJMEDIA_SRTP_HAS_DEINIT=${srtp_has_deinit}
        PJMEDIA_SRTP_HAS_SHUTDOWN=${srtp_has_shutdown}
    )
  endif()
endif()

# definitions header
block(SCOPE_FOR VARIABLES)
  # G711 codec
  set(PJMEDIA_HAS_G711_CODEC ${PJMEDIA_WITH_G711_CODEC})

  # srtp
  set(PJMEDIA_HAS_SRTP ${PJMEDIA_WITH_SRTP})

  # aec
  set(PJMEDIA_HAS_SPEEX_AEC ${PJMEDIA_WITH_SPEEX_AEC})

  # video
  set(PJMEDIA_HAS_VIDEO ${PJMEDIA_WITH_VIDEO})
  set(PJMEDIA_HAS_FFMPEG ${PJMEDIA_WITH_FFMPEG})
  set(PJMEDIA_HAS_LIBAVUTIL ${PJMEDIA_WITH_FFMPEG_AVUTIL})
  set(PJMEDIA_HAS_LIBSWSCALE ${PJMEDIA_WITH_FFMPEG_SWSCALE})
  set(PJMEDIA_HAS_LIBAVCODEC ${PJMEDIA_WITH_FFMPEG_AVCODEC})
  set(PJMEDIA_HAS_LIBAVFORMAT ${PJMEDIA_WITH_FFMPEG_AVFORMAT})
  set(PJMEDIA_HAS_LIBAVDEVICE ${PJMEDIA_WITH_FFMPEG_AVDEVICE})

  # audio device backends, read by pjmedia-audiodev/config.h; the null
  # device also changes what RTCP-XR reports (rtcp_xr.c)
  set(PJMEDIA_AUDIO_DEV_HAS_NULL_AUDIO ${PJMEDIA_WITH_AUDIODEV_NULL})
  set(PJMEDIA_AUDIO_DEV_HAS_ANDROID_JNI ${PJMEDIA_WITH_AUDIODEV_JNI})
  set(PJMEDIA_AUDIO_DEV_HAS_OPENSL ${PJMEDIA_WITH_AUDIODEV_OPENSL})
  set(PJMEDIA_AUDIO_DEV_HAS_OBOE ${PJMEDIA_WITH_AUDIODEV_OBOE})
  set(PJMEDIA_AUDIO_DEV_HAS_COREAUDIO ${PJMEDIA_WITH_AUDIODEV_COREAUDIO})
  set(PJMEDIA_AUDIO_DEV_HAS_ALSA ${PJMEDIA_WITH_AUDIODEV_ALSA})
  set(PJMEDIA_AUDIO_DEV_HAS_WASAPI ${PJMEDIA_WITH_AUDIODEV_WASAPI})

  # video device backends, read by pjmedia-videodev/config.h
  set(PJMEDIA_VIDEO_DEV_HAS_AVI ${PJMEDIA_WITH_VIDEODEV_AVI})
  set(PJMEDIA_VIDEO_DEV_HAS_OPENGL ${PJMEDIA_WITH_VIDEODEV_OPENGL})
  set(PJMEDIA_VIDEO_DEV_HAS_OPENGL_ES ${PJMEDIA_WITH_VIDEODEV_OPENGL})
  set(PJMEDIA_VIDEO_DEV_HAS_FFMPEG ${PJMEDIA_WITH_VIDEODEV_FFMPEG})
  set(PJMEDIA_VIDEO_DEV_HAS_SDL ${PJMEDIA_WITH_VIDEODEV_SDL})
  set(PJMEDIA_VIDEO_DEV_HAS_DARWIN ${PJMEDIA_WITH_VIDEODEV_DARWIN})
  set(PJMEDIA_VIDEO_DEV_HAS_METAL ${PJMEDIA_WITH_VIDEODEV_METAL})
  set(PJMEDIA_VIDEO_DEV_HAS_QT ${PJMEDIA_WITH_VIDEODEV_QT})
  set(PJMEDIA_VIDEO_DEV_HAS_V4L2 ${PJMEDIA_WITH_VIDEODEV_V4L2})
  set(PJMEDIA_VIDEO_DEV_HAS_DSHOW ${PJMEDIA_WITH_VIDEODEV_DSHOW})
  set(PJMEDIA_VIDEO_DEV_HAS_ANDROID ${PJMEDIA_WITH_VIDEODEV_ANDROID})
  set(PJMEDIA_VIDEO_DEV_HAS_ANDROID_OPENGL 0)
  set(PJMEDIA_VIDEO_DEV_HAS_IOS_OPENGL 0)
  if(PJMEDIA_WITH_VIDEODEV_OPENGL)
    set(PJMEDIA_VIDEO_DEV_HAS_ANDROID_OPENGL ${ANDROID})
    set(PJMEDIA_VIDEO_DEV_HAS_IOS_OPENGL ${IOS})
  endif()

  # write configured header
  configure_file(
    include/pjmedia/config_auto.h.cm
    include/pjmedia/config_auto.h
  )
endblock()

# add generated file to headers file set
target_sources(pjmedia
  PUBLIC
    FILE_SET config_headers TYPE HEADERS
    BASE_DIRS
      "${CMAKE_CURRENT_BINARY_DIR}/include"
    FILES
      "${CMAKE_CURRENT_BINARY_DIR}/include/pjmedia/config_auto.h"
)

# A file set's BASE_DIRS land after whatever include directories the target
# already had, so the source tree would be searched first and an autotools
# build's leftover pjmedia/config_auto.h would shadow the one just generated.
# ./configure-android is the established Android workflow, so that leftover is
# the normal state of a working tree. BEFORE puts the build directory first.
target_include_directories(pjmedia BEFORE
  PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}/include>
)

#
# pjmedia - dependencies
#

target_link_libraries(pjmedia
  PUBLIC
    # pjlib - PUBLIC to propagate PJ_AUTOCONF and other compile definitions
    pjlib
    # included by the public headers
    pjlib-util pjnath
  PRIVATE
    # project
    pjlib-ssl

    # srtp: used by transport_srtp.c only. Its header directory holds generic
    # names (sha1.h, aes.h, err.h), which must not reach applications.
    $<$<BOOL:${PJMEDIA_WITH_SRTP}>:Pj::Dep::SRTP>

    # resampling backend
    $<$<STREQUAL:${PJMEDIA_WITH_RESAMPLE},libresample>:Pj::Dep::Resample>
    $<$<STREQUAL:${PJMEDIA_WITH_RESAMPLE},libsamplerate>:SampleRate::SampleRate>
    $<$<STREQUAL:${PJMEDIA_WITH_RESAMPLE},speex>:Pj::Dep::Speex>
    $<$<BOOL:${_pj_resample_speex_needs_speexdsp}>:SpeexDSP::SpeexDSP>

    # aec
    $<$<BOOL:${PJMEDIA_WITH_SPEEX_AEC}>:Pj::Dep::Speex>
    $<$<BOOL:${_pj_speex_aec_needs_speexdsp}>:SpeexDSP::SpeexDSP>
    $<$<BOOL:${PJMEDIA_WITH_WEBRTC_AEC}>:Pj::Dep::WebRTC>
    $<$<BOOL:${PJMEDIA_WITH_WEBRTC_AEC3}>:Pj::Dep::WebRTC_AEC3>

    # video
    $<$<BOOL:${PJMEDIA_WITH_LIBYUV}>:Pj::Dep::YUV>
    $<$<BOOL:${PJMEDIA_WITH_FFMPEG_AVUTIL}>:FFMPEG::avutil>
    $<$<BOOL:${PJMEDIA_WITH_FFMPEG_SWSCALE}>:FFMPEG::swscale>
    $<$<BOOL:${PJMEDIA_WITH_FFMPEG_AVCODEC}>:FFMPEG::avcodec>
    $<$<BOOL:${PJMEDIA_WITH_FFMPEG_AVFORMAT}>:FFMPEG::avformat>
    $<$<BOOL:${PJMEDIA_WITH_FFMPEG_AVDEVICE}>:FFMPEG::avdevice>
  INTERFACE
    # ...but srtp's library must: a shared libpjmedia needs it found when an
    # application links, and the installed package does not record where a
    # system one is
    $<LINK_ONLY:$<$<BOOL:${PJMEDIA_WITH_SRTP}>:Pj::Dep::SRTP>>
)

# The bundled AEC3 exports all its WebRTC OS/arch definitions, a system one
# only those its headers require; add the rest, as the make build does.
if(PJMEDIA_WITH_WEBRTC_AEC3)
  get_target_property(_pj_aec3_provider Pj::Dep::WebRTC_AEC3 PJ_DEP_PROVIDER)
  if(_pj_aec3_provider STREQUAL "system")
    include(DetectWebRTCParameters)
    target_compile_definitions(pjmedia PRIVATE ${WEBRTC_COMPILE_DEFINITIONS})
  endif()
  unset(_pj_aec3_provider)
endif()

if (NOT (WIN32 OR CYGWIN OR MINGW))
  # pjmedia calls libm functions (sin(), cos(), ...), a separate library on
  # these systems that the final link needs. Linked by name so that a cross
  # toolchain picks the libm matching its CPU flags; a Generic one resolves
  # -lm through its multilib specs, where find_library() does not look.
  find_library(MATH_LIBRARY m)
  if(MATH_LIBRARY OR CMAKE_SYSTEM_NAME STREQUAL "Generic")
    target_link_libraries(pjmedia PRIVATE m)
  endif()
endif()

# ##############################################################################
# pjmedia-codec

add_library(pjmedia-codec
  src/pjmedia-codec/amr_sdp_match.c
  src/pjmedia-codec/audio_codecs.c
  $<$<BOOL:${PJMEDIA_WITH_ANDROID_MEDIACODEC_CODEC}>:src/pjmedia-codec/and_aud_mediacodec.cpp>
  $<$<BOOL:${PJMEDIA_WITH_ANDROID_MEDIACODEC_CODEC}>:src/pjmedia-codec/and_vid_mediacodec.cpp>
  src/pjmedia-codec/bcg729.c
  src/pjmedia-codec/ffmpeg_vid_codecs.c
  src/pjmedia-codec/g722.c
  src/pjmedia-codec/g722/g722_enc.c
  src/pjmedia-codec/g722/g722_dec.c
  src/pjmedia-codec/g7221.c
  src/pjmedia-codec/g7221_sdp_match.c
  src/pjmedia-codec/gsm.c
  src/pjmedia-codec/h263_packetizer.c
  src/pjmedia-codec/h264_packetizer.c
  src/pjmedia-codec/ilbc.c
  src/pjmedia-codec/ipp_codecs.c
  src/pjmedia-codec/l16.c
  $<$<BOOL:${PJ_WITH_CXX}>:src/pjmedia-codec/lyra.cpp>
  src/pjmedia-codec/opencore_amr.c
  src/pjmedia-codec/speex_codec.c
  $<$<BOOL:${PJ_WITH_CXX}>:src/pjmedia-codec/openh264.cpp>
  $<$<BOOL:${PJMEDIA_WITH_VID_TOOLBOX_CODEC}>:src/pjmedia-codec/vid_toolbox.m>
  src/pjmedia-codec/opus.c
  src/pjmedia-codec/passthrough.c
  src/pjmedia-codec/silk.c
  src/pjmedia-codec/vpx_packetizer.c
  src/pjmedia-codec/vpx.c
)

# headers
target_sources(pjmedia-codec
  PUBLIC
    FILE_SET HEADERS
      BASE_DIRS
        include
      FILES
        include/pjmedia-codec.h
        include/pjmedia-codec/amr_helper.h
        include/pjmedia-codec/amr_sdp_match.h
        include/pjmedia-codec/and_aud_mediacodec.h
        include/pjmedia-codec/and_vid_mediacodec.h
        include/pjmedia-codec/audio_codecs.h
        include/pjmedia-codec/bcg729.h
        include/pjmedia-codec/config.h
        include/pjmedia-codec/ffmpeg_vid_codecs.h
        include/pjmedia-codec/g722.h
        include/pjmedia-codec/g7221.h
        include/pjmedia-codec/g7221_sdp_match.h
        include/pjmedia-codec/gsm.h
        include/pjmedia-codec/h263_packetizer.h
        include/pjmedia-codec/h264_packetizer.h
        include/pjmedia-codec/ilbc.h
        include/pjmedia-codec/ipp_codecs.h
        include/pjmedia-codec/l16.h
        include/pjmedia-codec/lyra.h
        include/pjmedia-codec/opencore_amr.h
        include/pjmedia-codec/openh264.h
        include/pjmedia-codec/opus.h
        include/pjmedia-codec/passthrough.h
        include/pjmedia-codec/silk.h
        include/pjmedia-codec/speex.h
        include/pjmedia-codec/types.h
        include/pjmedia-codec/vid_toolbox.h
        include/pjmedia-codec/vpx.h
        include/pjmedia-codec/vpx_packetizer.h
)

#
# pjmedia-codec - configuration
#

# lyra codec models path
if(PJMEDIA_WITH_LYRA_CODEC)
  get_target_property(lyra_model_path Lyra::Lyra LYRA_MODEL_PATH)
  if(lyra_model_path)
    target_compile_definitions(pjmedia-codec
      PRIVATE
        "PJMEDIA_CODEC_LYRA_DEFAULT_MODEL_PATH=\"${lyra_model_path}\""
    )
  endif()
endif()

# definitions header
block(SCOPE_FOR VARIABLES)
  # audio codecs
  set(PJMEDIA_HAS_L16_CODEC ${PJMEDIA_WITH_L16_CODEC})
  set(PJMEDIA_HAS_GSM_CODEC ${PJMEDIA_WITH_GSM_CODEC})
  set(PJMEDIA_HAS_SPEEX_CODEC ${PJMEDIA_WITH_SPEEX_CODEC})
  set(PJMEDIA_HAS_ILBC_CODEC ${PJMEDIA_WITH_ILBC_CODEC})
  set(PJMEDIA_HAS_G722_CODEC ${PJMEDIA_WITH_G722_CODEC})
  set(PJMEDIA_HAS_G7221_CODEC ${PJMEDIA_WITH_G7221_CODEC})
  set(PJMEDIA_HAS_OPENCORE_AMRNB_CODEC ${PJMEDIA_WITH_OPENCORE_AMRNB_CODEC})
  set(PJMEDIA_HAS_OPENCORE_AMRWB_CODEC ${PJMEDIA_WITH_OPENCORE_AMRWB_CODEC})
  set(PJMEDIA_HAS_SILK_CODEC ${PJMEDIA_WITH_SILK_CODEC})
  set(PJMEDIA_HAS_OPUS_CODEC ${PJMEDIA_WITH_OPUS_CODEC})
  set(PJMEDIA_HAS_BCG729 ${PJMEDIA_WITH_BCG729_CODEC})
  set(PJMEDIA_HAS_LYRA_CODEC ${PJMEDIA_WITH_LYRA_CODEC})

  # A system GSM is used via <gsm.h> (FindGSM covers the gsm/ subdir), as
  # autoconf --with-external-gsm; the bundled one via its relative path.
  set(PJMEDIA_EXTERNAL_GSM_CODEC 0)
  if(PJMEDIA_WITH_GSM_CODEC)
    get_target_property(_pj_gsm_provider Pj::Dep::GSM PJ_DEP_PROVIDER)
    if(_pj_gsm_provider STREQUAL "system")
      set(PJMEDIA_EXTERNAL_GSM_CODEC 1)
    endif()
    unset(_pj_gsm_provider)
  endif()
  set(PJMEDIA_EXTERNAL_GSM_GSM_H 0)
  set(PJMEDIA_EXTERNAL_GSM_H ${PJMEDIA_EXTERNAL_GSM_CODEC})

  # video codecs
  set(PJMEDIA_HAS_VPX_CODEC ${PJMEDIA_WITH_VPX_CODEC})
  set(PJMEDIA_HAS_OPENH264_CODEC ${PJMEDIA_WITH_OPEN_H264_CODEC})
  set(PJMEDIA_HAS_VID_TOOLBOX_CODEC ${PJMEDIA_WITH_VID_TOOLBOX_CODEC})
  set(PJMEDIA_HAS_ANDROID_MEDIACODEC ${PJMEDIA_WITH_ANDROID_MEDIACODEC_CODEC})

  # write configured header
  configure_file(
    include/pjmedia-codec/config_auto.h.cm
    include/pjmedia-codec/config_auto.h
  )
endblock()

# add generated file to headers file set
target_sources(pjmedia-codec
  PUBLIC
    FILE_SET config_headers TYPE HEADERS
    BASE_DIRS
      "${CMAKE_CURRENT_BINARY_DIR}/include"
    FILES
      "${CMAKE_CURRENT_BINARY_DIR}/include/pjmedia-codec/config_auto.h"
)

# A file set's BASE_DIRS land after whatever include directories the target
# already had, so the source tree would be searched first and an autotools
# build's leftover pjmedia-codec/config_auto.h would shadow the one just
# generated.
# ./configure-android is the established Android workflow, so that leftover is
# the normal state of a working tree. BEFORE puts the build directory first.
target_include_directories(pjmedia-codec BEFORE
  PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}/include>
)

#
# pjmedia-codec - dependencies
#

if(APPLE AND PJMEDIA_WITH_ILBC_CODEC)
  pj_find_package(AudioToolbox)
endif()

target_link_libraries(pjmedia-codec
  PUBLIC
    # pjmedia: included by the public headers
    pjlib pjmedia
  PRIVATE
    # project
    pjlib-util

    # audio codecs
    $<$<BOOL:${PJMEDIA_WITH_GSM_CODEC}>:Pj::Dep::GSM>
    $<$<BOOL:${PJMEDIA_WITH_SPEEX_CODEC}>:Pj::Dep::Speex>
    $<$<BOOL:${PJMEDIA_WITH_ILBC_CODEC}>:Pj::Dep::iLBC>
    $<$<BOOL:${_pj_link_g7221}>:Pj::Dep::G7221>
    $<$<BOOL:${PJMEDIA_WITH_OPENCORE_AMRNB_CODEC}>:OpenCoreAMRNB::OpenCoreAMRNB>
    $<$<BOOL:${PJMEDIA_WITH_OPENCORE_AMRWB_CODEC}>:OpenCoreAMRWB::OpenCoreAMRWB>
    $<$<BOOL:${PJMEDIA_WITH_OPENCORE_AMRWB_CODEC}>:VisualOnAMRWBEnc::VisualOnAMRWBEnc>
    $<$<BOOL:${PJMEDIA_WITH_SILK_CODEC}>:Silk::Silk>
    $<$<BOOL:${PJMEDIA_WITH_OPUS_CODEC}>:OPUS::OPUS>
    $<$<BOOL:${PJMEDIA_WITH_BCG729_CODEC}>:BCG729::BCG729>
    $<$<BOOL:${PJMEDIA_WITH_INTEL_IPP}>:IPP::IPP>
    $<$<BOOL:${PJMEDIA_WITH_LYRA_CODEC}>:Lyra::Lyra>

    # video codecs
    $<$<BOOL:${PJMEDIA_WITH_VPX_CODEC}>:VPX::VPX>
    $<$<BOOL:${PJMEDIA_WITH_OPEN_H264_CODEC}>:OpenH264::OpenH264>
    $<$<BOOL:${PJMEDIA_WITH_VID_TOOLBOX_CODEC}>:VideoToolbox::VideoToolbox>
    $<$<BOOL:${PJMEDIA_WITH_ANDROID_MEDIACODEC_CODEC}>:MediaNDK::MediaNDK>

    # PJMEDIA_ILBC_CODEC_USE_COREAUDIO makes ilbc.c use AudioConverter from
    # AudioToolbox. It is set in config_site.h, which CMake cannot see, so the
    # framework is linked whenever the codec is built on Apple -- as the
    # autotools build does globally.
    $<$<BOOL:${AudioToolbox_FOUND}>:AudioToolbox::AudioToolbox>
    $<$<BOOL:${PJMEDIA_WITH_FFMPEG_AVFORMAT}>:FFMPEG::avformat>
    $<$<BOOL:${PJMEDIA_WITH_FFMPEG_AVCODEC}>:FFMPEG::avcodec>
    $<$<BOOL:${PJMEDIA_WITH_FFMPEG_AVUTIL}>:FFMPEG::avutil>
)

# ##############################################################################
# pjmedia-audiodev

add_library(pjmedia-audiodev
  src/pjmedia-audiodev/alsa_dev.c
  src/pjmedia-audiodev/audiodev.c
  src/pjmedia-audiodev/audiotest.c
  src/pjmedia-audiodev/android_jni_dev.c
  src/pjmedia-audiodev/bb10_dev.c
  src/pjmedia-audiodev/bdimad_dev.c
  src/pjmedia-audiodev/errno.c
  src/pjmedia-audiodev/legacy_dev.c
  src/pjmedia-audiodev/null_dev.c
  $<$<BOOL:${PJ_WITH_CXX}>:src/pjmedia-audiodev/oboe_dev.cpp>
  src/pjmedia-audiodev/opensl_dev.c
  src/pjmedia-audiodev/pa_dev.c
  $<$<BOOL:${PJ_WITH_CXX}>:src/pjmedia-audiodev/wasapi_dev.cpp>
  $<$<BOOL:${PJ_WITH_CXX}>:src/pjmedia-audiodev/wasapi_dev_win.cpp>
  src/pjmedia-audiodev/wmme_dev.c

  $<$<BOOL:${APPLE}>:src/pjmedia-audiodev/coreaudio_dev.m>
)

# headers
target_sources(pjmedia-audiodev
  PUBLIC
    FILE_SET HEADERS
    BASE_DIRS
      include
    FILES
      include/pjmedia_audiodev.h
      include/pjmedia-audiodev/alsa.h
      include/pjmedia-audiodev/audiodev.h
      include/pjmedia-audiodev/audiodev_imp.h
      include/pjmedia-audiodev/audiotest.h
      include/pjmedia-audiodev/config.h
      include/pjmedia-audiodev/errno.h
      include/pjmedia-audiodev/wasapi.h
)

# Reads pjmedia/config_auto.h too, so it needs the build directory first as
# well, see pjmedia above
target_include_directories(pjmedia-audiodev BEFORE
  PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}/include>
)

#
# pjmedia-audiodev - configuration
#

# compile definitions
target_compile_definitions(pjmedia-audiodev
  PUBLIC
    # Always passed by autoconf too; the other backends are written into
    # pjmedia/config_auto.h, see above
    PJMEDIA_AUDIO_DEV_HAS_WMME=$<BOOL:${PJMEDIA_WITH_AUDIODEV_WMME}>
    PJMEDIA_AUDIO_DEV_HAS_PORTAUDIO=$<BOOL:${PJMEDIA_WITH_AUDIODEV_PORTAUDIO}>
)

#
# pjmedia-audiodev - dependencies
#

target_link_libraries(pjmedia-audiodev
  PUBLIC
    # pjmedia: included by the public headers
    pjlib pjmedia
  PRIVATE
    # project
    pjlib-util

    # audio backends
    $<$<BOOL:${PJMEDIA_WITH_AUDIODEV_ALSA}>:ALSA::ALSA>
    $<$<BOOL:${PJMEDIA_WITH_AUDIODEV_COREAUDIO}>:CoreAudio::CoreAudio>
    $<$<BOOL:${PJMEDIA_WITH_AUDIODEV_OBOE}>:Oboe::Oboe>
    $<$<BOOL:${PJMEDIA_WITH_AUDIODEV_WASAPI}>:WASAPI::WASAPI>
    $<$<BOOL:${PJMEDIA_WITH_AUDIODEV_PORTAUDIO}>:PortAudio::PortAudio>
    # pjlib links winmm privately, which a shared pjlib does not pass on
    $<$<BOOL:${PJMEDIA_WITH_AUDIODEV_WMME}>:winmm>

    # OpenSL ES, for opensl_dev.c (on with PJMEDIA_WITH_AUDIODEV_OPENSL or
    # config_site.h) and Oboe; autoconf links it on Android too
    $<$<BOOL:${ANDROID}>:OpenSLES>
)

# ##############################################################################
#  pjmedia-videodev

add_library(pjmedia-videodev
  src/pjmedia-videodev/avi_dev.c
  src/pjmedia-videodev/android_dev.c
  src/pjmedia-videodev/android_opengl.c
  src/pjmedia-videodev/colorbar_dev.c
  src/pjmedia-videodev/dshow_dev.c
  $<$<BOOL:${PJ_WITH_CXX}>:src/pjmedia-videodev/dshowclasses.cpp>
  src/pjmedia-videodev/errno.c
  src/pjmedia-videodev/ffmpeg_dev.c
  src/pjmedia-videodev/null_dev.c
  src/pjmedia-videodev/opengl_dev.c
  src/pjmedia-videodev/util.c
  src/pjmedia-videodev/v4l2_dev.c
  src/pjmedia-videodev/videodev.c

  $<$<BOOL:${IOS}>:src/pjmedia-videodev/ios_opengl_dev.m>
  $<$<BOOL:${PJMEDIA_WITH_VIDEODEV_DARWIN}>:src/pjmedia-videodev/darwin_dev.m>
  $<$<BOOL:${APPLE}>:src/pjmedia-videodev/sdl_dev_m.m>
  $<$<BOOL:${APPLE}>:src/pjmedia-videodev/metal_dev.m>
  $<$<BOOL:${APPLE}>:src/pjmedia-videodev/qt_dev.m>

  $<$<NOT:$<BOOL:${APPLE}>>:src/pjmedia-videodev/sdl_dev.c>
)

# headers
target_sources(pjmedia-videodev
  PUBLIC
    FILE_SET HEADERS
      BASE_DIRS
        include
      FILES
        include/pjmedia_videodev.h
        include/pjmedia-videodev/avi_dev.h
        include/pjmedia-videodev/config.h
        include/pjmedia-videodev/errno.h
        include/pjmedia-videodev/opengl_dev.h
        include/pjmedia-videodev/videodev.h
        include/pjmedia-videodev/videodev_imp.h
)

# Reads pjmedia/config_auto.h too, so it needs the build directory first as
# well, see pjmedia above
target_include_directories(pjmedia-videodev BEFORE
  PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}/include>
)

#
# pjmedia-videodev - configuration
#

# The backends are written into pjmedia/config_auto.h, see above

#
# pjmedia-videodev - dependencies
#

target_link_libraries(pjmedia-videodev
  PUBLIC
    # pjmedia: included by the public headers
    pjlib pjmedia
  PRIVATE
    # project
    pjlib-util

    # video backends
    $<$<BOOL:${PJMEDIA_WITH_VIDEODEV_OPENGL}>:${PJ_OPENGL_LINK_TARGETS}>
    $<$<BOOL:${PJMEDIA_WITH_VIDEODEV_FFMPEG}>:FFMPEG::avdevice>
    $<$<BOOL:${PJMEDIA_WITH_VIDEODEV_SDL}>:SDL2::SDL2>
    $<$<BOOL:${PJMEDIA_WITH_VIDEODEV_V4L2}>:V4L2::V4L2>
    $<$<BOOL:${PJMEDIA_WITH_VIDEODEV_DARWIN}>:AVFoundation::AVFoundation>
    $<$<BOOL:${PJMEDIA_WITH_VIDEODEV_METAL}>:Metal::Metal>
    # TODO: add remaining APIs' dependencies

    # transitive deps
    $<$<BOOL:${PJMEDIA_WITH_LIBYUV}>:Pj::Dep::YUV>
)

# sdl_dev.c asks MSVC to link "sdl2.lib" with #pragma comment(lib); name the
# file actually linked instead, which differs per configuration (SDL2d.lib in
# a vcpkg Debug build)
if(MSVC AND PJMEDIA_WITH_VIDEODEV_SDL)
  set(_pj_sdl_target SDL2::SDL2)
  get_target_property(_pj_sdl_aliased SDL2::SDL2 ALIASED_TARGET)
  if(_pj_sdl_aliased)
    set(_pj_sdl_target ${_pj_sdl_aliased})
  endif()
  get_target_property(_pj_sdl_type ${_pj_sdl_target} TYPE)
  if(NOT _pj_sdl_type STREQUAL "INTERFACE_LIBRARY")
    target_compile_definitions(pjmedia-videodev PRIVATE
      "PJMEDIA_SDL_LIB=\"$<TARGET_LINKER_FILE_NAME:${_pj_sdl_target}>\""
    )
  endif()
  unset(_pj_sdl_target)
  unset(_pj_sdl_aliased)
  unset(_pj_sdl_type)
endif()

# DirectShow capture is the only user of the bundled BaseClasses, so they are
# compiled in here rather than built and installed as a library of their own.
if(PJMEDIA_WITH_VIDEODEV_DSHOW)
  set(_baseclasses "${CMAKE_CURRENT_SOURCE_DIR}/../third_party/BaseClasses")
  set(_baseclasses_sources
    ${_baseclasses}/amfilter.cpp
    ${_baseclasses}/amvideo.cpp
    ${_baseclasses}/arithutil.cpp
    ${_baseclasses}/combase.cpp
    ${_baseclasses}/ctlutil.cpp
    ${_baseclasses}/mtype.cpp
    ${_baseclasses}/renbase.cpp
    ${_baseclasses}/wxdebug.cpp
    ${_baseclasses}/wxlist.cpp
    ${_baseclasses}/wxutil.cpp
  )
  target_sources(pjmedia-videodev PRIVATE ${_baseclasses_sources})
  # SYSTEM, and -w below: Microsoft's sample code is not ours to clean up,
  # and under GCC's -Wall its headers would bury the warnings of the code
  # including them (dshowclasses.cpp)
  target_include_directories(pjmedia-videodev SYSTEM
    PRIVATE
      $<BUILD_INTERFACE:${_baseclasses}>
  )
  # winmm for the multimedia timers in renbase.cpp: pjlib links it privately,
  # which a shared pjlib does not pass on.
  target_link_libraries(pjmedia-videodev
    PRIVATE strmiids quartz rpcrt4 ole32 winmm)
  # As third_party/build/baseclasses/Makefile: the BaseClasses carry MSVC-isms
  # (e.g. calling a constructor directly) that GCC accepts only permissively.
  if(NOT MSVC)
    set_source_files_properties(${_baseclasses_sources}
      TARGET_DIRECTORY pjmedia-videodev
      PROPERTIES
        COMPILE_OPTIONS "-fpermissive;-w"
        COMPILE_DEFINITIONS "__STRSAFE__NO_INLINE=1"
    )
    target_link_libraries(pjmedia-videodev PRIVATE oleaut32 uuid)
  endif()
  unset(_baseclasses_sources)
  unset(_baseclasses)
endif()

# ##############################################################################
#  Test application

if(BUILD_TESTING)
  add_executable(pjmedia-test
    src/test/codec_vectors.c
    src/test/conf_test.c
    src/test/jbuf_test.c
    src/test/main.c
    src/test/mips_test.c
    src/test/vid_codec_test.c
    src/test/vid_conf_test.c
    src/test/vid_dev_test.c
    src/test/vid_port_test.c
    src/test/rtp_test.c
    src/test/test.c
    src/test/tone_detector_test.c
    src/test/txt_stream_test.c
    src/test/sdp_neg_test.c
    src/test/sdp_attr_test.c
    src/test/transport_srtp_test.c
  )

  target_link_libraries(pjmedia-test
    PRIVATE
      pjlib
      pjlib-util
      pjnath
      pjmedia
      pjmedia-codec
      pjmedia-audiodev
      pjmedia-videodev
      $<$<BOOL:${PJMEDIA_WITH_OPUS_CODEC}>:OPUS::OPUS>
  )

  # The test data is found relative to pjmedia/build, where make runs it
  add_test(NAME pjmedia-test
    COMMAND pjmedia-test
    WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/build"
  )
endif()

# The third-party libraries linked above, under the same conditions: the
# top-level CMakeLists.txt installs and exports only these
set(_pj_used_deps)
if(PJMEDIA_WITH_SRTP)
  list(APPEND _pj_used_deps SRTP)
endif()
if(PJMEDIA_WITH_RESAMPLE STREQUAL "libresample")
  list(APPEND _pj_used_deps Resample)
endif()
if(PJMEDIA_WITH_RESAMPLE STREQUAL "speex" OR PJMEDIA_WITH_SPEEX_AEC
   OR PJMEDIA_WITH_SPEEX_CODEC)
  list(APPEND _pj_used_deps Speex)
endif()
if(PJMEDIA_WITH_WEBRTC_AEC)
  list(APPEND _pj_used_deps WebRTC)
endif()
if(PJMEDIA_WITH_WEBRTC_AEC3)
  list(APPEND _pj_used_deps WebRTC_AEC3)
endif()
if(PJMEDIA_WITH_LIBYUV)
  list(APPEND _pj_used_deps YUV)
endif()
if(PJMEDIA_WITH_GSM_CODEC)
  list(APPEND _pj_used_deps GSM)
endif()
if(PJMEDIA_WITH_ILBC_CODEC)
  list(APPEND _pj_used_deps iLBC)
endif()
if(_pj_link_g7221)
  list(APPEND _pj_used_deps G7221)
endif()
set_property(GLOBAL PROPERTY PJ_USED_DEPS ${_pj_used_deps})
unset(_pj_used_deps)

# For the pkg-config file: the files of the dependencies found here
pj_pc_remember_imported_targets()
