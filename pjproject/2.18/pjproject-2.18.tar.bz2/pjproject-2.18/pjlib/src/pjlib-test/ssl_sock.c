/* 
 * Copyright (C) 2008-2026 Teluu Inc. (http://www.teluu.com)
 * Copyright (C) 2003-2008 Benny Prijono <benny@prijono.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
#include "ssl_sock_test.h"

/* Test direct certificate loading.
 * For OpenSSL backend only and TEST_LOAD_FROM_FILES must be 1.
 */
#define TEST_LOAD_DIRECT            1

#define TEST_CERT_BUFFER            \
    (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL || \
     PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_GNUTLS || \
     PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_MBEDTLS)


#if INCLUDE_SSLSOCK_TEST

/* Global vars */
static int clients_num;

struct send_key {
    pj_ioqueue_op_key_t op_key;
};


static int get_cipher_list(void) {
    pj_status_t status;
    pj_ssl_cipher ciphers[PJ_SSL_SOCK_MAX_CIPHERS];
    unsigned cipher_num;
    unsigned i;

    cipher_num = PJ_ARRAY_SIZE(ciphers);
    status = pj_ssl_cipher_get_availables(ciphers, &cipher_num);
    if (status != PJ_SUCCESS) {
        app_perror("...FAILED to get available ciphers", status);
        return status;
    }

    PJ_LOG(3, ("", "...Found %u ciphers:", cipher_num));
    for (i = 0; i < cipher_num; ++i) {
        const char* st;
        st = pj_ssl_cipher_name(ciphers[i]);
        if (st == NULL)
            st = "[Unknown]";

        PJ_LOG(3, ("", "...%3u: 0x%08x=%s", i+1, ciphers[i], st));
    }

    return PJ_SUCCESS;
}


struct test_state
{
    pj_pool_t      *pool;           /* pool                                 */
    pj_ioqueue_t   *ioqueue;        /* ioqueue                              */
    pj_ssl_sock_t  *accepted_ssock; /* accepted server-side socket          */
    struct test_state *accepted_st; /* state of the accepted socket         */
    pj_bool_t       is_server;      /* server role flag                     */
    const char     *cert_der;       /* DER of this end's own certificate    */
    pj_bool_t       is_verbose;     /* verbose flag, e.g: cert info         */
    pj_bool_t       echo;           /* echo received data                   */
    pj_status_t     err;            /* error flag                           */
    pj_size_t       sent;           /* bytes sent                           */
    pj_size_t       recv;           /* bytes received                       */
    pj_uint8_t      read_buf[256];  /* read buffer                          */
    pj_bool_t       done;           /* test done flag                       */
    char           *send_str;       /* data to send once connected          */
    pj_size_t       send_str_len;   /* send data length                     */
    pj_bool_t       check_echo;     /* flag to compare sent & echoed data   */
    const char     *check_echo_ptr; /* pointer/cursor for comparing data    */
    struct send_key send_key;       /* send op key                          */
};

static void dump_ssl_info(const pj_ssl_sock_info *si)
{
    const char *tmp_st;

    /* Print cipher name */
    tmp_st = pj_ssl_cipher_name(si->cipher);
    if (tmp_st == NULL)
        tmp_st = "[Unknown]";
    PJ_LOG(3, ("", ".....Cipher: %s", tmp_st));

    /* Print remote certificate info and verification result */
    if (si->remote_cert_info && si->remote_cert_info->subject.info.slen) 
    {
        char buf[2048];
        const char *verif_msgs[32];
        unsigned verif_msg_cnt;

        /* Dump remote TLS certificate info */
        PJ_LOG(3, ("", ".....Remote certificate info:"));
        pj_ssl_cert_info_dump(si->remote_cert_info, "  ", buf, sizeof(buf));
        PJ_LOG(3,("", "\n%s", buf));

        /* Dump remote TLS certificate verification result */
        verif_msg_cnt = PJ_ARRAY_SIZE(verif_msgs);
        pj_ssl_cert_get_verify_status_strings(si->verify_status,
                                              verif_msgs, &verif_msg_cnt);
        PJ_LOG(3,("", ".....Remote certificate verification result: %s",
                  (verif_msg_cnt == 1? verif_msgs[0]:"")));
        if (verif_msg_cnt > 1) {
            unsigned i;
            for (i = 0; i < verif_msg_cnt; ++i)
                PJ_LOG(3,("", "..... - %s", verif_msgs[i]));
        }
    }
}

/* The local raw chain must hold the local certificate, in storage of its
 * own rather than the peer chain's. der_name is the DER of the certificate
 * this end presents, or NULL to compare the storage only. Backends that
 * don't report the local raw chain, e.g. OpenSSL, leave cnt zero and are
 * skipped.
 */
static pj_status_t check_raw_chain(const pj_ssl_sock_info *si,
                                   pj_pool_t *pool,
                                   const char *der_name)
{
    const pj_ssl_cert_info *lci = si->local_cert_info;
    const pj_ssl_cert_info *rci = si->remote_cert_info;
    pj_str_t der_file;
    pj_oshandle_t fd = NULL;
    pj_ssize_t size;
    pj_str_t der;
    pj_status_t status;

    if (!lci || lci->raw_chain.cnt == 0)
        return PJ_SUCCESS;

    if (rci && rci->raw_chain.cnt &&
        lci->raw_chain.cert_raw == rci->raw_chain.cert_raw)
    {
        return PJ_EBUG;
    }

    if (!der_name)
        return PJ_SUCCESS;

    der_file = pj_str((char*)der_name);
    size = (pj_ssize_t)pj_file_size(der_file.ptr);
    if (size <= 0)
        return PJ_ENOTFOUND;

    status = pj_file_open(pool, der_file.ptr, PJ_O_RDONLY, &fd);
    if (status != PJ_SUCCESS)
        return status;

    der.ptr = (char*)pj_pool_alloc(pool, size);
    status = pj_file_read(fd, der.ptr, &size);
    der.slen = size;
    pj_file_close(fd);
    if (status != PJ_SUCCESS)
        return status;
    if (der.slen <= 0)
        return PJ_EEOF;

    if (lci->raw_chain.cert_raw[0].slen != der.slen ||
        pj_memcmp(lci->raw_chain.cert_raw[0].ptr, der.ptr, der.slen))
    {
        return PJ_EBUG;
    }

    return PJ_SUCCESS;
}


static pj_bool_t ssl_on_connect_complete(pj_ssl_sock_t *ssock,
                                         pj_status_t status)
{
    struct test_state *st = (struct test_state*) 
                            pj_ssl_sock_get_user_data(ssock);
    void *read_buf[1];
    pj_ssl_sock_info info;
    char buf1[64], buf2[64];

    if (status != PJ_SUCCESS) {
        app_perror("...ERROR ssl_on_connect_complete()", status);
        goto on_return;
    }

    status = pj_ssl_sock_get_info(ssock, &info);
    if (status != PJ_SUCCESS) {
        app_perror("...ERROR pj_ssl_sock_get_info()", status);
        goto on_return;
    }

    status = check_raw_chain(&info, st->pool, st->cert_der);
    if (status != PJ_SUCCESS) {
        app_perror("...ERROR invalid local raw chain", status);
        goto on_return;
    }

    pj_sockaddr_print((pj_sockaddr_t*)&info.local_addr, buf1, sizeof(buf1), 1);
    pj_sockaddr_print((pj_sockaddr_t*)&info.remote_addr, buf2, sizeof(buf2), 1);
    PJ_LOG(3, ("", "...Connected %s -> %s!", buf1, buf2));

    if (st->is_verbose)
        dump_ssl_info(&info);

    /* Start reading data */
    read_buf[0] = st->read_buf;
    status = pj_ssl_sock_start_read2(ssock, st->pool, sizeof(st->read_buf), (void**)read_buf, 0);
    if (status != PJ_SUCCESS) {
        app_perror("...ERROR pj_ssl_sock_start_read2()", status);
        goto on_return;
    }

    /* Start sending data */
    while (st->sent < st->send_str_len) {
        pj_ssize_t size;

        size = st->send_str_len - st->sent;
        status = pj_ssl_sock_send(ssock, (pj_ioqueue_op_key_t*)&st->send_key, 
                                  st->send_str + st->sent, &size, 0);
        if (status != PJ_SUCCESS && status != PJ_EPENDING) {
            app_perror("...ERROR pj_ssl_sock_send()", status);
            goto on_return;
        }

        if (status == PJ_SUCCESS) {
            st->sent += size;
        } else {
            if (status == PJ_EPENDING)
                status = PJ_SUCCESS;
            break;
        }
    }

on_return:
    st->err = status;

    if (st->err != PJ_SUCCESS) {
        pj_ssl_sock_close(ssock);
        clients_num--;
        return PJ_FALSE;
    }

    return PJ_TRUE;
}


static pj_bool_t ssl_on_accept_complete(pj_ssl_sock_t *ssock,
                                        pj_ssl_sock_t *newsock,
                                        const pj_sockaddr_t *src_addr,
                                        int src_addr_len,
                                        pj_status_t accept_status)
{
    struct test_state *parent_st = (struct test_state*) 
                                   pj_ssl_sock_get_user_data(ssock);
    struct test_state *st;
    void *read_buf[1];
    pj_ssl_sock_info info;
    char buf[64];
    pj_status_t status;

    PJ_UNUSED_ARG(src_addr_len);
    
    if (accept_status != PJ_SUCCESS) {
        if (newsock) {
            st = (struct test_state*) pj_ssl_sock_get_user_data(newsock);
            st->err = accept_status;
        }
        return PJ_FALSE;
    }

    /* Duplicate parent test state to newly accepted test state */
    st = (struct test_state*)pj_pool_zalloc(parent_st->pool, sizeof(struct test_state));
    *st = *parent_st;
    pj_ssl_sock_set_user_data(newsock, st);

    /* Track accepted socket for cleanup */
    parent_st->accepted_ssock = newsock;
    parent_st->accepted_st = st;

    status = pj_ssl_sock_get_info(newsock, &info);
    if (status != PJ_SUCCESS) {
        app_perror("...ERROR pj_ssl_sock_get_info()", status);
        goto on_return;
    }

    status = check_raw_chain(&info, st->pool, st->cert_der);
    if (status != PJ_SUCCESS) {
        app_perror("...ERROR invalid local raw chain", status);
        /* Report through the parent and keep echoing: closing from this
         * callback leaves on_handshake_complete() using a released
         * ssock->parent, and perf_test() waits for every client to finish.
         */
        parent_st->err = status;
    }

    pj_sockaddr_print(src_addr, buf, sizeof(buf), 1);
    PJ_LOG(3, ("", "...Accepted connection from %s", buf));

    if (st->is_verbose)
        dump_ssl_info(&info);

    /* Start reading data */
    read_buf[0] = st->read_buf;
    status = pj_ssl_sock_start_read2(newsock, st->pool, sizeof(st->read_buf), (void**)read_buf, 0);
    if (status != PJ_SUCCESS) {
        app_perror("...ERROR pj_ssl_sock_start_read2()", status);
        goto on_return;
    }

    /* Start sending data */
    while (st->sent < st->send_str_len) {
        pj_ssize_t size;

        size = st->send_str_len - st->sent;
        status = pj_ssl_sock_send(newsock, (pj_ioqueue_op_key_t*)&st->send_key, 
                                  st->send_str + st->sent, &size, 0);
        if (status != PJ_SUCCESS && status != PJ_EPENDING) {
            app_perror("...ERROR pj_ssl_sock_send()", status);
            goto on_return;
        }

        if (status == PJ_SUCCESS) {
            st->sent += size;
        } else {
            if (status == PJ_EPENDING)
                status = PJ_SUCCESS;
            break;
        }
    }

on_return:
    st->err = status;

    if (st->err != PJ_SUCCESS) {
        pj_ssl_sock_close(newsock);
        return PJ_FALSE;
    }

    return PJ_TRUE;
}

static pj_bool_t ssl_on_data_read(pj_ssl_sock_t *ssock,
                                  void *data,
                                  pj_size_t size,
                                  pj_status_t status,
                                  pj_size_t *remainder)
{
    struct test_state *st = (struct test_state*) 
                             pj_ssl_sock_get_user_data(ssock);

    PJ_UNUSED_ARG(remainder);
    PJ_UNUSED_ARG(data);

    if (size > 0) {
        pj_size_t consumed;

        /* Set random remainder */
        *remainder = pj_rand() % 100;

        /* Apply zero remainder if:
         * - remainder is less than size, or
         * - connection closed/error
         * - echo/check_eco set
         */
        if (*remainder > size || status != PJ_SUCCESS || st->echo || st->check_echo)
            *remainder = 0;

        consumed = size - *remainder;
        st->recv += consumed;

        //printf("%.*s", consumed, (char*)data);

        pj_memmove(data, (char*)data + consumed, *remainder);

        /* Echo data when specified to */
        if (st->echo) {
            pj_ssize_t size_ = consumed;
            status = pj_ssl_sock_send(ssock, (pj_ioqueue_op_key_t*)&st->send_key, data, &size_, 0);
            if (status != PJ_SUCCESS && status != PJ_EPENDING) {
                app_perror("...ERROR pj_ssl_sock_send()", status);
                goto on_return;
            }

            if (status == PJ_SUCCESS) {
                st->sent += size_;
            } else if (status == PJ_EPENDING) {
                status = PJ_SUCCESS;
            }
        }

        /* Verify echoed data when specified to */
        if (st->check_echo) {
            if (!st->check_echo_ptr)
                st->check_echo_ptr = st->send_str;

            if (pj_memcmp(st->check_echo_ptr, data, consumed)) {
                status = PJ_EINVAL;
                app_perror("...ERROR echoed data not exact", status);
                goto on_return;
            }
            st->check_echo_ptr += consumed;

            /* Echo received completely */
            if (st->send_str_len == st->recv) {
                pj_ssl_sock_info info;
                char buf[64];

                status = pj_ssl_sock_get_info(ssock, &info);
                if (status != PJ_SUCCESS) {
                    app_perror("...ERROR pj_ssl_sock_get_info()", status);
                    goto on_return;
                }

                pj_sockaddr_print((pj_sockaddr_t*)&info.local_addr, buf, sizeof(buf), 1);
                PJ_LOG(3, ("", "...%s successfully recv %lu bytes echo", buf,
                           (unsigned long)st->recv));
                st->done = PJ_TRUE;
            }
        }
    }

    if (status != PJ_SUCCESS) {
        if (status == PJ_EEOF) {
            status = PJ_SUCCESS;
            st->done = PJ_TRUE;
        } else {
            app_perror("...ERROR ssl_on_data_read()", status);
        }
    }

on_return:
    st->err = status;

    if (st->err != PJ_SUCCESS || st->done) {
        pj_ssl_sock_close(ssock);
        if (!st->is_server)
            clients_num--;
        return PJ_FALSE;
    }

    return PJ_TRUE;
}

static pj_bool_t ssl_on_data_sent(pj_ssl_sock_t *ssock,
                                  pj_ioqueue_op_key_t *op_key,
                                  pj_ssize_t sent)
{
    struct test_state *st = (struct test_state*)
                             pj_ssl_sock_get_user_data(ssock);
    PJ_UNUSED_ARG(op_key);

    if (sent < 0) {
        st->err = (pj_status_t)-sent;
    } else {
        st->sent += sent;

        /* Send more if any */
        while (st->sent < st->send_str_len) {
            pj_ssize_t size;
            pj_status_t status;

            size = st->send_str_len - st->sent;
            status = pj_ssl_sock_send(ssock, (pj_ioqueue_op_key_t*)&st->send_key, 
                                      st->send_str + st->sent, &size, 0);
            if (status != PJ_SUCCESS && status != PJ_EPENDING) {
                app_perror("...ERROR pj_ssl_sock_send()", status);
                st->err = status;
                break;
            }

            if (status == PJ_SUCCESS)
                st->sent += size;
            else
                break;
        }
    }

    if (st->err != PJ_SUCCESS) {
        pj_ssl_sock_close(ssock);
        if (!st->is_server)
            clients_num--;
        return PJ_FALSE;
    }

    return PJ_TRUE;
}

#define HTTP_SERVER_ADDR        "www.pjsip.org"
#define HTTP_SERVER_PORT        443
#define HTTP_REQ                "GET https://" HTTP_SERVER_ADDR "/ HTTP/1.0\r\n\r\n";

static int https_client_test(unsigned ms_timeout)
{
    pj_pool_t *pool = NULL;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_ssl_sock_t *ssock = NULL;
    pj_ssl_sock_param param;
    pj_status_t status;
    struct test_state state = {0};
    pj_sockaddr local_addr, rem_addr;
    pj_str_t tmp_st;

    pool = pj_pool_create(mem, "https_get", 256, 256, NULL);

    status = pj_ioqueue_create(pool, 4, &ioqueue);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    status = pj_timer_heap_create(pool, 4, &timer);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    state.pool = pool;
    state.send_str = HTTP_REQ;
    state.send_str_len = pj_ansi_strlen(state.send_str);
    state.is_verbose = PJ_TRUE;

    pj_ssl_sock_param_default(&param);
    param.cb.on_connect_complete = &ssl_on_connect_complete;
    param.cb.on_data_read = &ssl_on_data_read;
    param.cb.on_data_sent = &ssl_on_data_sent;
    param.ioqueue = ioqueue;
    param.user_data = &state;
    param.server_name = pj_str((char*)HTTP_SERVER_ADDR);
    param.timer_heap = timer;
    param.timeout.sec = 0;
    param.timeout.msec = ms_timeout;
    pj_time_val_normalize(&param.timeout);

    status = pj_ssl_sock_create(pool, &param, &ssock);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    pj_sockaddr_init(PJ_AF_INET, &local_addr, pj_strset2(&tmp_st, "0.0.0.0"), 0);
    pj_sockaddr_init(PJ_AF_INET, &rem_addr, pj_strset2(&tmp_st, HTTP_SERVER_ADDR), HTTP_SERVER_PORT);
    status = pj_ssl_sock_start_connect(ssock, pool, &local_addr, &rem_addr, pj_sockaddr_get_len(&local_addr));
    if (status == PJ_SUCCESS) {
        ssl_on_connect_complete(ssock, PJ_SUCCESS);
    } else if (status == PJ_EPENDING) {
        status = PJ_SUCCESS;
    } else {
        goto on_return;
    }

    /* Wait until everything has been sent/received */
    while (state.err == PJ_SUCCESS && !state.done) {
#ifdef PJ_SYMBIAN
        pj_symbianos_poll(-1, 1000);
#else
        pj_time_val delay = {0, 100};
        pj_ioqueue_poll(ioqueue, &delay);
        pj_timer_heap_poll(timer, &delay);
#endif
    }

    if (state.err) {
        status = state.err;
        goto on_return;
    }

    PJ_LOG(3, ("", "...Done!"));
    PJ_LOG(3, ("", ".....Sent/recv: %lu/%lu bytes", (unsigned long)state.sent,
               (unsigned long)state.recv));

on_return:
    if (ssock && !state.err && !state.done) 
        pj_ssl_sock_close(ssock);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    if (timer)
        pj_timer_heap_destroy(timer);
    if (pool)
        pj_pool_release(pool);

    return status;
}

#if !(defined(TEST_LOAD_FROM_FILES) && TEST_LOAD_FROM_FILES==1) || \
    TEST_CERT_BUFFER
static pj_status_t load_cert_to_buf(pj_pool_t *pool, const pj_str_t *file_name,
                                    pj_ssl_cert_buffer *buf)
{
    pj_status_t status;
    pj_oshandle_t fd = 0;
    pj_ssize_t size = (pj_ssize_t)pj_file_size(file_name->ptr);

    if (size < 0) {
        status = pj_get_os_error();
        return status ? status : PJ_ENOTFOUND;
    }

    status = pj_file_open(pool, file_name->ptr, PJ_O_RDONLY, &fd);
    if (status != PJ_SUCCESS)
        return status;

    buf->ptr = (char*)pj_pool_zalloc(pool, size+1);
    status = pj_file_read(fd, buf->ptr, &size);
    buf->slen = size;

    pj_file_close(fd);
    fd = NULL;
    return status;
}
#endif

#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_SCHANNEL)

static pj_status_t load_cert_from_store(pj_pool_t *pool,
                                        pj_ssl_cert_t **p_cert)
{
#if 0
    /* To test loading certificate from the store, follow these steps:
     * 1. Install the certificate & the private-key pair to the store,
     *    and optionally set the friendly-name for it.
     * 2. Update the lookup criteria below (field & keyword).
     */
    pj_ssl_cert_lookup_criteria crit = {0};

    /* Lookup by subject */
    crit.type = PJ_SSL_CERT_LOOKUP_SUBJECT;
    pj_cstr(&crit.keyword, "test.pjsip.org");

    /* Lookup by friendly-name */
    //crit.type = PJ_SSL_CERT_LOOKUP_FRIENDLY_NAME;
    //pj_cstr(&crit.keyword, "schannel-test");

    /* Lookup by fingerprint */
    //crit.type = PJ_SSL_CERT_LOOKUP_FINGERPRINT;
    //pj_cstr(&crit.keyword, "\x08\x3a\x6c\xdc\xd0\x19\x59\xec\x28\xc3"
    //                       "\x81\xb8\xc0\x21\x09\xe9\xd5\xf6\x57\x7d");

    return pj_ssl_cert_load_from_store(pool, &crit, p_cert);
#else
    /* Set no certificate, Schannel will use self-signed cert */
    PJ_UNUSED_ARG(pool);
    PJ_UNUSED_ARG(p_cert);
    return PJ_ENOTFOUND;
#endif
}

#endif

#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL)

#include <openssl/bio.h>
#include <openssl/pem.h>

static int pass_cb(char *buf, int size, int rwflag, void *u)
{
    pj_str_t pass = pj_str(CERT_PRIVKEY_PASS);

    PJ_UNUSED_ARG(rwflag);
    PJ_UNUSED_ARG(u);

    if (pass.slen > size)
        pass.slen = size;
    pj_memcpy(buf, pass.ptr, pass.slen);

    return (int)pass.slen;
}

static pj_status_t load_cert_direct(pj_pool_t *pool,
                                    pj_bool_t with_cert,
                                    pj_bool_t with_privkey,
                                    pj_ssl_cert_t **p_cert)
{
    BIO *in;
    pj_ssl_cert_direct cd;
    pj_status_t status;

    PJ_UNUSED_ARG(pool);

    /* Init credential */
    pj_bzero(&cd, sizeof(cd));

    /* Load private key */
    if (with_privkey) {
        EVP_PKEY *key = NULL;

        in = BIO_new_file(CERT_PRIVKEY_FILE, "r");
        if (!in)
            return PJ_ENOTFOUND;

        key = PEM_read_bio_PrivateKey(in, NULL, &pass_cb, NULL);
        BIO_free(in);
        if (!key)
            return PJ_EINVAL;
        
        cd.type |= PJ_SSL_CERT_DIRECT_OPENSSL_EVP_PKEY;
        cd.privkey = key;
    }

    /* Load certificate */
    if (with_cert) {
        X509* x = NULL;

        in = BIO_new_file(CERT_FILE, "r");
        if (!in) {
            status = PJ_ENOTFOUND;
            goto on_error;
        }

        x = PEM_read_bio_X509(in, NULL, 0, NULL);
        BIO_free(in);
        if (!x) {
            status = PJ_EINVAL;
            goto on_error;
        }

        cd.type |= PJ_SSL_CERT_DIRECT_OPENSSL_X509_CERT;
        cd.cert = x;
    }

    /* Create credential */
    status = pj_ssl_cert_load_direct(pool, &cd, p_cert);

    /* Drop the reference taken by PEM_read_bio_*(), but only where
     * pj_ssl_cert_load_direct() took one of its own -- it up-refs under the
     * same guard, and ssl_free_cert() is likewise a no-op below 3.0. Freeing
     * unconditionally would release the last reference on OpenSSL 1.x and
     * LibreSSL and leave the credential pointing at freed objects.
     *
     * Below 3.0 the header contract holds instead: the application keeps the
     * objects alive for as long as the credential is used.
     */
#if (OPENSSL_VERSION_NUMBER >= 0x30000000L)
    if (cd.privkey)
        EVP_PKEY_free(cd.privkey);
    if (cd.cert)
        X509_free(cd.cert);
#endif

    return status;

on_error:
    /* No credential was created, so nothing else can be holding these and
     * the release is correct on every OpenSSL version -- unlike the tail
     * above, which is surplus only where the credential took its own.
     */
    if (cd.privkey)
        EVP_PKEY_free(cd.privkey);

    return status;
}
#else
#   define load_cert_direct(pool,p_cert)
#endif

/* Supplied credentials are borrowed; NULL selects the default fixtures. */
static int echo_test_with_certs(pj_ssl_sock_proto srv_proto,
                               pj_ssl_sock_proto cli_proto,
                               pj_ssl_cipher srv_cipher,
                               pj_ssl_cipher cli_cipher,
                               pj_bool_t req_client_cert,
                               pj_bool_t client_provide_cert,
                               pj_bool_t verify_peer,
                               const pj_ssl_cert_t *server_cert,
                               const pj_ssl_cert_t *client_cert)
{
    pj_pool_t *pool = NULL;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_ssl_sock_t *ssock_serv = NULL;
    pj_ssl_sock_t *ssock_cli = NULL;
    pj_ssl_sock_param param;
    struct test_state state_serv = { 0 };
    struct test_state state_cli = { 0 };
    pj_sockaddr addr, listen_addr;
    pj_ssl_cipher ciphers[1];
    pj_ssl_cert_t *cert = NULL;
    pj_status_t status;

#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_SCHANNEL)
    PJ_UNUSED_ARG(server_cert);
#endif

    pool = pj_pool_create(mem, "ssl_echo", 256, 256, NULL);

    status = pj_ioqueue_create(pool, 4, &ioqueue);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    status = pj_timer_heap_create(pool, 4, &timer);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    pj_ssl_sock_param_default(&param);
    param.cb.on_accept_complete2 = &ssl_on_accept_complete;
    param.cb.on_connect_complete = &ssl_on_connect_complete;
    param.cb.on_data_read = &ssl_on_data_read;
    param.cb.on_data_sent = &ssl_on_data_sent;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;
    param.ciphers = ciphers;
    param.verify_peer = verify_peer;

    /* Init default bind address */
    {
        pj_str_t tmp_st;
        pj_sockaddr_init(PJ_AF_INET, &addr, pj_strset2(&tmp_st, "127.0.0.1"), 0);
    }

    /* === SERVER === */
    param.proto = srv_proto;
    param.user_data = &state_serv;
    param.ciphers_num = (srv_cipher == -1)? 0 : 1;
    param.require_client_cert = req_client_cert;
    ciphers[0] = srv_cipher;

    state_serv.pool = pool;
    state_serv.echo = PJ_TRUE;
    state_serv.is_server = PJ_TRUE;
    state_serv.is_verbose = PJ_TRUE;
    state_serv.cert_der = CERT_DER_FILE;

    status = pj_ssl_sock_create(pool, &param, &ssock_serv);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Set server cert */
#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_SCHANNEL)
    /* Schannel backend currently can only load certificates from
     * OS cert store. If the certificate loading fails, we'll skip setting
     * certificate, so the SSL socket will create & use a self-signed cert.
     */
    status = load_cert_from_store(pool, &cert);
    if (status == PJ_SUCCESS) {
        status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }
    }
#else
    if (server_cert) {
        status = pj_ssl_sock_set_certificate(ssock_serv, pool, server_cert);
        if (status != PJ_SUCCESS)
            goto on_return;
    } else
    {
        pj_str_t ca_file = pj_str(CERT_CA_FILE);
        pj_str_t cert_file = pj_str(CERT_FILE);
        pj_str_t privkey_file = pj_str(CERT_PRIVKEY_FILE);
        pj_str_t privkey_pass = pj_str(CERT_PRIVKEY_PASS);

#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_APPLE)
        /* We store private key in Keychain. */
        privkey_file = pj_str("");
        privkey_pass = pj_str("");
#endif

#if (defined(TEST_LOAD_FROM_FILES) && TEST_LOAD_FROM_FILES==1)

#   if TEST_LOAD_DIRECT && (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL)
        /* Certificate & private key is not loaded from files, but directly
         * using OpenSSL objects.
         */
        status = load_cert_direct(pool, PJ_TRUE, PJ_TRUE, &cert);

        /* Skip setting privkey & certificate files below */
        privkey_file.slen = 0;
        cert_file.slen = 0;
#   endif

        status = pj_ssl_cert_load_from_files(pool, &ca_file, &cert_file, 
                                             &privkey_file, &privkey_pass,
                                             &cert);
#else
        pj_ssl_cert_buffer ca_buf, cert_buf, privkey_buf;

        status = load_cert_to_buf(pool, &ca_file, &ca_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = load_cert_to_buf(pool, &cert_file, &cert_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = load_cert_to_buf(pool, &privkey_file, &privkey_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = pj_ssl_cert_load_from_buffer(pool, &ca_buf, &cert_buf,
                                              &privkey_buf, &privkey_pass, 
                                              &cert);
#endif
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }
    }
#endif

    status = pj_ssl_sock_start_accept(ssock_serv, pool, &addr, pj_sockaddr_get_len(&addr));
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Get listener address */
    {
        pj_ssl_sock_info info;

        pj_ssl_sock_get_info(ssock_serv, &info);
        pj_sockaddr_cp(&listen_addr, &info.local_addr);
    }

    /* === CLIENT === */
    param.proto = cli_proto;
    param.user_data = &state_cli;
    param.ciphers_num = (cli_cipher == -1)? 0 : 1;
    ciphers[0] = cli_cipher;

    state_cli.pool = pool;
    state_cli.check_echo = PJ_TRUE;
    state_cli.is_verbose = PJ_TRUE;
    state_cli.cert_der = CERT_DER_FILE;

    {
        /* srand() should be done centrally (blp)
        pj_time_val now;

        pj_gettimeofday(&now);
        pj_srand((unsigned)now.sec);
        */
        state_cli.send_str_len = (pj_rand() % 5 + 1) * 1024 + pj_rand() % 1024;
    }
    state_cli.send_str = (char*)pj_pool_alloc(pool, state_cli.send_str_len);
    {
        unsigned i;
        for (i = 0; i < state_cli.send_str_len; ++i)
            state_cli.send_str[i] = (char)(pj_rand() % 256);
    }

    /* Verifying the server, below, needs the name its certificate is for */
    param.server_name = pj_str("127.0.0.1");

    status = pj_ssl_sock_create(pool, &param, &ssock_cli);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Set cert for client.
     * Reusing certificate for server above, but if client_provide_cert
     * is not set, override the certificate with CA certificate.
     */
    if (client_cert) {
        status = pj_ssl_sock_set_certificate(ssock_cli, pool, client_cert);
        if (status != PJ_SUCCESS)
            goto on_return;
        state_cli.cert_der = CERT_CLI_DER_FILE;
    } else
#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_SCHANNEL)
    if (client_provide_cert) {
        status = load_cert_from_store(pool, &cert);
        if (status == PJ_SUCCESS)
            status = pj_ssl_sock_set_certificate(ssock_cli, pool, cert);

        if (status != PJ_SUCCESS) {
            goto on_return;
        }
    }
#else
    {
        pj_ssl_cert_t *cli_cert = cert;

        if (!client_provide_cert) {
            pj_str_t ca_file = pj_str(CERT_CA_FILE);
            pj_str_t null_str = pj_str("");
            pj_ssl_cert_direct cert_direct;

#if (defined(TEST_LOAD_FROM_FILES) && TEST_LOAD_FROM_FILES==1)
            /* Reset any certificate & private keys previously set */
            status = pj_ssl_cert_load_from_files(pool, &ca_file, &null_str, 
                                                 &null_str, &null_str,
                                                 &cli_cert);

            /* Also reset any direct backend objects */
            pj_bzero(&cert_direct, sizeof(cert_direct));
            pj_ssl_cert_load_direct(pool, &cert_direct, &cli_cert);
#else
            pj_ssl_cert_buffer null_buf, ca_buf;

            null_buf.slen = 0;

            status = load_cert_to_buf(pool, &ca_file, &ca_buf);
            if (status != PJ_SUCCESS) {
                goto on_return;
            }

            status = pj_ssl_cert_load_from_buffer(pool, &ca_buf, &null_buf,
                                                  &null_buf, &null_str,
                                                  &cli_cert);
#endif
            if (status != PJ_SUCCESS) {
                goto on_return;
            }

        }
#if TEST_CLI_OWN_CERT
        else {
            /* A credential of its own, so each end's local certificate
             * chain differs from the peer's in content as well as storage.
             */
            pj_str_t ca_file = pj_str(CERT_CA_FILE);
            pj_str_t cert_file = pj_str(CERT_CLI_FILE);
            pj_str_t privkey_file = pj_str(CERT_CLI_PRIVKEY_FILE);
            pj_str_t privkey_pass = pj_str(CERT_PRIVKEY_PASS);
            pj_ssl_cert_t *own_cert = NULL;

#if (defined(TEST_LOAD_FROM_FILES) && TEST_LOAD_FROM_FILES==1)
            status = pj_ssl_cert_load_from_files(pool, &ca_file, &cert_file,
                                                 &privkey_file, &privkey_pass,
                                                 &own_cert);
#else
            pj_ssl_cert_buffer ca_buf, cert_buf, privkey_buf;

            status = load_cert_to_buf(pool, &ca_file, &ca_buf);
            if (status == PJ_SUCCESS)
                status = load_cert_to_buf(pool, &cert_file, &cert_buf);
            if (status == PJ_SUCCESS)
                status = load_cert_to_buf(pool, &privkey_file, &privkey_buf);
            if (status == PJ_SUCCESS) {
                status = pj_ssl_cert_load_from_buffer(pool, &ca_buf, &cert_buf,
                                                      &privkey_buf,
                                                      &privkey_pass, &own_cert);
            }
#endif
            if (status != PJ_SUCCESS) {
                goto on_return;
            }

            cli_cert = own_cert;
            state_cli.cert_der = CERT_CLI_DER_FILE;
        }
#endif

        status = pj_ssl_sock_set_certificate(ssock_cli, pool, cli_cert);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }
    }
#endif

    status = pj_ssl_sock_start_connect(ssock_cli, pool, &addr, &listen_addr, pj_sockaddr_get_len(&addr));
    if (status == PJ_SUCCESS) {
        ssl_on_connect_complete(ssock_cli, PJ_SUCCESS);
    } else if (status == PJ_EPENDING) {
        status = PJ_SUCCESS;
    } else {
        goto on_return;
    }

    /* Wait until everything has been sent/received or error */
    while (!state_serv.err && !state_cli.err && !state_serv.done && !state_cli.done)
    {
#ifdef PJ_SYMBIAN
        pj_symbianos_poll(-1, 1000);
#else
        pj_time_val delay = {0, 100};
        pj_ioqueue_poll(ioqueue, &delay);
#endif
    }

    /* Clean up sockets */
    {
        /* The delay must be at least PJ_SSL_SOCK_DELAYED_CLOSE_TIMEOUT. */
        pj_time_val delay = {0, 500};
        while (pj_ioqueue_poll(ioqueue, &delay) > 0);
        pj_timer_heap_poll(timer, &delay);
    }

    if (state_serv.err || state_cli.err) {
        if (state_serv.err != PJ_SUCCESS)
            status = state_serv.err;
        else
            status = state_cli.err;

        goto on_return;
    }

    PJ_LOG(3, ("", "...Done!"));
    PJ_LOG(3, ("", ".....Sent/recv: %lu/%lu bytes", (unsigned long)state_cli.sent,
               (unsigned long)state_cli.recv));

on_return:
    /* Release the reference pj_ssl_cert_load_direct() took. Each socket
     * deep-copied and up-ref'd its own in pj_ssl_sock_set_certificate(), so
     * this drops only the credential's.
     */
#if TEST_LOAD_DIRECT && (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL)
    if (cert)
        pj_ssl_cert_wipe_keys(cert);
#endif

#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_DARWIN) || \
    (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_APPLE)
    if (status != PJ_SUCCESS) {
        PJ_LOG(3, ("", "Apple SSL requires the private key to be "
                       "inside the Keychain. So double click on "
                       "the file pjlib/build/privkey.p12 to "
                       "place it in the Keychain. "
                       "The password is \"pjsip\"."));
    }
#endif

    if (ssock_serv)
        pj_ssl_sock_close(ssock_serv);
    if (state_serv.accepted_st && !state_serv.accepted_st->err &&
        !state_serv.accepted_st->done)
    {
        pj_ssl_sock_close(state_serv.accepted_ssock);
    }
    if (ssock_cli && !state_cli.err && !state_cli.done) 
        pj_ssl_sock_close(ssock_cli);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    if (timer)
        pj_timer_heap_destroy(timer);
    if (pool)
        pj_pool_release(pool);

    return status;
}


static int echo_test(pj_ssl_sock_proto srv_proto, pj_ssl_sock_proto cli_proto,
                     pj_ssl_cipher srv_cipher, pj_ssl_cipher cli_cipher,
                     pj_bool_t req_client_cert, pj_bool_t client_provide_cert)
{
    return echo_test_with_certs(srv_proto, cli_proto, srv_cipher, cli_cipher,
                               req_client_cert, client_provide_cert,
                               PJ_FALSE, NULL, NULL);
}


#if TEST_CERT_BUFFER
static int cert_buffer_test(void)
{
    const char *files[] = { CERT_CA_FILE, CERT_FILE, CERT_PRIVKEY_FILE,
                           CERT_CLI_FILE, CERT_CLI_PRIVKEY_FILE };
    pj_pool_t *pool;
    pj_ssl_cert_buffer buf[PJ_ARRAY_SIZE(files)];
    pj_str_t pass = pj_str(CERT_PRIVKEY_PASS);
    pj_status_t status = PJ_SUCCESS;
    unsigned i, j;

    pool = pj_pool_create(mem, "ssl_cert_buf", 4096, 4096, NULL);
    for (j = 0; j < PJ_ARRAY_SIZE(files); ++j) {
        pj_str_t file = pj_str((char *)files[j]);

        status = load_cert_to_buf(pool, &file, &buf[j]);
        if (status != PJ_SUCCESS)
            goto on_return;
    }

    for (i = 0; i < 2; ++i) {
        pj_ssl_cert_t *server_cert = NULL;
        pj_ssl_cert_t *client_cert = NULL;

        PJ_LOG(3, ("", "..PEM certificate buffers %s NUL",
                   i ? "including" : "excluding"));
        if (i) {
            for (j = 0; j < PJ_ARRAY_SIZE(buf); ++j)
                ++buf[j].slen;
        }

        status = pj_ssl_cert_load_from_buffer(pool, &buf[0], &buf[1],
                                              &buf[2], &pass, &server_cert);
        if (status == PJ_SUCCESS) {
            status = pj_ssl_cert_load_from_buffer(pool, &buf[0], &buf[3],
                                                  &buf[4], &pass, &client_cert);
        }
        if (status == PJ_SUCCESS) {
            status = echo_test_with_certs(PJ_SSL_SOCK_PROTO_TLS1_2,
                                         PJ_SSL_SOCK_PROTO_TLS1_2,
                                         -1, -1, PJ_TRUE, PJ_TRUE, PJ_TRUE,
                                         server_cert, client_cert);
        }
        pj_ssl_cert_wipe_keys(server_cert);
        pj_ssl_cert_wipe_keys(client_cert);
        if (status != PJ_SUCCESS)
            goto on_return;
    }

on_return:
    pj_pool_release(pool);
    return status;
}
#endif


static pj_bool_t asock_on_data_read(pj_activesock_t *asock,
                                    void *data,
                                    pj_size_t size,
                                    pj_status_t status,
                                    pj_size_t *remainder)
{
    struct test_state *st = (struct test_state*)
                             pj_activesock_get_user_data(asock);

    PJ_UNUSED_ARG(data);
    PJ_UNUSED_ARG(size);
    PJ_UNUSED_ARG(remainder);

    if (status != PJ_SUCCESS) {
        if (status == PJ_EEOF) {
            status = PJ_SUCCESS;
            st->done = PJ_TRUE;
        } else {
            app_perror("...ERROR asock_on_data_read()", status);
        }
    }

    st->err = status;

    if (st->err != PJ_SUCCESS || st->done) {
        pj_activesock_close(asock);
        if (!st->is_server)
            clients_num--;
        return PJ_FALSE;
    }

    return PJ_TRUE;
}


static pj_bool_t asock_on_connect_complete(pj_activesock_t *asock,
                                           pj_status_t status)
{
    struct test_state *st = (struct test_state*)
                             pj_activesock_get_user_data(asock);

    if (status == PJ_SUCCESS) {
        void *read_buf[1];

        /* Start reading data */
        read_buf[0] = st->read_buf;
        status = pj_activesock_start_read2(asock, st->pool, sizeof(st->read_buf), (void**)read_buf, 0);
        if (status != PJ_SUCCESS) {
            app_perror("...ERROR pj_ssl_sock_start_read2()", status);
        }
    }

    st->err = status;

    if (st->err != PJ_SUCCESS) {
        pj_activesock_close(asock);
        if (!st->is_server)
            clients_num--;
        return PJ_FALSE;
    }

    return PJ_TRUE;
}

static pj_bool_t asock_on_accept_complete(pj_activesock_t *asock,
                                          pj_sock_t newsock,
                                          const pj_sockaddr_t *src_addr,
                                          int src_addr_len)
{
    struct test_state *st;
    void *read_buf[1];
    pj_activesock_t *new_asock;
    pj_activesock_cb asock_cb = { 0 };
    pj_status_t status;

    PJ_UNUSED_ARG(src_addr);
    PJ_UNUSED_ARG(src_addr_len);

    st = (struct test_state*) pj_activesock_get_user_data(asock);

    asock_cb.on_data_read = &asock_on_data_read;
    status = pj_activesock_create(st->pool, newsock, pj_SOCK_STREAM(), NULL, 
                                  st->ioqueue, &asock_cb, st, &new_asock);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Start reading data */
    read_buf[0] = st->read_buf;
    status = pj_activesock_start_read2(new_asock, st->pool, 
                                       sizeof(st->read_buf), 
                                       (void**)read_buf, 0);
    if (status != PJ_SUCCESS) {
        app_perror("...ERROR pj_ssl_sock_start_read2()", status);
    }

on_return:
    st->err = status;

    if (st->err != PJ_SUCCESS)
        pj_activesock_close(new_asock);

    return PJ_TRUE;
}


/* Raw TCP socket try to connect to SSL socket server, once
 * connection established, it will just do nothing, SSL socket
 * server should be able to close the connection after specified
 * timeout period (set ms_timeout to 0 to disable timer).
 */
static int client_non_ssl(unsigned ms_timeout)
{
    pj_pool_t *pool = NULL;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_ssl_sock_t *ssock_serv = NULL;
    pj_activesock_t *asock_cli = NULL;
    pj_activesock_cb asock_cb = { 0 };
    pj_sock_t sock = PJ_INVALID_SOCKET;
    pj_ssl_sock_param param;
    struct test_state state_serv = { 0 };
    struct test_state state_cli = { 0 };
    pj_sockaddr listen_addr;
    pj_ssl_cert_t *cert = NULL;
    pj_status_t status;

    pool = pj_pool_create(mem, "ssl_accept_raw_tcp", 256, 256, NULL);

    status = pj_ioqueue_create(pool, 4, &ioqueue);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    status = pj_timer_heap_create(pool, 4, &timer);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    pj_ssl_sock_param_default(&param);
    param.cb.on_accept_complete2 = &ssl_on_accept_complete;
    param.cb.on_data_read = &ssl_on_data_read;
    param.cb.on_data_sent = &ssl_on_data_sent;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;
    param.timeout.sec = 0;
    param.timeout.msec = ms_timeout;
    pj_time_val_normalize(&param.timeout);

    /* SERVER */
    param.user_data = &state_serv;
    state_serv.pool = pool;
    state_serv.is_server = PJ_TRUE;
    state_serv.is_verbose = PJ_TRUE;

    status = pj_ssl_sock_create(pool, &param, &ssock_serv);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Set cert */
#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_SCHANNEL)
    /* Schannel backend currently can only load certificates from
     * OS cert store. If the certificate loading fails, we'll skip setting
     * certificate, so the SSL socket will create & use a self-signed cert.
     */
    status = load_cert_from_store(pool, &cert);
    if (status == PJ_SUCCESS) {
        status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }
    }
#else
    {
        pj_str_t ca_file = pj_str(CERT_CA_FILE);
        pj_str_t cert_file = pj_str(CERT_FILE);
        pj_str_t privkey_file = pj_str(CERT_PRIVKEY_FILE);
        pj_str_t privkey_pass = pj_str(CERT_PRIVKEY_PASS);

#if (defined(TEST_LOAD_FROM_FILES) && TEST_LOAD_FROM_FILES==1)
        status = pj_ssl_cert_load_from_files(pool, &ca_file, &cert_file, 
                                             &privkey_file, &privkey_pass,
                                             &cert);
#else
        pj_ssl_cert_buffer ca_buf, cert_buf, privkey_buf;

        status = load_cert_to_buf(pool, &ca_file, &ca_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = load_cert_to_buf(pool, &cert_file, &cert_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = load_cert_to_buf(pool, &privkey_file, &privkey_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = pj_ssl_cert_load_from_buffer(pool, &ca_buf, &cert_buf,
                                              &privkey_buf, &privkey_pass, 
                                              &cert);
#endif
        if (status != PJ_SUCCESS) {
            goto on_return;
        }
    }

    status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }
#endif

    /* Init bind address */
    {
        pj_str_t tmp_st;
        pj_sockaddr_init(PJ_AF_INET, &listen_addr, pj_strset2(&tmp_st, "127.0.0.1"), 0);
    }

    status = pj_ssl_sock_start_accept(ssock_serv, pool, &listen_addr, pj_sockaddr_get_len(&listen_addr));
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Update listener address */
    {
        pj_ssl_sock_info info;

        pj_ssl_sock_get_info(ssock_serv, &info);
        pj_sockaddr_cp(&listen_addr, &info.local_addr);
    }

    /* CLIENT */
    state_cli.pool = pool;
    status = pj_sock_socket(pj_AF_INET(), pj_SOCK_STREAM(), 0, &sock);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    asock_cb.on_connect_complete = &asock_on_connect_complete;
    asock_cb.on_data_read = &asock_on_data_read;
    status = pj_activesock_create(pool, sock, pj_SOCK_STREAM(), NULL, 
                                  ioqueue, &asock_cb, &state_cli, &asock_cli);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    status = pj_activesock_start_connect(asock_cli, pool, (pj_sockaddr_t*)&listen_addr, 
                                         pj_sockaddr_get_len(&listen_addr));
    if (status == PJ_SUCCESS) {
        asock_on_connect_complete(asock_cli, PJ_SUCCESS);
    } else if (status == PJ_EPENDING) {
        status = PJ_SUCCESS;
    } else {
        goto on_return;
    }

    /* Wait until everything has been sent/received or error */
    while (!state_serv.err && !state_cli.err && !state_serv.done && !state_cli.done)
    {
#ifdef PJ_SYMBIAN
        pj_symbianos_poll(-1, 1000);
#else
        pj_time_val delay = {0, 100};
        pj_ioqueue_poll(ioqueue, &delay);
        pj_timer_heap_poll(timer, &delay);
#endif
    }

    if (state_serv.err || state_cli.err) {
        if (state_serv.err != PJ_SUCCESS)
            status = state_serv.err;
        else
            status = state_cli.err;

        goto on_return;
    }

    PJ_LOG(3, ("", "...Done!"));

on_return:
    if (asock_cli && !state_cli.err && !state_cli.done)
        pj_activesock_close(asock_cli);
    if (state_serv.accepted_ssock)
        pj_ssl_sock_close(state_serv.accepted_ssock);
    if (ssock_serv)
        pj_ssl_sock_close(ssock_serv);

    /* Poll to let deferred socket destruction complete */
    if (ioqueue) {
        pj_time_val delay = {0, 500};
        int n = 50;
        while (n-- > 0 && pj_ioqueue_poll(ioqueue, &delay) > 0)
            ;
    }

    /* The accepted socket whose handshake failed is closed by a timer
     * (PJ_SSL_SOCK_DELAYED_CLOSE_TIMEOUT), wait until it has run.
     */
    if (timer) {
        pj_time_val deadline, now;

        pj_gettickcount(&deadline);
        deadline.sec += 5;
        while (ioqueue && pj_timer_heap_count(timer) > 0) {
            pj_time_val delay = {0, 100};

            pj_gettickcount(&now);
            if (PJ_TIME_VAL_GTE(now, deadline))
                break;
            pj_ioqueue_poll(ioqueue, &delay);
            pj_timer_heap_poll(timer, NULL);
        }
        pj_timer_heap_destroy(timer);
    }
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    if (pool)
        pj_pool_release(pool);

    return status;
}


/* SSL socket try to connect to raw TCP socket server, once
 * connection established, SSL socket will try to perform SSL
 * handshake. SSL client socket should be able to close the
 * connection after specified timeout period (set ms_timeout to 
 * 0 to disable timer).
 */
static int server_non_ssl(unsigned ms_timeout)
{
    pj_pool_t *pool = NULL;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_activesock_t *asock_serv = NULL;
    pj_ssl_sock_t *ssock_cli = NULL;
    pj_activesock_cb asock_cb = { 0 };
    pj_sock_t sock = PJ_INVALID_SOCKET;
    pj_ssl_sock_param param;
    struct test_state state_serv = { 0 };
    struct test_state state_cli = { 0 };
    pj_sockaddr addr, listen_addr;
    pj_status_t status;

    pool = pj_pool_create(mem, "ssl_connect_raw_tcp", 256, 256, NULL);

    status = pj_ioqueue_create(pool, 4, &ioqueue);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    status = pj_timer_heap_create(pool, 4, &timer);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* SERVER */
    state_serv.pool = pool;
    state_serv.ioqueue = ioqueue;

    status = pj_sock_socket(pj_AF_INET(), pj_SOCK_STREAM(), 0, &sock);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Init bind address */
    {
        pj_str_t tmp_st;
        pj_sockaddr_init(PJ_AF_INET, &listen_addr, pj_strset2(&tmp_st, "127.0.0.1"), 0);
    }

    status = pj_sock_bind(sock, (pj_sockaddr_t*)&listen_addr, 
                          pj_sockaddr_get_len((pj_sockaddr_t*)&listen_addr));
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    status = pj_sock_listen(sock, PJ_SOMAXCONN);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    asock_cb.on_accept_complete = &asock_on_accept_complete;
    status = pj_activesock_create(pool, sock, pj_SOCK_STREAM(), NULL, 
                                  ioqueue, &asock_cb, &state_serv, &asock_serv);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    status = pj_activesock_start_accept(asock_serv, pool);
    if (status != PJ_SUCCESS)
        goto on_return;

    /* Update listener address */
    {
        int addr_len;

        addr_len = sizeof(listen_addr);
        pj_sock_getsockname(sock, (pj_sockaddr_t*)&listen_addr, &addr_len);
    }

    /* CLIENT */
    pj_ssl_sock_param_default(&param);
    param.cb.on_connect_complete = &ssl_on_connect_complete;
    param.cb.on_data_read = &ssl_on_data_read;
    param.cb.on_data_sent = &ssl_on_data_sent;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;
    param.timeout.sec = 0;
    param.timeout.msec = ms_timeout;
    pj_time_val_normalize(&param.timeout);
    param.user_data = &state_cli;

    state_cli.pool = pool;
    state_cli.is_server = PJ_FALSE;
    state_cli.is_verbose = PJ_TRUE;

    status = pj_ssl_sock_create(pool, &param, &ssock_cli);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Init default bind address */
    {
        pj_str_t tmp_st;
        pj_sockaddr_init(PJ_AF_INET, &addr, pj_strset2(&tmp_st, "127.0.0.1"), 0);
    }

    status = pj_ssl_sock_start_connect(ssock_cli, pool, 
                                       (pj_sockaddr_t*)&addr, 
                                       (pj_sockaddr_t*)&listen_addr, 
                                       pj_sockaddr_get_len(&listen_addr));
    if (status != PJ_EPENDING) {
        goto on_return;
    }

    /* Wait until everything has been sent/received or error */
    while ((!state_serv.err && !state_serv.done) || (!state_cli.err && !state_cli.done))
    {
#ifdef PJ_SYMBIAN
        pj_symbianos_poll(-1, 1000);
#else
        pj_time_val delay = {0, 100};
        pj_ioqueue_poll(ioqueue, &delay);
        pj_timer_heap_poll(timer, &delay);
#endif
    }

    if (state_serv.err || state_cli.err) {
        if (state_cli.err != PJ_SUCCESS)
            status = state_cli.err;
        else
            status = state_serv.err;

        goto on_return;
    }

    PJ_LOG(3, ("", "...Done!"));

on_return:
    if (asock_serv) {
        pj_activesock_close(asock_serv);
    } else if (sock != PJ_INVALID_SOCKET) {
        pj_sock_close(sock);
    }
    if (ssock_cli && !state_cli.err && !state_cli.done)
        pj_ssl_sock_close(ssock_cli);
    if (timer)
        pj_timer_heap_destroy(timer);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    if (pool)
        pj_pool_release(pool);

    return status;
}


#if WITH_BENCHMARK
/* Test will perform multiple clients trying to connect to single server.
 * Once SSL connection established, echo test will be performed.
 */
static int perf_test(unsigned clients, unsigned ms_handshake_timeout)
{
    pj_pool_t *pool = NULL;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_ssl_sock_t *ssock_serv = NULL;
    pj_ssl_sock_t **ssock_cli = NULL;
    pj_ssl_sock_param param;
    struct test_state state_serv = { 0 };
    struct test_state *state_cli = NULL;
    pj_sockaddr addr, listen_addr;
    pj_ssl_cert_t *cert = NULL;
    pj_status_t status;
    unsigned i, cli_err = 0;
    pj_size_t tot_sent = 0, tot_recv = 0;
    pj_time_val start;

    pool = pj_pool_create(mem, "ssl_perf", 256, 256, NULL);

    status = pj_ioqueue_create(pool, PJ_IOQUEUE_MAX_HANDLES, &ioqueue);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    status = pj_timer_heap_create(pool, PJ_IOQUEUE_MAX_HANDLES, &timer);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    pj_ssl_sock_param_default(&param);
    param.cb.on_accept_complete2 = &ssl_on_accept_complete;
    param.cb.on_connect_complete = &ssl_on_connect_complete;
    param.cb.on_data_read = &ssl_on_data_read;
    param.cb.on_data_sent = &ssl_on_data_sent;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;
    param.timeout.sec = 0;
    param.timeout.msec = ms_handshake_timeout;
    pj_time_val_normalize(&param.timeout);

    /* Init default bind address */
    {
        pj_str_t tmp_st;
        pj_sockaddr_init(PJ_AF_INET, &addr, pj_strset2(&tmp_st, "127.0.0.1"), 0);
    }

    /* SERVER */
    param.user_data = &state_serv;

    state_serv.pool = pool;
    state_serv.echo = PJ_TRUE;
    state_serv.is_server = PJ_TRUE;

    status = pj_ssl_sock_create(pool, &param, &ssock_serv);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Set cert */
#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_SCHANNEL)
    /* Schannel backend currently can only load certificates from
     * OS cert store. If the certificate loading fails, we'll skip setting
     * certificate, so the SSL socket will create & use a self-signed cert.
     */
    status = load_cert_from_store(pool, &cert);
    if (status == PJ_SUCCESS) {
        status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }
    }
#else
    {
        pj_str_t ca_file = pj_str(CERT_CA_FILE);
        pj_str_t cert_file = pj_str(CERT_FILE);
        pj_str_t privkey_file = pj_str(CERT_PRIVKEY_FILE);
        pj_str_t privkey_pass = pj_str(CERT_PRIVKEY_PASS);

#if (defined(TEST_LOAD_FROM_FILES) && TEST_LOAD_FROM_FILES==1)

#   if TEST_LOAD_DIRECT && (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL)
        /* Certificate & private key is not loaded from files, but directly
         * using OpenSSL objects.
         */
        status = load_cert_direct(pool, PJ_TRUE, PJ_TRUE, &cert);

        /* Skip setting privkey & certificate files below */
        privkey_file.slen = 0;
        cert_file.slen = 0;
#   endif

        status = pj_ssl_cert_load_from_files(pool, &ca_file, &cert_file, 
                                             &privkey_file, &privkey_pass,
                                             &cert);
#else
        pj_ssl_cert_buffer ca_buf, cert_buf, privkey_buf;

        status = load_cert_to_buf(pool, &ca_file, &ca_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = load_cert_to_buf(pool, &cert_file, &cert_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = load_cert_to_buf(pool, &privkey_file, &privkey_buf);
        if (status != PJ_SUCCESS) {
            goto on_return;
        }

        status = pj_ssl_cert_load_from_buffer(pool, &ca_buf, &cert_buf,
                                              &privkey_buf, &privkey_pass, 
                                              &cert);
#endif
        if (status != PJ_SUCCESS) {
            goto on_return;
        }
    }

    status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
    if (status != PJ_SUCCESS) {
        goto on_return;
    }
#endif

    status = pj_ssl_sock_start_accept(ssock_serv, pool, &addr, pj_sockaddr_get_len(&addr));
    if (status != PJ_SUCCESS) {
        goto on_return;
    }

    /* Get listening address for clients to connect to */
    {
        pj_ssl_sock_info info;
        char buf[64];

        pj_ssl_sock_get_info(ssock_serv, &info);
        pj_sockaddr_cp(&listen_addr, &info.local_addr);

        pj_sockaddr_print((pj_sockaddr_t*)&listen_addr, buf, sizeof(buf), 1);
        PJ_LOG(3, ("", "...Listener ready at %s", buf));
    }


    /* CLIENTS */
    clients_num = clients;
    param.timeout.sec = 0;
    param.timeout.msec = 0;

    /* Allocate SSL socket pointers and test state */
    ssock_cli = (pj_ssl_sock_t**)pj_pool_calloc(pool, clients, sizeof(pj_ssl_sock_t*));
    state_cli = (struct test_state*)pj_pool_calloc(pool, clients, sizeof(struct test_state));

    /* Get start timestamp */
    pj_gettimeofday(&start);

    /* Setup clients */
    for (i = 0; i < clients; ++i) {
        param.user_data = &state_cli[i];

        state_cli[i].pool = pool;
        state_cli[i].check_echo = PJ_TRUE;
        state_cli[i].send_str_len = (pj_rand() % 5 + 1) * 1024 + pj_rand() % 1024;
        state_cli[i].send_str = (char*)pj_pool_alloc(pool, state_cli[i].send_str_len);
        {
            unsigned j;
            for (j = 0; j < state_cli[i].send_str_len; ++j)
                state_cli[i].send_str[j] = (char)(pj_rand() % 256);
        }

        status = pj_ssl_sock_create(pool, &param, &ssock_cli[i]);
        if (status != PJ_SUCCESS) {
            app_perror("...ERROR pj_ssl_sock_create()", status);
            cli_err++;
            clients_num--;
            continue;
        }

        status = pj_ssl_sock_start_connect(ssock_cli[i], pool, &addr, &listen_addr, pj_sockaddr_get_len(&addr));
        if (status == PJ_SUCCESS) {
            ssl_on_connect_complete(ssock_cli[i], PJ_SUCCESS);
        } else if (status == PJ_EPENDING) {
            status = PJ_SUCCESS;
        } else {
            app_perror("...ERROR pj_ssl_sock_create()", status);
            pj_ssl_sock_close(ssock_cli[i]);
            ssock_cli[i] = NULL;
            clients_num--;
            cli_err++;
            continue;
        }

        /* Give chance to server to accept this client */
        {
            unsigned n = 5;

#ifdef PJ_SYMBIAN
            while(n && pj_symbianos_poll(-1, 1000))
                n--;
#else
            pj_time_val delay = {0, 100};
            while(n && pj_ioqueue_poll(ioqueue, &delay) > 0)
                n--;
#endif
        }
    }

    /* Wait until everything has been sent/received or error */
    while (clients_num)
    {
#ifdef PJ_SYMBIAN
        pj_symbianos_poll(-1, 1000);
#else
        pj_time_val delay = {0, 100};
        pj_ioqueue_poll(ioqueue, &delay);
        pj_timer_heap_poll(timer, &delay);
#endif
    }

    /* Clean up sockets */
    {
        pj_time_val delay = {0, 500};
        while (pj_ioqueue_poll(ioqueue, &delay) > 0);
    }

    if (state_serv.err != PJ_SUCCESS) {
        status = state_serv.err;
        goto on_return;
    }

    PJ_LOG(3, ("", "...Done!"));

    /* SSL setup and data transfer duration */
    {
        pj_time_val stop;
        
        pj_gettimeofday(&stop);
        PJ_TIME_VAL_SUB(stop, start);

        PJ_LOG(3, ("", ".....Setup & data transfer duration: %ld.%03lds", stop.sec, stop.msec));
    }

    /* Check clients status */
    for (i = 0; i < clients; ++i) {
        if (state_cli[i].err != PJ_SUCCESS)
            cli_err++;

        tot_sent += state_cli[i].sent;
        tot_recv += state_cli[i].recv;
    }

    PJ_LOG(3, ("", ".....Clients: %d (%d errors)", clients, cli_err));
    PJ_LOG(3, ("", ".....Total sent/recv: %lu/%lu bytes",
               (unsigned long)tot_sent, (unsigned long)tot_recv));

on_return:
    /* Release the reference pj_ssl_cert_load_direct() took. Each socket
     * deep-copied and up-ref'd its own in pj_ssl_sock_set_certificate(), so
     * this drops only the credential's.
     */
#if TEST_LOAD_DIRECT && (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL)
    if (cert)
        pj_ssl_cert_wipe_keys(cert);
#endif

    if (ssock_serv) 
        pj_ssl_sock_close(ssock_serv);

    if (ssock_cli && state_cli) {
        for (i = 0; i < clients; ++i) {
            if (ssock_cli[i] && !state_cli[i].err && !state_cli[i].done)
                pj_ssl_sock_close(ssock_cli[i]);
        }
    }
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    if (pool)
        pj_pool_release(pool);

    return status;
}
#endif

/* Stress tests (send_load, close_pending, bidir, mt_send_load) are in
 * ssl_sock_stress.c, registered as ssl_sock_stress_test().
 */


/*
 * Large message test: send 64KB data (multiple TLS records),
 * verify byte-for-byte echo. Uses dedicated state/callbacks with
 * larger buffers than the echo_test infrastructure.
 */
#define LARGE_MSG_SIZE      (64 * 1024)
#define LARGE_MSG_BUF_SIZE  8192

struct large_msg_state
{
    pj_pool_t          *pool;
    pj_ssl_sock_t      *accepted_ssock;
    pj_bool_t           is_server;
    pj_bool_t           echo;
    pj_status_t         err;
    pj_size_t           sent;
    pj_size_t           recv;
    pj_uint8_t          read_buf[LARGE_MSG_BUF_SIZE];
    pj_bool_t           done;
    char               *send_str;
    pj_size_t           send_str_len;
    const char         *check_echo_ptr;
    pj_ioqueue_op_key_t send_key;
};

static pj_bool_t lm_on_connect_complete(pj_ssl_sock_t *ssock,
                                        pj_status_t status)
{
    struct large_msg_state *st = (struct large_msg_state *)
                                  pj_ssl_sock_get_user_data(ssock);
    void *read_buf[1];

    if (status != PJ_SUCCESS) {
        st->err = status;
        return PJ_FALSE;
    }

    read_buf[0] = st->read_buf;
    status = pj_ssl_sock_start_read2(ssock, st->pool,
                                     sizeof(st->read_buf),
                                     (void **)read_buf, 0);
    if (status != PJ_SUCCESS) {
        st->err = status;
        return PJ_FALSE;
    }

    /* Start sending */
    while (st->sent < st->send_str_len) {
        pj_ssize_t size = st->send_str_len - st->sent;

        status = pj_ssl_sock_send(ssock, &st->send_key,
                                  st->send_str + st->sent, &size, 0);
        if (status == PJ_SUCCESS) {
            st->sent += size;
        } else {
            if (status != PJ_EPENDING)
                st->err = status;
            break;
        }
    }

    return (st->err == PJ_SUCCESS) ? PJ_TRUE : PJ_FALSE;
}

static pj_bool_t lm_on_accept_complete(pj_ssl_sock_t *ssock,
                                       pj_ssl_sock_t *newsock,
                                       const pj_sockaddr_t *src_addr,
                                       int src_addr_len,
                                       pj_status_t accept_status)
{
    struct large_msg_state *parent_st = (struct large_msg_state *)
                                         pj_ssl_sock_get_user_data(ssock);
    struct large_msg_state *st;
    void *read_buf[1];
    pj_status_t status;

    PJ_UNUSED_ARG(src_addr);
    PJ_UNUSED_ARG(src_addr_len);

    if (accept_status != PJ_SUCCESS)
        return PJ_FALSE;

    st = (struct large_msg_state *)pj_pool_zalloc(parent_st->pool,
                                        sizeof(struct large_msg_state));
    *st = *parent_st;
    st->sent = 0;
    st->recv = 0;
    st->done = PJ_FALSE;
    st->err = PJ_SUCCESS;
    pj_ssl_sock_set_user_data(newsock, st);

    /* Track accepted socket for cleanup */
    parent_st->accepted_ssock = newsock;

    read_buf[0] = st->read_buf;
    status = pj_ssl_sock_start_read2(newsock, st->pool,
                                     sizeof(st->read_buf),
                                     (void **)read_buf, 0);
    if (status != PJ_SUCCESS) {
        st->err = status;
        return PJ_FALSE;
    }

    return PJ_TRUE;
}

static pj_bool_t lm_on_data_read(pj_ssl_sock_t *ssock,
                                  void *data,
                                  pj_size_t size,
                                  pj_status_t status,
                                  pj_size_t *remainder)
{
    struct large_msg_state *st = (struct large_msg_state *)
                                  pj_ssl_sock_get_user_data(ssock);

    if (remainder)
        *remainder = 0;

    if (size > 0) {
        st->recv += size;

        /* Server: echo data back */
        if (st->echo) {
            pj_ssize_t sz = (pj_ssize_t)size;
            pj_status_t s;

            s = pj_ssl_sock_send(ssock, &st->send_key, data, &sz, 0);
            if (s == PJ_SUCCESS)
                st->sent += sz;
            else if (s != PJ_EPENDING)
                st->err = s;
        }

        /* Client: verify echoed data byte-for-byte */
        if (st->check_echo_ptr) {
            if (pj_memcmp(st->check_echo_ptr, data, size)) {
                PJ_LOG(1, ("", "...ERROR echoed data mismatch at "
                           "offset %lu",
                           (unsigned long)(st->check_echo_ptr -
                                           st->send_str)));
                st->err = PJ_EINVAL;
            }
            st->check_echo_ptr += size;

            if (st->recv >= st->send_str_len)
                st->done = PJ_TRUE;
        }
    }

    if (status != PJ_SUCCESS) {
        if (status == PJ_EEOF)
            st->done = PJ_TRUE;
        else
            st->err = status;
    }

    if (st->err != PJ_SUCCESS || st->done)
        return PJ_FALSE;

    return PJ_TRUE;
}

static pj_bool_t lm_on_data_sent(pj_ssl_sock_t *ssock,
                                  pj_ioqueue_op_key_t *op_key,
                                  pj_ssize_t sent)
{
    struct large_msg_state *st = (struct large_msg_state *)
                                  pj_ssl_sock_get_user_data(ssock);
    PJ_UNUSED_ARG(op_key);

    if (sent < 0) {
        st->err = (pj_status_t)-sent;
        return PJ_FALSE;
    }

    st->sent += sent;

    /* Client: continue sending remaining data */
    if (st->send_str && st->sent < st->send_str_len) {
        while (st->sent < st->send_str_len) {
            pj_ssize_t size = st->send_str_len - st->sent;
            pj_status_t s;

            s = pj_ssl_sock_send(ssock, &st->send_key,
                                 st->send_str + st->sent, &size, 0);
            if (s == PJ_SUCCESS) {
                st->sent += size;
            } else {
                if (s != PJ_EPENDING)
                    st->err = s;
                break;
            }
        }
    }

    return (st->err == PJ_SUCCESS) ? PJ_TRUE : PJ_FALSE;
}

static int large_msg_test(void)
{
    pj_pool_t *pool = NULL;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_ssl_sock_t *ssock_serv = NULL;
    pj_ssl_sock_t *ssock_cli = NULL;
    pj_ssl_sock_param param;
    struct large_msg_state state_serv;
    struct large_msg_state state_cli;
    pj_sockaddr addr, listen_addr;
    pj_status_t status;
    char *large_buf;
    int i;

    pool = pj_pool_create(mem, "ssl_large", 256000, 4096, NULL);

    pj_bzero(&state_serv, sizeof(state_serv));
    pj_bzero(&state_cli, sizeof(state_cli));

    status = pj_ioqueue_create(pool, 4, &ioqueue);
    if (status != PJ_SUCCESS) {
        app_perror("...large_msg_test: ioqueue create", status);
        goto on_return;
    }

    status = pj_timer_heap_create(pool, 4, &timer);
    if (status != PJ_SUCCESS) {
        app_perror("...large_msg_test: timer create", status);
        goto on_return;
    }

    pj_ssl_sock_param_default(&param);
    param.cb.on_accept_complete2 = &lm_on_accept_complete;
    param.cb.on_connect_complete = &lm_on_connect_complete;
    param.cb.on_data_read = &lm_on_data_read;
    param.cb.on_data_sent = &lm_on_data_sent;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;
    param.proto = PJ_SSL_SOCK_PROTO_TLS1_2;
    param.ciphers_num = 0;

    {
        pj_str_t tmp_st;
        pj_sockaddr_init(PJ_AF_INET, &addr,
                         pj_strset2(&tmp_st, "127.0.0.1"), 0);
    }

    /* Fill send data with deterministic pattern */
    large_buf = (char *)pj_pool_alloc(pool, LARGE_MSG_SIZE);
    for (i = 0; i < LARGE_MSG_SIZE; i++)
        large_buf[i] = (char)(i & 0xFF);

    /* SERVER */
    state_serv.pool = pool;
    state_serv.echo = PJ_TRUE;
    state_serv.is_server = PJ_TRUE;
    param.user_data = &state_serv;
    param.require_client_cert = PJ_FALSE;

    listen_addr = addr;
    status = ssl_test_create_server(pool, &param, "large_msg_test",
                                    &ssock_serv, &listen_addr);
    if (status != PJ_SUCCESS)
        goto on_return;

    /* CLIENT */
    state_cli.pool = pool;
    state_cli.is_server = PJ_FALSE;
    state_cli.send_str = large_buf;
    state_cli.send_str_len = LARGE_MSG_SIZE;
    state_cli.check_echo_ptr = large_buf;
    param.user_data = &state_cli;

    status = pj_ssl_sock_create(pool, &param, &ssock_cli);
    if (status != PJ_SUCCESS) {
        app_perror("...large_msg_test: client create", status);
        goto on_return;
    }

    status = pj_ssl_sock_start_connect(ssock_cli, pool, &addr,
                                       &listen_addr,
                                       pj_sockaddr_get_len(&addr));
    if (status == PJ_SUCCESS) {
        lm_on_connect_complete(ssock_cli, PJ_SUCCESS);
    } else if (status != PJ_EPENDING) {
        app_perror("...large_msg_test: connect", status);
        goto on_return;
    }

    /* Poll until done */
    {
        pj_timestamp t_start, t_now;
        pj_uint32_t elapsed;

        pj_get_timestamp(&t_start);
        while (!state_cli.err && !state_cli.done) {
            pj_time_val delay = {0, 100};
            pj_ioqueue_poll(ioqueue, &delay);
            pj_timer_heap_poll(timer, NULL);

            pj_get_timestamp(&t_now);
            elapsed = pj_elapsed_msec(&t_start, &t_now);
            if (elapsed > 30000) {
                PJ_LOG(1, ("", "...large_msg_test TIMEOUT after 30s"));
                status = PJ_ETIMEDOUT;
                goto on_return;
            }
        }
    }

    if (state_cli.err) {
        status = state_cli.err;
        app_perror("...large_msg_test client error", status);
        goto on_return;
    }

    PJ_LOG(3, ("", "...large_msg_test: sent=%lu, recv=%lu",
               (unsigned long)state_cli.sent,
               (unsigned long)state_cli.recv));

    if (state_cli.recv < (pj_size_t)LARGE_MSG_SIZE) {
        PJ_LOG(1, ("", "...large_msg_test: recv=%lu < expected=%d",
                   (unsigned long)state_cli.recv, LARGE_MSG_SIZE));
        status = PJ_EINVAL;
        goto on_return;
    }

    status = PJ_SUCCESS;

on_return:
    if (ssock_cli)
        pj_ssl_sock_close(ssock_cli);
    if (state_serv.accepted_ssock)
        pj_ssl_sock_close(state_serv.accepted_ssock);
    if (ssock_serv)
        pj_ssl_sock_close(ssock_serv);

    /* Poll to drain pending events after close */
    if (ioqueue) {
        pj_time_val delay = {0, 500};
        int n = 50;
        while (n-- > 0 && pj_ioqueue_poll(ioqueue, &delay) > 0)
            ;
    }

    if (timer)
        pj_timer_heap_destroy(timer);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    if (pool)
        pj_pool_release(pool);

    return (status == PJ_SUCCESS) ? 0 : -1;
}



/*
 * TLS session resumption test (OpenSSL backend). Opens a server, then makes
 * two client connections to it with session reuse enabled. The first
 * connection must perform a full handshake; the second must resume the
 * cached session if 'expect_reuse'.
 *
 * With REUSE_SAME and REUSE_UNTRUSTED, both clients have the same settings
 * and the server requires a client certificate:
 * - REUSE_SAME: both ends have the CA list and must report no verification
 *   error on either connection;
 * - REUSE_UNTRUSTED: neither end trusts the other's certificate, and a
 *   resumed connection must report the same verification failure as the
 *   full handshake.
 *
 * With any other 'mode', the second client must not resume the first one's
 * session:
 * - REUSE_CA_FILE: only the first client has the CA list, and the second
 *   must report the server certificate as untrusted;
 * - REUSE_CA_PATH: the clients have different CA directories;
 * - REUSE_VERIFY_CB: both clients have a verification callback;
 * - REUSE_CLI_KEY: both clients have the same client certificate, but only
 *   the first has its private key.
 */
#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL)

enum reuse_mode
{
    REUSE_SAME,
    REUSE_UNTRUSTED,
    REUSE_CA_FILE,
    REUSE_CA_PATH,
    REUSE_VERIFY_CB,
    REUSE_CLI_KEY
};

static const char reuse_greeting[] = "hello";

struct reuse_state
{
    pj_pool_t      *pool;
    pj_bool_t       is_server;
    pj_bool_t       done;           /* client round completed              */
    pj_bool_t       closed;         /* client: closed in a callback        */
    pj_status_t     err;
    pj_bool_t       reused;         /* client: was the session resumed     */
    pj_uint32_t     verify_status;  /* client: server cert verify status   */
    unsigned        acc_cnt;        /* listener: accepted connections      */
    pj_bool_t       acc_reused[2];  /* listener: per-connection resumption */
    pj_uint32_t     acc_verify[2];  /* listener: client cert verify status */
    pj_uint8_t      read_buf[128];
    struct send_key send_key;
};

static pj_bool_t reuse_on_accept(pj_ssl_sock_t *ssock,
                                 pj_ssl_sock_t *newsock,
                                 const pj_sockaddr_t *src_addr,
                                 int src_addr_len,
                                 pj_status_t accept_status)
{
    struct reuse_state *parent_st = (struct reuse_state*)
                                    pj_ssl_sock_get_user_data(ssock);
    struct reuse_state *st;
    pj_ssl_sock_info info;
    void *read_buf[1];
    pj_ssize_t len;
    pj_status_t status;

    PJ_UNUSED_ARG(src_addr);
    PJ_UNUSED_ARG(src_addr_len);

    if (accept_status != PJ_SUCCESS)
        return PJ_TRUE;             /* keep listening */

    if (parent_st->acc_cnt < PJ_ARRAY_SIZE(parent_st->acc_reused) &&
        pj_ssl_sock_get_info(newsock, &info) == PJ_SUCCESS)
    {
        parent_st->acc_reused[parent_st->acc_cnt] = info.session_reused;
        parent_st->acc_verify[parent_st->acc_cnt] = info.verify_status;
    }
    parent_st->acc_cnt++;

    st = (struct reuse_state*) pj_pool_zalloc(parent_st->pool, sizeof(*st));
    st->pool = parent_st->pool;
    st->is_server = PJ_TRUE;
    pj_ssl_sock_set_user_data(newsock, st);

    /* Read so we notice the client closing (EOF). */
    read_buf[0] = st->read_buf;
    status = pj_ssl_sock_start_read2(newsock, st->pool, sizeof(st->read_buf),
                                     read_buf, 0);
    if (status != PJ_SUCCESS) {
        pj_ssl_sock_close(newsock);
        return PJ_TRUE;
    }

    /* Send a greeting. For TLS 1.3 the NewSessionTicket precedes this on the
     * wire, so the client caches the session while reading.
     */
    len = (pj_ssize_t)pj_ansi_strlen(reuse_greeting);
    status = pj_ssl_sock_send(newsock, &st->send_key.op_key, reuse_greeting,
                              &len, 0);
    if (status != PJ_SUCCESS && status != PJ_EPENDING) {
        pj_ssl_sock_close(newsock);
        return PJ_TRUE;
    }

    return PJ_TRUE;
}

static pj_bool_t reuse_on_connect(pj_ssl_sock_t *ssock, pj_status_t status)
{
    struct reuse_state *st = (struct reuse_state*)
                             pj_ssl_sock_get_user_data(ssock);
    pj_ssl_sock_info info;
    void *read_buf[1];

    if (status != PJ_SUCCESS) {
        st->err = status;
        st->done = PJ_TRUE;
        st->closed = PJ_TRUE;
        pj_ssl_sock_close(ssock);
        return PJ_FALSE;
    }

    if (pj_ssl_sock_get_info(ssock, &info) == PJ_SUCCESS) {
        st->reused = info.session_reused;
        st->verify_status = info.verify_status;
    }

    read_buf[0] = st->read_buf;
    status = pj_ssl_sock_start_read2(ssock, st->pool, sizeof(st->read_buf),
                                     read_buf, 0);
    if (status != PJ_SUCCESS) {
        st->err = status;
        st->done = PJ_TRUE;
        st->closed = PJ_TRUE;
        pj_ssl_sock_close(ssock);
        return PJ_FALSE;
    }
    return PJ_TRUE;
}

static pj_bool_t reuse_on_read(pj_ssl_sock_t *ssock,
                               void *data, pj_size_t size,
                               pj_status_t status, pj_size_t *remainder)
{
    struct reuse_state *st = (struct reuse_state*)
                             pj_ssl_sock_get_user_data(ssock);
    PJ_UNUSED_ARG(data);
    PJ_UNUSED_ARG(remainder);

    if (st->is_server) {
        /* Client closed or error -> tear down the accepted socket. */
        if (status != PJ_SUCCESS) {
            pj_ssl_sock_close(ssock);
            return PJ_FALSE;
        }
        return PJ_TRUE;
    }

    /* Client: receiving the greeting means the NewSessionTicket (if any) has
     * already been processed and cached.
     *
     * Don't close the socket here: this may be called from within
     * pj_ssl_sock_start_read2(), which can't handle the socket being
     * destroyed. The test closes it once the round is done.
     */
    if (size > 0)
        st->done = PJ_TRUE;
    if (status != PJ_SUCCESS) {
        if (status != PJ_EEOF)
            st->err = status;
        st->done = PJ_TRUE;
    }
    return PJ_TRUE;
}

static pj_bool_t reuse_on_verify(pj_ssl_sock_t *ssock, pj_bool_t is_server)
{
    PJ_UNUSED_ARG(ssock);
    PJ_UNUSED_ARG(is_server);
    return PJ_TRUE;
}

static int session_reuse_test(pj_ssl_sock_proto proto,
                              pj_bool_t srv_reuse,
                              enum reuse_mode mode,
                              pj_bool_t expect_reuse)
{
    pj_bool_t same_cfg = (mode == REUSE_SAME || mode == REUSE_UNTRUSTED);
    pj_bool_t untrusted = (mode == REUSE_UNTRUSTED);
    pj_pool_t *pool = NULL;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_ssl_sock_t *ssock_serv = NULL;
    pj_ssl_sock_param param;
    struct reuse_state state_serv;
    pj_sockaddr bind_addr, listen_addr;
    pj_str_t tmp_st;
    pj_bool_t reused[2];
    pj_uint32_t cli_verify[2];
    int i;
    pj_status_t status;

    pj_bzero(&state_serv, sizeof(state_serv));
    reused[0] = PJ_TRUE;            /* must become FALSE */
    reused[1] = !expect_reuse;      /* must become expect_reuse */
    cli_verify[0] = cli_verify[1] = 0;

    pool = pj_pool_create(mem, "ssl_reuse", 512, 512, NULL);
    status = pj_ioqueue_create(pool, 8, &ioqueue);
    if (status != PJ_SUCCESS)
        goto on_return;
    status = pj_timer_heap_create(pool, 8, &timer);
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_ssl_sock_param_default(&param);
    param.cb.on_accept_complete2 = &reuse_on_accept;
    param.cb.on_data_read = &reuse_on_read;
    param.cb.on_data_sent = &ssl_on_data_sent;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;
    param.proto = proto;
    param.enable_session_reuse = srv_reuse;
    param.require_client_cert = same_cfg;
    param.user_data = &state_serv;
    state_serv.pool = pool;
    state_serv.is_server = PJ_TRUE;

    pj_sockaddr_init(PJ_AF_INET, &listen_addr,
                     pj_strset2(&tmp_st, "127.0.0.1"), 0);

    {
        pj_str_t ca = pj_str(CERT_CA_FILE);
        pj_str_t crt = pj_str(CERT_FILE);
        pj_str_t key = pj_str(CERT_PRIVKEY_FILE);
        pj_str_t pass = pj_str(CERT_PRIVKEY_PASS);
        pj_ssl_cert_t *cert = NULL;
        pj_ssl_sock_info info;

        status = pj_ssl_sock_create(pool, &param, &ssock_serv);
        if (status == PJ_SUCCESS)
            status = pj_ssl_cert_load_from_files(pool,
                                                 untrusted ? NULL : &ca,
                                                 &crt, &key, &pass, &cert);
        if (status == PJ_SUCCESS)
            status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
        if (status == PJ_SUCCESS)
            status = pj_ssl_sock_start_accept(ssock_serv, pool, &listen_addr,
                                        pj_sockaddr_get_len(&listen_addr));
        if (status != PJ_SUCCESS) {
            app_perror("...session_reuse_test: server", status);
            goto on_return;
        }
        pj_ssl_sock_get_info(ssock_serv, &info);
        listen_addr = info.local_addr;
    }

    /* Two client rounds against the same server. */
    for (i = 0; i < 2; ++i) {
        pj_ssl_sock_t *ssock_cli = NULL;
        pj_ssl_sock_param cparam;
        struct reuse_state state_cli;
        unsigned loop;

        pj_bzero(&state_cli, sizeof(state_cli));
        state_cli.pool = pool;

        pj_ssl_sock_param_default(&cparam);
        cparam.cb.on_connect_complete = &reuse_on_connect;
        cparam.cb.on_data_read = &reuse_on_read;
        cparam.cb.on_data_sent = &ssl_on_data_sent;
        cparam.ioqueue = ioqueue;
        cparam.timer_heap = timer;
        cparam.proto = proto;
        cparam.enable_session_reuse = PJ_TRUE;
        cparam.server_name = pj_str("127.0.0.1");
        cparam.user_data = &state_cli;
        if (mode == REUSE_VERIFY_CB)
            cparam.cb.on_verify_cb = &reuse_on_verify;

        status = pj_ssl_sock_create(pool, &cparam, &ssock_cli);
        if (status != PJ_SUCCESS)
            goto on_return;

        if (mode != REUSE_VERIFY_CB && (mode != REUSE_CA_FILE || i == 0)) {
            pj_str_t ca_file = pj_str(CERT_CA_FILE);
            pj_str_t ca_path = pj_str(i == 0 ? CERT_DIR : ".");
            pj_str_t crt = pj_str(CERT_CLI_FILE);
            pj_str_t key = pj_str(CERT_CLI_PRIVKEY_FILE);
            pj_str_t pass = pj_str(CERT_PRIVKEY_PASS);
            pj_bool_t has_ca = !untrusted && mode != REUSE_CA_PATH;
            pj_bool_t has_crt = same_cfg || mode == REUSE_CLI_KEY;
            pj_bool_t has_key = same_cfg || (mode == REUSE_CLI_KEY && i == 0);
            pj_ssl_cert_t *cert = NULL;

            status = pj_ssl_cert_load_from_files2(pool,
                                    has_ca ? &ca_file : NULL,
                                    mode == REUSE_CA_PATH ? &ca_path : NULL,
                                    has_crt ? &crt : NULL,
                                    has_key ? &key : NULL,
                                    has_key ? &pass : NULL,
                                    &cert);
            if (status == PJ_SUCCESS)
                status = pj_ssl_sock_set_certificate(ssock_cli, pool, cert);
            if (status != PJ_SUCCESS) {
                app_perror("...session_reuse_test: client cert", status);
                pj_ssl_sock_close(ssock_cli);
                goto on_return;
            }
        }

        pj_sockaddr_init(PJ_AF_INET, &bind_addr,
                         pj_strset2(&tmp_st, "127.0.0.1"), 0);
        status = pj_ssl_sock_start_connect(ssock_cli, pool, &bind_addr,
                                           &listen_addr,
                                           pj_sockaddr_get_len(&listen_addr));
        if (status == PJ_SUCCESS) {
            reuse_on_connect(ssock_cli, PJ_SUCCESS);
        } else if (status == PJ_EPENDING) {
            status = PJ_SUCCESS;
        } else {
            pj_ssl_sock_close(ssock_cli);
            goto on_return;
        }

        /* Wait for this round to complete. */
        loop = 0;
        while (!state_cli.done && !state_cli.err && loop++ < 1000) {
            pj_time_val delay = {0, 100};
            pj_ioqueue_poll(ioqueue, &delay);
            pj_timer_heap_poll(timer, NULL);
        }
        if (!state_cli.done) {
            PJ_LOG(1, ("", "...ERROR: connection %d timed out", i + 1));
            pj_ssl_sock_close(ssock_cli);
            status = PJ_ETIMEDOUT;
            goto on_return;
        }

        if (!state_cli.closed)
            pj_ssl_sock_close(ssock_cli);

        /* Drain so the ticket is fully processed and the server-side socket
         * observes the client close.
         */
        {
            pj_time_val delay = {0, 500};
            loop = 0;
            while (pj_ioqueue_poll(ioqueue, &delay) > 0 && loop++ < 100)
                ;
            pj_timer_heap_poll(timer, NULL);
        }

        if (state_cli.err) {
            status = state_cli.err;
            goto on_return;
        }

        PJ_LOG(3, ("", "...connection %d: session_reused=%d, "
                   "verify_status cli=0x%x srv=0x%x",
                   i + 1, state_cli.reused, state_cli.verify_status,
                   state_serv.acc_verify[i]));
        reused[i] = state_cli.reused;
        cli_verify[i] = state_cli.verify_status;
    }

    if (reused[0]) {
        PJ_LOG(1, ("", "...ERROR: first connection unexpectedly resumed"));
        status = PJ_EBUG;
        goto on_return;
    }
    if (reused[1] != expect_reuse || state_serv.acc_cnt != 2 ||
        state_serv.acc_reused[1] != expect_reuse)
    {
        PJ_LOG(1, ("", "...ERROR: second connection %s session",
                   expect_reuse ? "did not resume" : "unexpectedly resumed"));
        status = PJ_EBUG;
        goto on_return;
    }
    if (mode == REUSE_CA_FILE && (cli_verify[0] != 0 || cli_verify[1] == 0)) {
        PJ_LOG(1, ("", "...ERROR: unexpected verify_status"));
        status = PJ_EBUG;
        goto on_return;
    }
    for (i = 0; same_cfg && i < 2; ++i) {
        if (!untrusted && (cli_verify[i] || state_serv.acc_verify[i])) {
            PJ_LOG(1, ("", "...ERROR: connection %d reports a trusted "
                       "certificate as unverified", i + 1));
            status = PJ_EBUG;
            goto on_return;
        }
        if (untrusted && (!cli_verify[i] || !state_serv.acc_verify[i])) {
            PJ_LOG(1, ("", "...ERROR: connection %d reports an untrusted "
                       "certificate as verified", i + 1));
            status = PJ_EBUG;
            goto on_return;
        }
    }
    if (same_cfg && (cli_verify[1] != cli_verify[0] ||
                     state_serv.acc_verify[1] != state_serv.acc_verify[0]))
    {
        PJ_LOG(1, ("", "...ERROR: second connection reports a different "
                   "verification status"));
        status = PJ_EBUG;
        goto on_return;
    }
    PJ_LOG(3, ("", "...session resumption OK"));
    status = PJ_SUCCESS;

on_return:
    if (ssock_serv)
        pj_ssl_sock_close(ssock_serv);
    if (ioqueue) {
        pj_time_val delay = {0, 500};
        while (pj_ioqueue_poll(ioqueue, &delay) > 0)
            ;
    }
    if (timer)
        pj_timer_heap_destroy(timer);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    if (pool)
        pj_pool_release(pool);

    return (status == PJ_SUCCESS) ? 0 : -1;
}

#endif  /* PJ_SSL_SOCK_IMP_OPENSSL */


static int cert_verify_name_test(void)
{
    enum { NOWC = PJ_SSL_CERT_NAME_NO_WILDCARD,
           URI = PJ_SSL_CERT_NAME_MATCH_SIP_URI,
           CN = PJ_SSL_CERT_NAME_MATCH_CN };
    static const struct test_t {
        const char *cn;
        const char *san;     /* "D:" DNS, "I:" IP, "U:" URI, "E:" email,
                              * ',' separated */
        const char *name;
        unsigned flags;
        pj_status_t result;
    } tests[] = {
        /* DNS SAN, exact & case-insensitive */
        { "x", "D:turn.example.com", "turn.example.com", 0, PJ_SUCCESS },
        { "x", "D:TURN.Example.com", "turn.example.COM", 0, PJ_SUCCESS },
        { "x", "D:a.example.com,D:turn.example.com", "turn.example.com", 0,
          PJ_SUCCESS },
        { "x", "D:turn.example.com", "turn.example.co", 0, PJ_ENOTFOUND },
        { "x", "D:turn.example.com", "xturn.example.com", 0, PJ_ENOTFOUND },

        /* Wildcard, accepted by default (RFC 9525 section 1.3) */
        { "x", "D:*.example.com", "turn.example.com", 0, PJ_SUCCESS },
        { "x", "D:*.example.com", "turn.example.com", NOWC, PJ_ENOTFOUND },
        { "x", "D:*.example.com", "a.turn.example.com", 0, PJ_ENOTFOUND },
        { "x", "D:*.example.com", "example.com", 0, PJ_ENOTFOUND },
        { "x", "D:*.example.com", ".example.com", 0, PJ_ENOTFOUND },
        { "x", "D:f*.example.com", "foo.example.com", 0, PJ_ENOTFOUND },
        { "x", "D:*", "example", 0, PJ_ENOTFOUND },
        { "x", "D:*.0.0.1", "127.0.0.1", 0, PJ_ENOTFOUND },

        /* Hardening beyond RFC 9525: a wildcard needs two labels after it.
         * This rejects a wildcard on a top-level domain, not one on every
         * public suffix, which RFC 9525 section 7.1 puts out of scope.
         */
        { "x", "D:*.com", "example.com", 0, PJ_ENOTFOUND },
        { "x", "D:*.co.uk", "example.co.uk", 0, PJ_SUCCESS },

        /* IP SAN */
        { "x", "I:192.0.2.1", "192.0.2.1", 0, PJ_SUCCESS },
        { "x", "I:192.0.2.1", "192.0.2.10", 0, PJ_ENOTFOUND },
        { "x", "I:2001:db8::1", "2001:DB8:0::1", 0, PJ_SUCCESS },
        { "x", "D:192.0.2.1", "192.0.2.1", 0, PJ_ENOTFOUND },
        { "x", "I:192.0.2.1", "example.com", 0, PJ_ENOTFOUND },

        /* SIP URI SAN */
        { "x", "U:sip:example.com", "example.com", 0, PJ_ENOTFOUND },
        { "x", "U:sip:example.com", "example.com", URI, PJ_SUCCESS },
        { "x", "U:sips:example.com", "example.com", URI, PJ_SUCCESS },
        { "x", "U:http://example.com", "example.com", URI, PJ_ENOTFOUND },

        /* The Common Name is never matched without the flag */
        { "turn.example.com", "", "turn.example.com", 0, PJ_ENOTFOUND },
        { "turn.example.com", "", "turn.example.com", CN, PJ_SUCCESS },
        { "*.example.com", "", "turn.example.com", CN, PJ_SUCCESS },
        { "*.example.com", "", "turn.example.com", CN | NOWC, PJ_ENOTFOUND },
        { "192.0.2.1", "", "192.0.2.1", CN, PJ_SUCCESS },

        /* With the flag, any SubjectAltName entry still suppresses it */
        { "turn.example.com", "D:other.example.com", "turn.example.com", CN,
          PJ_ENOTFOUND },
        { "turn.example.com", "I:192.0.2.1", "turn.example.com", CN,
          PJ_ENOTFOUND },
        { "turn.example.com", "U:http://x", "turn.example.com", CN,
          PJ_ENOTFOUND },
        { "turn.example.com", "U:sip:other.example.com", "turn.example.com",
          CN, PJ_ENOTFOUND },
        { "turn.example.com", "E:admin@example.com", "turn.example.com", CN,
          PJ_ENOTFOUND },
        { "example.com", "U:sip:x.example.com", "example.com", URI | CN,
          PJ_ENOTFOUND },
        { "", "", "", CN, PJ_ENOTFOUND },
        { "", "", "example.com", CN, PJ_ENOTFOUND },
    };
    pj_pool_t *pool;
    unsigned i;
    int rc = 0;

    pool = pj_pool_create(mem, "certname", 1000, 1000, NULL);
    if (!pool)
        return -1300;

    for (i = 0; i < PJ_ARRAY_SIZE(tests); ++i) {
        const struct test_t *t = &tests[i];
        pj_ssl_cert_info ci;
        const char *p = t->san;
        pj_str_t name;
        pj_status_t status;

        pj_bzero(&ci, sizeof(ci));
        ci.version = 3;
        pj_cstr(&ci.subject.cn, t->cn);
        ci.subj_alt_name.entry = pj_pool_calloc(pool, 4,
                                         sizeof(*ci.subj_alt_name.entry));

        while (*p) {
            const char *end = pj_ansi_strchr(p, ',');
            unsigned n = ci.subj_alt_name.cnt++;

            if (!end)
                end = p + pj_ansi_strlen(p);
            ci.subj_alt_name.entry[n].type =
                            (p[0]=='D'? PJ_SSL_CERT_NAME_DNS :
                             (p[0]=='I'? PJ_SSL_CERT_NAME_IP :
                              (p[0]=='E'? PJ_SSL_CERT_NAME_RFC822 :
                               PJ_SSL_CERT_NAME_URI)));
            pj_strset(&ci.subj_alt_name.entry[n].name, (char*)p + 2,
                      end - p - 2);
            p = (*end)? end + 1 : end;
        }

        status = pj_ssl_cert_verify_name(&ci, pj_cstr(&name, t->name),
                                         t->flags);
        if (status != t->result) {
            PJ_LOG(1,("", "   cert name test #%u failed: cn='%s' san='%s' "
                      "name='%s' flags=%u: expected %d, got %d",
                      i, t->cn, t->san, t->name, t->flags, t->result,
                      status));
            rc = -1310;
        }
    }

    pj_pool_release(pool);
    return rc;
}


/* Certificate serial number test: a client connects to a server using each
 * certificate below and checks the peer serial in pj_ssl_cert_info, which
 * must be right-aligned, most significant octet first, whatever its length.
 */
#if TEST_CERT_BUFFER

/* Self-signed P-256 certificates sharing this key, differing in serial */
static const char serial_key_pem[] =
    "-----BEGIN PRIVATE KEY-----\n"
    "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgA/1+nm2ZU4zhz1LP\n"
    "BIDH/fRgMp1jY8SRiujoDUdad3+hRANCAASlEaaCDVBdjuUHuBPYM20NrJxld6tT\n"
    "9IchPoUG8ancLepANgl+X3akPDkp22FXuwbdaA+UM/K9wilPQrBgWX17\n"
    "-----END PRIVATE KEY-----\n";

static const struct serial_cert
{
    const char *title;
    const char *pem;
    pj_uint8_t  serial_no[20];      /* expected pj_ssl_cert_info value */
} serial_certs[] =
{
    {
        "2-octet serial",
        "-----BEGIN CERTIFICATE-----\n"
        "MIIBPjCB5aADAgECAgIBAjAKBggqhkjOPQQDAjAWMRQwEgYDVQQDDAtzZXJpYWwu\n"
        "dGVzdDAgFw0yNjA5MjcxNjU3NTVaGA8yMTI2MDkwMzE2NTc1NVowFjEUMBIGA1UE\n"
        "AwwLc2VyaWFsLnRlc3QwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAASlEaaCDVBd\n"
        "juUHuBPYM20NrJxld6tT9IchPoUG8ancLepANgl+X3akPDkp22FXuwbdaA+UM/K9\n"
        "wilPQrBgWX17oyEwHzAdBgNVHQ4EFgQUe2FNKJErdjkiWhPSS5DmAWDvMgUwCgYI\n"
        "KoZIzj0EAwIDSAAwRQIgZaAdQkVKSAsn5WI9YUfLF5g0/hYy6Lzga3uZjBpkZhoC\n"
        "IQDalqCmycJuwyAUv+DoSODNOZoqCZJqjpWc3n7b4sXe9g==\n"
        "-----END CERTIFICATE-----\n",
        { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
          0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02 }
    },
    {
        /* Encoded in 21 octets, the first being the DER sign octet */
        "20-octet serial with high bit set",
        "-----BEGIN CERTIFICATE-----\n"
        "MIIBUTCB+KADAgECAhUAgQIDBAUGBwgJCgsMDQ4PEBESExQwCgYIKoZIzj0EAwIw\n"
        "FjEUMBIGA1UEAwwLc2VyaWFsLnRlc3QwIBcNMjYwOTI3MTY1NzU1WhgPMjEyNjA5\n"
        "MDMxNjU3NTVaMBYxFDASBgNVBAMMC3NlcmlhbC50ZXN0MFkwEwYHKoZIzj0CAQYI\n"
        "KoZIzj0DAQcDQgAEpRGmgg1QXY7lB7gT2DNtDaycZXerU/SHIT6FBvGp3C3qQDYJ\n"
        "fl92pDw5KdthV7sG3WgPlDPyvcIpT0KwYFl9e6MhMB8wHQYDVR0OBBYEFHthTSiR\n"
        "K3Y5IloT0kuQ5gFg7zIFMAoGCCqGSM49BAMCA0gAMEUCIQDrvAJokjUczFvQs9+V\n"
        "hc7s6XkMeClC95Uo67st+HBIdgIgdk/b943pXuJb3b1hVkXVTyARHUN5GYQzdVdB\n"
        "nmBB8tU=\n"
        "-----END CERTIFICATE-----\n",
        { 0x81, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A,
          0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14 }
    },
    {
        /* Longer than the field, and than GnuTLS's 64-octet buffer: only
         * the first 20 octets are kept
         */
        "65-octet serial",
        "-----BEGIN CERTIFICATE-----\n"
        "MIIBfzCCASSgAwIBAgJBAQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAh\n"
        "IiMkJSYnKCkqKywtLi8wMTIzNDU2Nzg5Ojs8PT4/QEEwCgYIKoZIzj0EAwIwFjEU\n"
        "MBIGA1UEAwwLc2VyaWFsLnRlc3QwIBcNMjYxMDE3MjA0MjE2WhgPMjEyNjA5MjMy\n"
        "MDQyMTZaMBYxFDASBgNVBAMMC3NlcmlhbC50ZXN0MFkwEwYHKoZIzj0CAQYIKoZI\n"
        "zj0DAQcDQgAEpRGmgg1QXY7lB7gT2DNtDaycZXerU/SHIT6FBvGp3C3qQDYJfl92\n"
        "pDw5KdthV7sG3WgPlDPyvcIpT0KwYFl9e6MhMB8wHQYDVR0OBBYEFHthTSiRK3Y5\n"
        "IloT0kuQ5gFg7zIFMAoGCCqGSM49BAMCA0kAMEYCIQC6o1CE3ESGPkSBN/99PfRv\n"
        "L6q6vBOTTWT5t2UjEY79xAIhAMc0G0mcanwOZ8zaYG1wofdm3ZIngOVXJ60NeCxN\n"
        "sytA\n"
        "-----END CERTIFICATE-----\n",
        { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A,
          0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14 }
    }
};

struct serial_state
{
    pj_pool_t      *pool;
    pj_bool_t       done;           /* handshake completed or failed      */
    pj_status_t     err;
    pj_uint8_t      serial_no[20];  /* client: peer certificate serial    */
    pj_uint8_t      read_buf[64];
};

static pj_bool_t serial_on_accept(pj_ssl_sock_t *ssock,
                                  pj_ssl_sock_t *newsock,
                                  const pj_sockaddr_t *src_addr,
                                  int src_addr_len,
                                  pj_status_t accept_status)
{
    struct serial_state *parent_st = (struct serial_state*)
                                     pj_ssl_sock_get_user_data(ssock);
    struct serial_state *st;
    void *read_buf[1];

    PJ_UNUSED_ARG(src_addr);
    PJ_UNUSED_ARG(src_addr_len);

    parent_st->done = PJ_TRUE;
    if (accept_status != PJ_SUCCESS)
        return PJ_TRUE;

    st = (struct serial_state*) pj_pool_zalloc(parent_st->pool, sizeof(*st));
    st->pool = parent_st->pool;
    pj_ssl_sock_set_user_data(newsock, st);

    /* Read so we notice the client closing (EOF). */
    read_buf[0] = st->read_buf;
    if (pj_ssl_sock_start_read2(newsock, st->pool, sizeof(st->read_buf),
                                read_buf, 0) != PJ_SUCCESS)
    {
        pj_ssl_sock_close(newsock);
    }
    return PJ_TRUE;
}

static pj_bool_t serial_on_connect(pj_ssl_sock_t *ssock, pj_status_t status)
{
    struct serial_state *st = (struct serial_state*)
                              pj_ssl_sock_get_user_data(ssock);
    pj_ssl_sock_info info;

    pj_bzero(&info, sizeof(info));
    if (status == PJ_SUCCESS)
        status = pj_ssl_sock_get_info(ssock, &info);
    if (status == PJ_SUCCESS)
        pj_memcpy(st->serial_no, info.remote_cert_info->serial_no,
                  sizeof(st->serial_no));

    st->err = status;
    st->done = PJ_TRUE;
    pj_ssl_sock_close(ssock);
    return PJ_FALSE;
}

static pj_bool_t serial_on_read(pj_ssl_sock_t *ssock,
                                void *data, pj_size_t size,
                                pj_status_t status, pj_size_t *remainder)
{
    PJ_UNUSED_ARG(data);
    PJ_UNUSED_ARG(size);
    PJ_UNUSED_ARG(remainder);

    if (status != PJ_SUCCESS) {
        pj_ssl_sock_close(ssock);
        return PJ_FALSE;
    }
    return PJ_TRUE;
}

static void serial_to_hex(const pj_uint8_t *serial_no, char *buf)
{
    unsigned i;

    for (i = 0; i < 20; ++i)
        pj_ansi_snprintf(buf + i * 2, 3, "%02X", serial_no[i]);
}

static pj_status_t serial_check(pj_pool_t *pool, pj_ioqueue_t *ioqueue,
                                pj_timer_heap_t *timer,
                                const struct serial_cert *sc)
{
    pj_ssl_sock_t *ssock_serv = NULL;
    pj_ssl_sock_t *ssock_cli = NULL;
    pj_ssl_sock_param param;
    pj_ssl_sock_info info;
    pj_ssl_cert_t *cert = NULL;
    pj_ssl_cert_buffer cert_buf, key_buf;
    struct serial_state state_serv, state_cli;
    pj_sockaddr bind_addr, listen_addr;
    pj_str_t tmp_st;
    unsigned loop;
    pj_status_t status;

    pj_bzero(&state_serv, sizeof(state_serv));
    pj_bzero(&state_cli, sizeof(state_cli));
    state_serv.pool = state_cli.pool = pool;

    pj_ssl_sock_param_default(&param);
    param.cb.on_accept_complete2 = &serial_on_accept;
    param.cb.on_connect_complete = &serial_on_connect;
    param.cb.on_data_read = &serial_on_read;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;

    /* === SERVER === */
    param.user_data = &state_serv;
    status = pj_ssl_sock_create(pool, &param, &ssock_serv);
    if (status != PJ_SUCCESS)
        goto on_return;

    /* The self-signed certificate is its own CA. PEM lengths include the
     * NUL, which Mbed TLS requires.
     */
    pj_strset(&cert_buf, (char*)sc->pem, pj_ansi_strlen(sc->pem) + 1);
    pj_strset(&key_buf, (char*)serial_key_pem, sizeof(serial_key_pem));
    status = pj_ssl_cert_load_from_buffer(pool, &cert_buf, &cert_buf,
                                          &key_buf, NULL, &cert);
    if (status != PJ_SUCCESS)
        goto on_return;

    status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_sockaddr_init(PJ_AF_INET, &listen_addr,
                     pj_strset2(&tmp_st, "127.0.0.1"), 0);
    status = pj_ssl_sock_start_accept(ssock_serv, pool, &listen_addr,
                                      pj_sockaddr_get_len(&listen_addr));
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_ssl_sock_get_info(ssock_serv, &info);
    pj_sockaddr_cp(&listen_addr, &info.local_addr);

    /* === CLIENT === */
    param.user_data = &state_cli;
    status = pj_ssl_sock_create(pool, &param, &ssock_cli);
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_sockaddr_init(PJ_AF_INET, &bind_addr,
                     pj_strset2(&tmp_st, "127.0.0.1"), 0);
    status = pj_ssl_sock_start_connect(ssock_cli, pool, &bind_addr,
                                       &listen_addr,
                                       pj_sockaddr_get_len(&listen_addr));
    if (status == PJ_SUCCESS) {
        serial_on_connect(ssock_cli, PJ_SUCCESS);
    } else if (status != PJ_EPENDING) {
        pj_ssl_sock_close(ssock_cli);
        goto on_return;
    }

    /* The listener must outlive the server side of the handshake, which
     * may complete after the client's.
     */
    loop = 0;
    while ((!state_cli.done || !state_serv.done) && loop++ < 1000) {
        pj_time_val delay = {0, 100};
        pj_ioqueue_poll(ioqueue, &delay);
        pj_timer_heap_poll(timer, NULL);
    }

    if (!state_cli.done) {
        pj_ssl_sock_close(ssock_cli);
        status = PJ_ETIMEDOUT;
    } else {
        status = state_cli.err;
    }
    if (status != PJ_SUCCESS)
        goto on_return;

    if (pj_memcmp(state_cli.serial_no, sc->serial_no,
                  sizeof(sc->serial_no)))
    {
        char got[41], exp[41];

        serial_to_hex(state_cli.serial_no, got);
        serial_to_hex(sc->serial_no, exp);
        PJ_LOG(1, ("", "...ERROR: serial_no %s, expected %s", got, exp));
        status = PJ_EBUG;
    }

on_return:
    if (ssock_serv)
        pj_ssl_sock_close(ssock_serv);

    /* Let the accepted socket observe the client close. */
    {
        pj_time_val delay = {0, 500};
        loop = 0;
        while (pj_ioqueue_poll(ioqueue, &delay) > 0 && loop++ < 100)
            ;
        pj_timer_heap_poll(timer, NULL);
    }

    return status;
}

static int cert_serial_test(void)
{
    pj_pool_t *pool;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    unsigned i;
    pj_status_t status;

    pool = pj_pool_create(mem, "ssl_serial", 512, 512, NULL);
    status = pj_ioqueue_create(pool, 8, &ioqueue);
    if (status != PJ_SUCCESS)
        goto on_return;
    status = pj_timer_heap_create(pool, 8, &timer);
    if (status != PJ_SUCCESS)
        goto on_return;

    for (i = 0; i < PJ_ARRAY_SIZE(serial_certs); ++i) {
        PJ_LOG(3, ("", "...%s", serial_certs[i].title));
        status = serial_check(pool, ioqueue, timer, &serial_certs[i]);
        if (status != PJ_SUCCESS) {
            app_perror("...ERROR cert_serial_test()", status);
            break;
        }
    }

on_return:
    if (timer)
        pj_timer_heap_destroy(timer);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    pj_pool_release(pool);

    return (status == PJ_SUCCESS) ? 0 : -1;
}

/* OpenSSL 3.3 and later, LibreSSL and BoringSSL reject a short time field
 * when the certificate is decoded, so the test server cannot present one.
 */
#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL)
#   include <openssl/opensslv.h>
#   if (OPENSSL_VERSION_NUMBER < 0x30300000L) && \
       !defined(LIBRESSL_VERSION_NUMBER) && !defined(OPENSSL_IS_BORINGSSL)
#       define TEST_BAD_TIME_CERT       1
#   endif
#endif

#if TEST_BAD_TIME_CERT
/* Self-signed cert (sharing serial_key_pem) whose notAfter is a zero-length
 * GeneralizedTime. OpenSSL keeps the raw ASN.1 time bytes without checking
 * the format, so get_cert_info() parses this field when a peer presents it.
 * Serial number is 1.
 */
static const struct serial_cert bad_time_cert =
{
    "zero-length GeneralizedTime notAfter",
    "-----BEGIN CERTIFICATE-----\n"
    "MIIBDDCBsqADAgECAgEBMAoGCCqGSM49BAMCMBYxFDASBgNVBAMMC3NlcmlhbC50\n"
    "ZXN0MBEXDTI2MDkyNzE2NTc1NVoYADAWMRQwEgYDVQQDDAtzZXJpYWwudGVzdDBZ\n"
    "MBMGByqGSM49AgEGCCqGSM49AwEHA0IABKURpoINUF2O5Qe4E9gzbQ2snGV3q1P0\n"
    "hyE+hQbxqdwt6kA2CX5fdqQ8OSnbYVe7Bt1oD5Qz8r3CKU9CsGBZfXswCgYIKoZI\n"
    "zj0EAwIDSQAwRgIhAPelQ0duY6Mx3K9ojfVD5Jhwd8k/c4EpCUDzftBRheRhAiEA\n"
    "zmslYbYrD9DX9xAfHCf8e4xMfl4Pya3HS+7POgpGSws=\n"
    "-----END CERTIFICATE-----\n",
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01 }
};

/* A peer certificate with a malformed validity time must not read outside
 * the ASN.1 time field when its info is parsed (ASan regression).
 */
static int cert_bad_time_test(void)
{
    pj_pool_t *pool;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_status_t status;

    pool = pj_pool_create(mem, "ssl_badtime", 512, 512, NULL);
    status = pj_ioqueue_create(pool, 8, &ioqueue);
    if (status != PJ_SUCCESS)
        goto on_return;
    status = pj_timer_heap_create(pool, 8, &timer);
    if (status != PJ_SUCCESS)
        goto on_return;

    status = serial_check(pool, ioqueue, timer, &bad_time_cert);
    if (status != PJ_SUCCESS)
        app_perror("...ERROR cert_bad_time_test()", status);

on_return:
    if (timer)
        pj_timer_heap_destroy(timer);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    pj_pool_release(pool);

    return (status == PJ_SUCCESS) ? 0 : -1;
}
#endif  /* TEST_BAD_TIME_CERT */

struct chain_state
{
    pj_pool_t      *pool;
    pj_bool_t       done;           /* handshake completed or failed      */
    pj_status_t     err;
    pj_bool_t       got_cert;       /* server: client sent a certificate  */
    pj_uint32_t     verify_status;  /* server: client cert verify status  */
    pj_uint8_t      read_buf[64];
};

static pj_bool_t chain_on_accept(pj_ssl_sock_t *ssock,
                                 pj_ssl_sock_t *newsock,
                                 const pj_sockaddr_t *src_addr,
                                 int src_addr_len,
                                 pj_status_t accept_status)
{
    struct chain_state *st = (struct chain_state*)
                             pj_ssl_sock_get_user_data(ssock);
    pj_ssl_sock_info info;
    void *read_buf[1];

    PJ_UNUSED_ARG(src_addr);
    PJ_UNUSED_ARG(src_addr_len);

    st->done = PJ_TRUE;
    st->err = accept_status;
    if (accept_status != PJ_SUCCESS)
        return PJ_TRUE;

    if (pj_ssl_sock_get_info(newsock, &info) == PJ_SUCCESS) {
        st->got_cert = (info.remote_cert_info &&
                        info.remote_cert_info->subject.info.slen);
        st->verify_status = info.verify_status;
    }

    /* Read so we notice the client closing (EOF). */
    read_buf[0] = st->read_buf;
    if (pj_ssl_sock_start_read2(newsock, st->pool, sizeof(st->read_buf),
                                read_buf, 0) != PJ_SUCCESS)
    {
        pj_ssl_sock_close(newsock);
    }
    return PJ_TRUE;
}

static pj_bool_t chain_on_connect(pj_ssl_sock_t *ssock, pj_status_t status)
{
    struct chain_state *st = (struct chain_state*)
                             pj_ssl_sock_get_user_data(ssock);

    st->err = status;
    st->done = PJ_TRUE;
    return PJ_TRUE;
}

/* A client certificate whose chain ends at a CA the server doesn't trust
 * must not be reported as verified, also when the client sends that CA.
 * The client certificate is optional, so the handshake itself succeeds.
 */
static int untrusted_chain_test(void)
{
    pj_pool_t *pool;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_ssl_sock_t *ssock_serv = NULL;
    pj_ssl_sock_t *ssock_cli = NULL;
    pj_ssl_sock_param param;
    pj_ssl_sock_info info;
    pj_ssl_cert_t *cert = NULL;
    pj_ssl_cert_t *cli_cert = NULL;
    pj_ssl_cert_buffer ca_buf, cert_buf, key_buf, cli_buf, issuer_buf;
    pj_ssl_cert_buffer chain_buf;
    pj_str_t file, pass = pj_str(CERT_PRIVKEY_PASS);
    struct chain_state state_serv, state_cli;
    pj_sockaddr bind_addr, listen_addr;
    pj_str_t tmp_st;
    unsigned loop;
    pj_status_t status;

    pj_bzero(&state_serv, sizeof(state_serv));
    pj_bzero(&state_cli, sizeof(state_cli));
    pj_bzero(&cli_buf, sizeof(cli_buf));
    pj_bzero(&issuer_buf, sizeof(issuer_buf));

    pool = pj_pool_create(mem, "ssl_chain", 512, 512, NULL);
    state_serv.pool = state_cli.pool = pool;
    status = pj_ioqueue_create(pool, 8, &ioqueue);
    if (status != PJ_SUCCESS)
        goto on_return;
    status = pj_timer_heap_create(pool, 8, &timer);
    if (status != PJ_SUCCESS)
        goto on_return;

    status = load_cert_to_buf(pool, pj_cstr(&file, CERT_CA_FILE), &ca_buf);
    if (status == PJ_SUCCESS)
        status = load_cert_to_buf(pool, pj_cstr(&file, CERT_FILE), &cert_buf);
    if (status == PJ_SUCCESS)
        status = load_cert_to_buf(pool, pj_cstr(&file, CERT_PRIVKEY_FILE),
                                  &key_buf);
    if (status == PJ_SUCCESS)
        status = load_cert_to_buf(pool, pj_cstr(&file, CERT_CLI_FILE),
                                  &cli_buf);
    /* Issuer of CERT_CLI_FILE, PEM so it can be appended to the chain */
    if (status == PJ_SUCCESS)
        status = load_cert_to_buf(pool, pj_cstr(&file, CERT_DIR "cacert.pem"),
                                  &issuer_buf);
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_ssl_sock_param_default(&param);
    param.cb.on_accept_complete2 = &chain_on_accept;
    param.cb.on_connect_complete = &chain_on_connect;
    param.cb.on_data_read = &serial_on_read;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;

    /* === SERVER: trusts no CA === */
    param.user_data = &state_serv;
    status = pj_ssl_sock_create(pool, &param, &ssock_serv);
    if (status != PJ_SUCCESS)
        goto on_return;

    status = pj_ssl_cert_load_from_buffer(pool, NULL, &cert_buf, &key_buf,
                                          &pass, &cert);
    if (status == PJ_SUCCESS)
        status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_sockaddr_init(PJ_AF_INET, &listen_addr,
                     pj_strset2(&tmp_st, "127.0.0.1"), 0);
    status = pj_ssl_sock_start_accept(ssock_serv, pool, &listen_addr,
                                      pj_sockaddr_get_len(&listen_addr));
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_ssl_sock_get_info(ssock_serv, &info);
    pj_sockaddr_cp(&listen_addr, &info.local_addr);

    /* === CLIENT: sends its certificate followed by its issuer === */
    param.user_data = &state_cli;
    param.server_name = pj_str("127.0.0.1");
    status = pj_ssl_sock_create(pool, &param, &ssock_cli);
    if (status != PJ_SUCCESS)
        goto on_return;

    chain_buf.ptr = (char*)pj_pool_zalloc(pool, cli_buf.slen +
                                                issuer_buf.slen + 1);
    pj_memcpy(chain_buf.ptr, cli_buf.ptr, cli_buf.slen);
    pj_memcpy(chain_buf.ptr + cli_buf.slen, issuer_buf.ptr, issuer_buf.slen);
    chain_buf.slen = cli_buf.slen + issuer_buf.slen;

    status = load_cert_to_buf(pool, pj_cstr(&file, CERT_CLI_PRIVKEY_FILE),
                              &key_buf);
    if (status == PJ_SUCCESS)
        status = pj_ssl_cert_load_from_buffer(pool, &ca_buf, &chain_buf,
                                              &key_buf, &pass, &cli_cert);
    if (status == PJ_SUCCESS)
        status = pj_ssl_sock_set_certificate(ssock_cli, pool, cli_cert);
    if (status != PJ_SUCCESS) {
        pj_ssl_sock_close(ssock_cli);
        goto on_return;
    }

    pj_sockaddr_init(PJ_AF_INET, &bind_addr,
                     pj_strset2(&tmp_st, "127.0.0.1"), 0);
    status = pj_ssl_sock_start_connect(ssock_cli, pool, &bind_addr,
                                       &listen_addr,
                                       pj_sockaddr_get_len(&listen_addr));
    if (status == PJ_SUCCESS) {
        chain_on_connect(ssock_cli, PJ_SUCCESS);
    } else if (status != PJ_EPENDING) {
        pj_ssl_sock_close(ssock_cli);
        goto on_return;
    }

    loop = 0;
    while ((!state_cli.done || !state_serv.done) && loop++ < 1000) {
        pj_time_val delay = {0, 100};
        pj_ioqueue_poll(ioqueue, &delay);
        pj_timer_heap_poll(timer, NULL);
    }

    pj_ssl_sock_close(ssock_cli);
    if (!state_serv.done) {
        status = PJ_ETIMEDOUT;
        goto on_return;
    }

    status = PJ_SUCCESS;
#if PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_GNUTLS
    /* This backend requests the optional client certificate */
    if (state_serv.err != PJ_SUCCESS || !state_serv.got_cert) {
        PJ_LOG(1, ("", "...ERROR: handshake failed or no client "
                       "certificate received"));
        status = PJ_EBUG;
    }
#endif
    if (state_serv.err == PJ_SUCCESS && state_serv.got_cert &&
        (state_serv.verify_status & (PJ_SSL_CERT_EUNTRUSTED |
                                     PJ_SSL_CERT_EISSUER_NOT_FOUND)) == 0)
    {
        PJ_LOG(1, ("", "...ERROR: untrusted client certificate chain "
                       "reported as verified"));
        status = PJ_EBUG;
    }

on_return:
    if (ssock_serv)
        pj_ssl_sock_close(ssock_serv);

    /* Let the accepted socket observe the client close. */
    if (ioqueue && timer) {
        pj_time_val delay = {0, 500};
        loop = 0;
        while (pj_ioqueue_poll(ioqueue, &delay) > 0 && loop++ < 100)
            ;
        pj_timer_heap_poll(timer, NULL);
    }

    if (status != PJ_SUCCESS)
        app_perror("...ERROR untrusted_chain_test()", status);
    if (timer)
        pj_timer_heap_destroy(timer);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    pj_pool_release(pool);

    return (status == PJ_SUCCESS) ? 0 : -1;
}

static pj_bool_t no_ca_on_connect(pj_ssl_sock_t *ssock, pj_status_t status)
{
    struct chain_state *st = (struct chain_state*)
                             pj_ssl_sock_get_user_data(ssock);
    pj_ssl_sock_info info;

    st->err = status;
    if (status == PJ_SUCCESS &&
        pj_ssl_sock_get_info(ssock, &info) == PJ_SUCCESS)
    {
        st->verify_status = info.verify_status;
    }
    st->done = PJ_TRUE;
    return PJ_TRUE;
}

/* A client without any CA cannot trust the server certificate. With
 * verify_peer the handshake must fail, without it the handshake succeeds
 * and the certificate must not be reported as verified.
 */
static int no_ca_client_test(pj_bool_t verify_peer)
{
    pj_pool_t *pool;
    pj_ioqueue_t *ioqueue = NULL;
    pj_timer_heap_t *timer = NULL;
    pj_ssl_sock_t *ssock_serv = NULL;
    pj_ssl_sock_t *ssock_cli = NULL;
    pj_ssl_sock_param param;
    pj_ssl_sock_info info;
    pj_ssl_cert_t *cert = NULL;
    pj_ssl_cert_buffer cert_buf, key_buf;
    pj_str_t file, pass = pj_str(CERT_PRIVKEY_PASS);
    struct chain_state state_serv, state_cli;
    pj_sockaddr bind_addr, listen_addr;
    pj_str_t tmp_st;
    unsigned loop;
    pj_status_t status;

    pj_bzero(&state_serv, sizeof(state_serv));
    pj_bzero(&state_cli, sizeof(state_cli));

    pool = pj_pool_create(mem, "ssl_noca", 512, 512, NULL);
    state_serv.pool = state_cli.pool = pool;
    status = pj_ioqueue_create(pool, 8, &ioqueue);
    if (status != PJ_SUCCESS)
        goto on_return;
    status = pj_timer_heap_create(pool, 8, &timer);
    if (status != PJ_SUCCESS)
        goto on_return;

    status = load_cert_to_buf(pool, pj_cstr(&file, CERT_FILE), &cert_buf);
    if (status == PJ_SUCCESS)
        status = load_cert_to_buf(pool, pj_cstr(&file, CERT_PRIVKEY_FILE),
                                  &key_buf);
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_ssl_sock_param_default(&param);
    param.cb.on_accept_complete2 = &chain_on_accept;
    param.cb.on_connect_complete = &no_ca_on_connect;
    param.cb.on_data_read = &serial_on_read;
    param.ioqueue = ioqueue;
    param.timer_heap = timer;

    /* === SERVER === */
    param.user_data = &state_serv;
    status = pj_ssl_sock_create(pool, &param, &ssock_serv);
    if (status != PJ_SUCCESS)
        goto on_return;

    status = pj_ssl_cert_load_from_buffer(pool, NULL, &cert_buf, &key_buf,
                                          &pass, &cert);
    if (status == PJ_SUCCESS)
        status = pj_ssl_sock_set_certificate(ssock_serv, pool, cert);
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_sockaddr_init(PJ_AF_INET, &listen_addr,
                     pj_strset2(&tmp_st, "127.0.0.1"), 0);
    status = pj_ssl_sock_start_accept(ssock_serv, pool, &listen_addr,
                                      pj_sockaddr_get_len(&listen_addr));
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_ssl_sock_get_info(ssock_serv, &info);
    pj_sockaddr_cp(&listen_addr, &info.local_addr);

    /* === CLIENT: no certificate, no CA === */
    param.user_data = &state_cli;
    param.verify_peer = verify_peer;
    status = pj_ssl_sock_create(pool, &param, &ssock_cli);
    if (status != PJ_SUCCESS)
        goto on_return;

    pj_sockaddr_init(PJ_AF_INET, &bind_addr,
                     pj_strset2(&tmp_st, "127.0.0.1"), 0);
    status = pj_ssl_sock_start_connect(ssock_cli, pool, &bind_addr,
                                       &listen_addr,
                                       pj_sockaddr_get_len(&listen_addr));
    if (status == PJ_SUCCESS) {
        no_ca_on_connect(ssock_cli, PJ_SUCCESS);
    } else if (status != PJ_EPENDING) {
        pj_ssl_sock_close(ssock_cli);
        goto on_return;
    }

    loop = 0;
    while ((!state_cli.done || !state_serv.done) && loop++ < 1000) {
        pj_time_val delay = {0, 100};
        pj_ioqueue_poll(ioqueue, &delay);
        pj_timer_heap_poll(timer, NULL);
    }

    pj_ssl_sock_close(ssock_cli);
    if (!state_cli.done || !state_serv.done) {
        status = PJ_ETIMEDOUT;
        goto on_return;
    }

    status = PJ_SUCCESS;
    if (verify_peer) {
        if (state_cli.err == PJ_SUCCESS) {
            PJ_LOG(1, ("", "...ERROR: handshake succeeded with an untrusted "
                           "server certificate"));
            status = PJ_EBUG;
        }
    } else if (state_cli.err != PJ_SUCCESS) {
        PJ_LOG(1, ("", "...ERROR: handshake failed"));
        status = state_cli.err;
    } else if (state_cli.verify_status == 0) {
        PJ_LOG(1, ("", "...ERROR: untrusted server certificate reported "
                       "as verified"));
        status = PJ_EBUG;
    }

on_return:
    if (ssock_serv)
        pj_ssl_sock_close(ssock_serv);

    /* Let the accepted socket observe the client close. */
    if (ioqueue && timer) {
        pj_time_val delay = {0, 500};
        loop = 0;
        while (pj_ioqueue_poll(ioqueue, &delay) > 0 && loop++ < 100)
            ;
        pj_timer_heap_poll(timer, NULL);
    }

    if (status != PJ_SUCCESS)
        app_perror("...ERROR no_ca_client_test()", status);
    if (timer)
        pj_timer_heap_destroy(timer);
    if (ioqueue)
        pj_ioqueue_destroy(ioqueue);
    pj_pool_release(pool);

    return (status == PJ_SUCCESS) ? 0 : -1;
}

#endif  /* TEST_CERT_BUFFER */


int ssl_sock_test(void)
{
    int ret;

#if TEST_CERT_BUFFER
    ret = cert_buffer_test();
    if (ret != 0)
        return ret;
#endif

    PJ_LOG(3,("", "..certificate name verification test"));
    ret = cert_verify_name_test();
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..get cipher list test"));
    ret = get_cipher_list();
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..https client test"));
    ret = https_client_test(30000);
    if (ret != 0)
        return ret;

#ifndef PJ_SYMBIAN
   
    /* On Symbian platforms, SSL socket is implemented using CSecureSocket, 
     * and it hasn't supported server mode, so exclude the following tests,
     * which require SSL server, for now.
     */

    /* Schannel backend notes:
     * - currently it does not support ciphers settings, so we exclude tests
     *   whose ciphers setting is specified.
     * - TLS protocol older than 1.0 is not supported, TLS 1.0 & 1.1 will be
     *   disabled soon, TLS 1.3 is supported since Windows 11, so for now
     *   we only include tests with TLS 1.2.
     */

#if (PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_SCHANNEL)
    PJ_LOG(3,("", "..echo test w/ TLSv1.2 and PJ_TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 cipher"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_TLS1_2, PJ_SSL_SOCK_PROTO_TLS1_2,
                    PJ_TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
                    PJ_TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
                    PJ_FALSE, PJ_FALSE);
    if (ret != 0)
        return ret;

/* The Darwin backend cannot set a TLS 1.3 floor -- Secure Transport's
 * SSLSetProtocolVersionMin() does not accept it -- so a TLS 1.3-only
 * request is rejected at socket creation rather than downgraded.
 */
#if (PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_DARWIN)
    PJ_LOG(3,("", "..echo test w/ TLSv1.3 and PJ_TLS_AES_128_GCM_SHA256 cipher"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_SSL_SOCK_PROTO_TLS1_3,
                    PJ_TLS_AES_128_GCM_SHA256, PJ_TLS_AES_128_GCM_SHA256,
                    PJ_FALSE, PJ_FALSE);
    if (ret != 0)
        return ret;
#endif

#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL)
    PJ_LOG(3,("", "..TLSv1.3 session resumption test"));
    ret = session_reuse_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_TRUE, REUSE_SAME,
                             PJ_TRUE);
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..TLSv1.3 session resumption test w/ untrusted certs"));
    ret = session_reuse_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_TRUE,
                             REUSE_UNTRUSTED, PJ_TRUE);
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..TLSv1.3 no session resumption unless server opts in"));
    ret = session_reuse_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_FALSE,
                             REUSE_UNTRUSTED, PJ_FALSE);
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..TLSv1.2 session resumption test w/ untrusted certs"));
    ret = session_reuse_test(PJ_SSL_SOCK_PROTO_TLS1_2, PJ_FALSE,
                             REUSE_UNTRUSTED, PJ_TRUE);
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..TLSv1.3 no session resumption across CA lists"));
    ret = session_reuse_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_TRUE, REUSE_CA_FILE,
                             PJ_FALSE);
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..TLSv1.3 no session resumption across CA directories"));
    ret = session_reuse_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_TRUE, REUSE_CA_PATH,
                             PJ_FALSE);
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..TLSv1.3 no session resumption with verify callback"));
    ret = session_reuse_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_TRUE, REUSE_VERIFY_CB,
                             PJ_FALSE);
    if (ret != 0)
        return ret;

    PJ_LOG(3,("", "..TLSv1.3 no session resumption without client key"));
    ret = session_reuse_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_TRUE, REUSE_CLI_KEY,
                             PJ_FALSE);
    if (ret != 0)
        return ret;
#endif
#endif

    PJ_LOG(3,("", "..echo test w/ compatible proto: server TLSv1.2 vs client TLSv1.2"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_TLS1_2, PJ_SSL_SOCK_PROTO_TLS1_2, 
                    -1, -1,
                    PJ_FALSE, PJ_FALSE);
    if (ret != 0)
        return ret;

#if (PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_SCHANNEL)
/* The Darwin backend cannot set a TLS 1.3 floor -- Secure Transport's
 * SSLSetProtocolVersionMin() does not accept it -- so a TLS 1.3-only
 * request is rejected at socket creation rather than downgraded.
 */
#if (PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_DARWIN)
    PJ_LOG(3,("", "..echo test w/ compatible proto: server TLSv1.2+1.3 vs client TLSv1.3"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_TLS1_2 | PJ_SSL_SOCK_PROTO_TLS1_3, PJ_SSL_SOCK_PROTO_TLS1_3, 
                    -1, -1,
                    PJ_FALSE, PJ_FALSE);
    if (ret != 0)
        return ret;
#endif

    PJ_LOG(3,("", "..echo test w/ incompatible proto: server TLSv1.3 vs client TLSv1.2"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_TLS1_3, PJ_SSL_SOCK_PROTO_TLS1_2,
                    PJ_TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
                    PJ_TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
                    PJ_FALSE, PJ_FALSE);
    if (ret == 0)
        return PJ_EBUG;
#endif

#if (PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_SCHANNEL)
    PJ_LOG(3,("", "..echo test w/ incompatible proto: server TLSv1.2 vs client TLSv1.3"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_TLS1_2, PJ_SSL_SOCK_PROTO_TLS1_3, 
                    -1, -1,
                    PJ_FALSE, PJ_FALSE);
    if (ret == 0)
        return PJ_EBUG;
#endif

/* With Apple SSL, we can't seem to enable certain ciphers only.
 * SSLSetEnabledCiphers() is deprecated and we only have
 * sec_protocol_options_append_tls_ciphersuite(),
 * but there's no API to remove certain or all ciphers.
 */
#if (PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_APPLE && PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_SCHANNEL)
    PJ_LOG(3,("", "..echo test w/ incompatible ciphers"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_DEFAULT, PJ_SSL_SOCK_PROTO_DEFAULT, 
                    PJ_TLS_RSA_WITH_DES_CBC_SHA, PJ_TLS_RSA_WITH_AES_256_CBC_SHA,
                    PJ_FALSE, PJ_FALSE);
    if (ret == 0)
        return PJ_EBUG;
#endif

#if (PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_SCHANNEL)
    PJ_LOG(3,("", "..echo test w/ client cert required but not provided"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_DEFAULT, PJ_SSL_SOCK_PROTO_DEFAULT, 
                    -1, -1,
                    PJ_TRUE, PJ_FALSE);
    if (ret == 0)
        return PJ_EBUG;

    PJ_LOG(3,("", "..echo test w/ client cert required and provided"));
    ret = echo_test(PJ_SSL_SOCK_PROTO_DEFAULT, PJ_SSL_SOCK_PROTO_DEFAULT, 
                    -1, -1,
                    PJ_TRUE, PJ_TRUE);
    if (ret != 0)
        return ret;
#endif

#if TEST_CERT_BUFFER
    PJ_LOG(3,("", "..certificate serial number test"));
    ret = cert_serial_test();
    if (ret != 0)
        return ret;

#if TEST_BAD_TIME_CERT
    PJ_LOG(3,("", "..certificate malformed validity time test"));
    ret = cert_bad_time_test();
    if (ret != 0)
        return ret;
#endif

    PJ_LOG(3,("", "..untrusted client certificate chain test"));
    ret = untrusted_chain_test();
    if (ret != 0)
        return ret;

#if (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_OPENSSL) || \
    (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_GNUTLS) || \
    (PJ_SSL_SOCK_IMP == PJ_SSL_SOCK_IMP_MBEDTLS)
    PJ_LOG(3,("", "..client without CA test"));
    ret = no_ca_client_test(PJ_FALSE);
    if (ret == 0)
        ret = no_ca_client_test(PJ_TRUE);
    if (ret != 0)
        return ret;
#else
    PJ_UNUSED_ARG(no_ca_client_test);
#endif
#endif

    PJ_LOG(3,("", "..large message test"));
    ret = large_msg_test();
    if (ret != 0)
        return ret;

#if WITH_BENCHMARK
#if (PJ_SSL_SOCK_IMP != PJ_SSL_SOCK_IMP_MBEDTLS)
    PJ_LOG(3,("", "..performance test"));
    ret = perf_test(PJ_IOQUEUE_MAX_HANDLES/2 - 1, 0);
    if (ret != 0)
        return ret;
#else
    PJ_UNUSED_ARG(perf_test);
#endif
#endif

    PJ_LOG(3,("", "..client non-SSL (handshake timeout 5 secs)"));
    ret = client_non_ssl(5000);
    if (ret != PJ_ETIMEDOUT)
        return ret;

#endif

    PJ_LOG(3,("", "..server non-SSL (handshake timeout 5 secs)"));
    ret = server_non_ssl(5000);
    if (ret != PJ_ETIMEDOUT)
        return ret;

    return 0;
}

#else   /* INCLUDE_SSLSOCK_TEST */
/* To prevent warning about "translation unit is empty"
 * when this test is disabled. 
 */
int dummy_ssl_sock_test;
#endif  /* INCLUDE_SSLSOCK_TEST */
