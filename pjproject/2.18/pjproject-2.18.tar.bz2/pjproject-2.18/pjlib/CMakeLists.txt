list(APPEND CMAKE_MESSAGE_CONTEXT "pjlib")

# ##############################################################################
# Options

include(Pj/Option)
include(CMakeDependentOption)

# Floating point support
option(PJLIB_WITH_FLOATING_POINT "Enable floating point support" ON)

# Threading support. Turning this off sets PJ_HAS_THREADS to 0 and keeps the
# threading library off the link line. Components that need threads, such as
# pjsua-lib and the WebRTC AEC, will not work; disable them separately.
option(PJLIB_WITH_THREADS "Enable threading support" ON)

# I/O queue backend
pj_option(PJLIB_WITH_IOQUEUE "I/O Queue implementation backend"
  DEFAULT select
  ALLOWED_VALUES select kqueue epoll iocp
)

# Use `libuuid` for `UUID` handling implementation where the OS has no
# native one, as autoconf
cmake_dependent_option(PJLIB_WITH_LIBUUID
  "Enable libuuid" ON
  "UNIX;NOT APPLE;NOT ANDROID;NOT BSD;NOT CYGWIN" OFF
)

# Enable SSL support with the selected implementation backend. auto takes the
# first of OpenSSL, GnuTLS and MbedTLS found, as autoconf; none (or empty)
# disables SSL, as --disable-ssl. A library backend asked for by name that is
# not found or cannot be linked stops the configure.
pj_option(PJLIB_WITH_SSL "Enable SSL support"
  DEFAULT auto
  ALLOWED_VALUES auto none openssl gnutls mbedtls darwin apple schannel
)

# ##############################################################################
# Target

add_library(pjlib
  src/pj/activesock.c
  src/pj/addr_resolv_sock.c
  src/pj/array.c
  src/pj/atomic_slist.c
  src/pj/config.c
  src/pj/ctype.c
  src/pj/errno.c
  src/pj/except.c
  src/pj/fifobuf.c
  src/pj/guid.c
  src/pj/hash.c
  src/pj/ioqueue_dummy.c
  src/pj/ioqueue_epoll.c
  src/pj/ioqueue_kqueue.c
  src/pj/ioqueue_select.c
  src/pj/list.c
  src/pj/lock.c
  src/pj/log.c
  src/pj/log_writer_stdout.c
  src/pj/os_info.c
  src/pj/os_time_common.c
  src/pj/os_timestamp_common.c
  src/pj/pool.c
  src/pj/pool_buf.c
  src/pj/pool_caching.c
  src/pj/pool_dbg.c
  src/pj/pool_policy_malloc.c
  src/pj/rand.c
  src/pj/rbtree.c
  src/pj/sock_bsd.c
  src/pj/sock_common.c
  src/pj/sock_qos_common.c
  src/pj/sock_qos_bsd.c
  src/pj/sock_qos_darwin.c
  src/pj/sock_select.c
  src/pj/ssl_sock_common.c
  src/pj/ssl_sock_darwin.c
  src/pj/ssl_sock_dump.c
  src/pj/ssl_sock_gtls.c
  src/pj/ssl_sock_mbedtls.c
  src/pj/ssl_sock_ossl.c
  src/pj/string.c
  src/pj/timer.c
  src/pj/types.c
  src/pj/unittest.c
)

# libpj, as make names it, so a shared build keeps make's libpj.so.2
set_target_properties(pjlib PROPERTIES OUTPUT_NAME pj)

# Ensure generated headers are found before source headers
target_include_directories(pjlib
  PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}/include>
)

# headers
target_sources(pjlib
  PUBLIC
    FILE_SET HEADERS
      BASE_DIRS
        include
      FILES
        include/pjlib.h
        include/pj/activesock.h
        include/pj/addr_resolv.h
        include/pj/argparse.h
        include/pj/array.h
        include/pj/assert.h
        include/pj/atomic_queue.h
        include/pj/atomic_slist.h
        include/pj/compat/assert.h
        include/pj/compat/cc_armcc.h
        include/pj/compat/cc_clang.h
        include/pj/compat/cc_codew.h
        include/pj/compat/cc_gcc.h
        include/pj/compat/cc_gcce.h
        include/pj/compat/cc_msvc.h
        include/pj/compat/cc_mwcc.h
        include/pj/compat/ctype.h
        include/pj/compat/errno.h
        include/pj/compat/high_precision.h
        include/pj/compat/limits.h
        include/pj/compat/m_alpha.h
        include/pj/compat/m_armv4.h
        include/pj/compat/m_i386.h
        include/pj/compat/m_m68k.h
        include/pj/compat/m_powerpc.h
        include/pj/compat/m_sparc.h
        include/pj/compat/m_x86_64.h
        include/pj/compat/malloc.h
        include/pj/compat/os_darwinos.h
        include/pj/compat/os_linux.h
        include/pj/compat/os_palmos.h
        include/pj/compat/os_rtems.h
        include/pj/compat/os_sunos.h
        include/pj/compat/os_symbian.h
        include/pj/compat/os_win32.h
        include/pj/compat/os_win32_wince.h
        include/pj/compat/os_winphone8.h
        include/pj/compat/os_winuwp.h
        include/pj/compat/rand.h
        include/pj/compat/setjmp.h
        include/pj/compat/size_t.h
        include/pj/compat/socket.h
        include/pj/compat/stdarg.h
        include/pj/compat/stdfileio.h
        include/pj/compat/string.h
        include/pj/compat/time.h
        include/pj/config.h
        include/pj/ctype.h
        include/pj/doxygen.h
        include/pj/errno.h
        include/pj/except.h
        include/pj/fifobuf.h
        include/pj/file_access.h
        include/pj/file_io.h
        include/pj/guid.h
        include/pj/hash.h
        include/pj/ioqueue.h
        include/pj/ip_helper.h
        include/pj/limits.h
        include/pj/list.h
        include/pj/list_i.h
        include/pj/lock.h
        include/pj/log.h
        include/pj/math.h
        include/pj/os.h
        include/pj/pool.h
        include/pj/pool_alt.h
        include/pj/pool_buf.h
        include/pj/pool_i.h
        include/pj/rand.h
        include/pj/rbtree.h
        include/pj/sock.h
        include/pj/sock_qos.h
        include/pj/sock_select.h
        include/pj/ssl_sock.h
        include/pj/string.h
        include/pj/string_i.h
        include/pj/timer.h
        include/pj/types.h
        include/pj/unicode.h
        include/pj/unittest.h
)

# atomic_queue is C++, used by the Android audio and codec backends only
if(PJ_WITH_CXX)
  target_sources(pjlib PRIVATE src/pj/atomic_queue.cpp)
  target_compile_features(pjlib PRIVATE cxx_std_11)
  set(PJ_HAS_ATOMIC_QUEUE 1)
else()
  set(PJ_HAS_ATOMIC_QUEUE 0)
endif()

# system APIs
if(WIN32 OR CYGWIN OR MINGW)
  target_sources(pjlib
    PRIVATE
      src/pj/file_io_win32.c
      src/pj/guid_win32.c
      src/pj/ioqueue_winnt.c
      src/pj/ip_helper_win32.c
      src/pj/os_core_win32.c
      src/pj/os_error_win32.c
      src/pj/os_time_win32.c
      src/pj/os_timestamp_win32.c
      src/pj/sock_qos_bsd.c
      src/pj/ssl_sock_schannel.c
      src/pj/unicode_win32.c
  )
else()
  target_sources(pjlib
    PRIVATE
      src/pj/file_access_unistd.c
      src/pj/file_io_ansi.c
      src/pj/ip_helper_generic.c
      src/pj/os_core_unix.c
      src/pj/os_error_unix.c
      src/pj/os_time_unix.c
      src/pj/os_timestamp_posix.c
  )
endif()

# Apple-specific
if(APPLE)
  target_sources(pjlib
    PRIVATE
      src/pj/os_core_darwin.m
      src/pj/ssl_sock_apple.m
      $<$<BOOL:${IOS}>:src/pj/os_info_iphone.m>
  )
endif()

# UUID: the system's own, else libuuid, else a simple generator. libuuid is
# looked for before choosing, as a new UUID_ROOT can turn it back on.
pj_find_optional(PJLIB_WITH_LIBUUID OFF UUID)
if(ANDROID)
  target_sources(pjlib PRIVATE src/pj/guid_android.c)
elseif(APPLE)
  target_sources(pjlib PRIVATE src/pj/guid_darwin.c)
elseif(BSD)
  target_sources(pjlib PRIVATE src/pj/guid_bsd.c)
elseif(WIN32 OR CYGWIN OR MINGW)
  target_sources(pjlib PRIVATE src/pj/file_access_win32.c)
elseif(PJLIB_WITH_LIBUUID)
  target_link_libraries(pjlib PRIVATE UUID::UUID)
  target_sources(pjlib PRIVATE src/pj/guid_uuid.c)
else()
  target_sources(pjlib PRIVATE src/pj/guid_simple.c)
endif()

# ##############################################################################
# Dependencies

# win32
include(CheckIncludeFile)
if(WIN32 OR CYGWIN OR MINGW)
  check_include_file(winsock.h PJ_HAS_WINSOCK_H)
  check_include_file(winsock2.h PJ_HAS_WINSOCK2_H)
  # mswsock.h does not compile on its own, it needs winsock2.h first. Under
  # its own cache key: the plain check of it once failed into
  # PJ_HAS_MSWSOCK_H, and a cached result is never probed again.
  include(CheckIncludeFiles)
  check_include_files("winsock2.h;mswsock.h" PJ_HAS_WINSOCK2_MSWSOCK_H)
  set(PJ_HAS_MSWSOCK_H "${PJ_HAS_WINSOCK2_MSWSOCK_H}")
  check_include_file(ws2tcpip.h PJ_HAS_WS2TCPIP_H)

  # iphlpapi for ip_helper_win32.c, mswsock for AcceptEx() in ioqueue_winnt.c
  target_link_libraries(pjlib PRIVATE ole32 winmm iphlpapi)
  if(PJ_HAS_MSWSOCK_H)
    target_link_libraries(pjlib PRIVATE mswsock)
  endif()
  # Public: pjlib's headers bring in Winsock, and code using them, e.g. the
  # bundled srtp, calls it directly. A shared pjlib does not pass on a
  # private one; autoconf links it into everything.
  if(PJ_HAS_WINSOCK2_H)
    target_link_libraries(pjlib PUBLIC ws2_32)
  elseif(PJ_HAS_WINSOCK_H)
    target_link_libraries(pjlib PUBLIC wsock32)
  endif()
endif()

# apple
if(APPLE)
  # The autotools build links these globally (aconfigure.ac). pjlib has
  # Objective-C sources of its own -- os_info_iphone.m uses UIDevice,
  # ssl_sock_apple.m uses NSLock -- and because pjlib is a static library the
  # missing frameworks surface only when an application is finally linked.
  #
  # Through an imported target rather than the paths find_library() returns:
  # those carry the SDK version of the machine that built the package, so an
  # installed Pj would not relocate to another Xcode.
  pj_find_package(AppleFoundation)
  if(AppleFoundation_FOUND)
    target_link_libraries(pjlib PUBLIC AppleFoundation::AppleFoundation)
  endif()

  # pjlib compiles a C++ source of its own (atomic_queue.cpp), so a consumer
  # needs the C++ runtime even when the consumer is pure C. Nothing surfaces
  # this while building the archive; it appears as undefined std::terminate()
  # when an application is linked. A C++ link adds it already, and ld warns
  # about the duplicate.
  if(PJ_WITH_CXX)
    target_link_libraries(pjlib PUBLIC
      "$<$<NOT:$<LINK_LANGUAGE:CXX,OBJCXX>>:c++>")
  endif()
endif()

# math library
if(NOT (WIN32 OR CYGWIN OR MINGW))
  find_library(MATH_LIBRARY m)
  # A toolchain for a Generic system (no OS, or an RTOS such as Zephyr)
  # ships libm beside its libc and resolves -lm through its multilib specs,
  # where find_library() does not look.
  if(MATH_LIBRARY OR CMAKE_SYSTEM_NAME STREQUAL "Generic")
    target_link_libraries(pjlib PUBLIC m)
  elseif(PJLIB_WITH_FLOATING_POINT)
    pj_force_set(PJLIB_WITH_FLOATING_POINT OFF "math library not found")
  endif()
endif()

# threading library
if(PJLIB_WITH_THREADS)
  pj_find_package(Threads)
  if(Threads_FOUND)
    target_link_libraries(pjlib PRIVATE Threads::Threads)
  endif()
else()
  target_compile_definitions(pjlib PUBLIC PJ_HAS_THREADS=0)
endif()

# Functions libc may not hold, as autoconf: socket() and gethostbyname() are
# in libsocket and libnsl on Solaris, clock_gettime() in librt before glibc
# 2.17. Each library is linked only when the function needs it.
if(UNIX)
  include(CheckSymbolExists)
  include(CheckLibraryExists)

  check_symbol_exists(socket "sys/types.h;sys/socket.h" PJ_LIBC_HAS_SOCKET)
  if(NOT PJ_LIBC_HAS_SOCKET)
    check_library_exists(socket socket "" PJ_LIBSOCKET_HAS_SOCKET)
    if(PJ_LIBSOCKET_HAS_SOCKET)
      target_link_libraries(pjlib PUBLIC socket)
    endif()
  endif()

  check_symbol_exists(gethostbyname "netdb.h" PJ_LIBC_HAS_GETHOSTBYNAME)
  if(NOT PJ_LIBC_HAS_GETHOSTBYNAME)
    check_library_exists(nsl gethostbyname "" PJ_LIBNSL_HAS_GETHOSTBYNAME)
    if(PJ_LIBNSL_HAS_GETHOSTBYNAME)
      target_link_libraries(pjlib PUBLIC nsl)
    endif()
  endif()

  check_symbol_exists(clock_gettime "time.h" PJ_LIBC_HAS_CLOCK_GETTIME)
  if(NOT PJ_LIBC_HAS_CLOCK_GETTIME)
    check_library_exists(rt clock_gettime "" PJ_LIBRT_HAS_CLOCK_GETTIME)
    if(PJ_LIBRT_HAS_CLOCK_GETTIME)
      target_link_libraries(pjlib PUBLIC rt)
    endif()
  endif()
endif()

# ssl
add_library(pjlib-ssl INTERFACE) # a target to expose SSL deps

# FindOpenSSL does no link test; reject an OpenSSL that is found but cannot be
# linked, e.g. built for another architecture, as autoconf's AC_CHECK_LIB does
function(_pj_check_openssl_usable)
  include(Pj/CheckLibraryUsable)
  pj_check_library_usable(OpenSSL ${PJ_FIND_QUIET}
    CODE [=[
      #include <openssl/err.h>
      #include <openssl/ssl.h>
      int main(void) { SSL_CTX_free(0); ERR_clear_error(); return 0; }
    ]=]
    INCLUDE_DIRS ${OPENSSL_INCLUDE_DIR}
    LIBRARIES OpenSSL::SSL OpenSSL::Crypto
  )
endfunction()

function(_pj_check_gnutls_usable)
  include(Pj/CheckLibraryUsable)
  pj_check_library_usable(GnuTLS ${PJ_FIND_QUIET}
    CODE [=[
      #include <gnutls/gnutls.h>
      int main(void) { gnutls_global_deinit(); return 0; }
    ]=]
    INCLUDE_DIRS ${GNUTLS_INCLUDE_DIR}
    LIBRARIES GnuTLS::GnuTLS
  )
endfunction()

# Mbed TLS 4.x moved the crypto library to TF-PSA-Crypto
function(_pj_mbedtls_libraries out)
  if(TARGET MbedTLS::tfpsacrypto)
    set(_crypto MbedTLS::tfpsacrypto)
  else()
    set(_crypto MbedTLS::mbedcrypto)
  endif()
  set(${out} MbedTLS::mbedtls MbedTLS::mbedx509 ${_crypto} PARENT_SCOPE)
endfunction()

function(_pj_check_mbedtls_usable)
  include(Pj/CheckLibraryUsable)
  _pj_mbedtls_libraries(_libs)
  pj_check_library_usable(MbedTLS ${PJ_FIND_QUIET}
    CODE [=[
      #include <mbedtls/ssl.h>
      int main(void) {
          mbedtls_ssl_config conf;
          mbedtls_ssl_config_init(&conf);
          mbedtls_ssl_config_free(&conf);
          return 0;
      }
    ]=]
    LIBRARIES ${_libs}
  )
endfunction()

function(_pj_ssl_fail reason)
  message(FATAL_ERROR "PJLIB_WITH_SSL=${PJLIB_WITH_SSL} cannot be used: "
    "${reason}. Set PJLIB_WITH_SSL to auto, none or another backend.")
endfunction()

pj_retry_on_new_root(PJLIB_WITH_SSL OpenSSL)
pj_retry_on_new_root(PJLIB_WITH_SSL GnuTLS)
pj_retry_on_new_root(PJLIB_WITH_SSL MbedTLS)
set(_pj_ssl "${PJLIB_WITH_SSL}")
if(_pj_ssl STREQUAL "none")
  set(_pj_ssl "")
elseif(_pj_ssl STREQUAL "auto")
  pj_find_openssl(COMPONENTS Crypto SSL QUIET)
  if(OPENSSL_FOUND)
    _pj_check_openssl_usable()
    if(NOT OpenSSL_USABLE)
      message(STATUS "[!] OpenSSL was found but cannot be linked")
    endif()
  endif()
  if(OPENSSL_FOUND AND OpenSSL_USABLE)
    set(_pj_ssl openssl)
  else()
    find_package(GnuTLS QUIET)
    if(GNUTLS_FOUND)
      _pj_check_gnutls_usable()
      if(NOT GnuTLS_USABLE)
        message(STATUS "[!] GnuTLS was found but cannot be linked")
      endif()
    endif()
    if(GNUTLS_FOUND AND GnuTLS_USABLE)
      set(_pj_ssl gnutls)
    else()
      find_package(MbedTLS CONFIG QUIET)
      if(MbedTLS_FOUND)
        _pj_check_mbedtls_usable()
        if(NOT MbedTLS_USABLE)
          message(STATUS "[!] MbedTLS was found but cannot be linked")
        endif()
      endif()
      if(MbedTLS_FOUND AND MbedTLS_USABLE)
        set(_pj_ssl mbedtls)
      else()
        set(_pj_ssl "")
        message(STATUS "[!] No usable OpenSSL, GnuTLS or MbedTLS found. building without SSL")
      endif()
    endif()
  endif()
endif()
# Each backend is searched here unless it already was, by auto above or by a
# parent project
if(_pj_ssl STREQUAL "openssl")
  if(NOT OPENSSL_FOUND)
    pj_find_openssl(COMPONENTS Crypto SSL ${PJ_FIND_QUIET})
  endif()
  if(OPENSSL_FOUND)
    _pj_check_openssl_usable()
  endif()
  if(OPENSSL_FOUND AND OpenSSL_USABLE)
    target_link_libraries(pjlib-ssl INTERFACE OpenSSL::Crypto OpenSSL::SSL)
  elseif(OPENSSL_FOUND)
    _pj_ssl_fail("OpenSSL found but cannot be linked")
  else()
    _pj_ssl_fail("OpenSSL not found")
  endif()
elseif(_pj_ssl STREQUAL "gnutls")
  if(NOT GNUTLS_FOUND)
    find_package(GnuTLS ${PJ_FIND_QUIET})
  endif()
  if(GNUTLS_FOUND)
    _pj_check_gnutls_usable()
  endif()
  if(GNUTLS_FOUND AND GnuTLS_USABLE)
    target_link_libraries(pjlib-ssl INTERFACE GnuTLS::GnuTLS)
  elseif(GNUTLS_FOUND)
    _pj_ssl_fail("GnuTLS found but cannot be linked")
  else()
    _pj_ssl_fail("GnuTLS not found")
  endif()
elseif(_pj_ssl STREQUAL "mbedtls")
  if(NOT MbedTLS_FOUND)
    find_package(MbedTLS CONFIG ${PJ_FIND_QUIET})
  endif()
  if(MbedTLS_FOUND)
    _pj_check_mbedtls_usable()
  endif()
  if(MbedTLS_FOUND AND MbedTLS_USABLE)
    _pj_mbedtls_libraries(_pj_mbedtls_libs)
    target_link_libraries(pjlib-ssl INTERFACE ${_pj_mbedtls_libs})
  elseif(MbedTLS_FOUND)
    _pj_ssl_fail("MbedTLS found but cannot be linked")
  else()
    _pj_ssl_fail("MbedTLS not found")
  endif()
elseif(_pj_ssl STREQUAL "darwin")
  if(NOT APPLE)
    message(FATAL_ERROR "PJLIB_WITH_SSL=darwin requires an Apple platform")
  endif()
  find_library(Security_LIBRARY Security REQUIRED)
  target_link_libraries(pjlib-ssl INTERFACE "${Security_LIBRARY}")
elseif(_pj_ssl STREQUAL "apple")
  if(NOT APPLE)
    message(FATAL_ERROR "PJLIB_WITH_SSL=apple requires an Apple platform")
  endif()
  # ssl_sock_apple.m delivers every asynchronous event through
  # ssl_network_event_poll(), which is only called from ioqueue_select.c.
  # With any other ioqueue the Network.framework event queue is never
  # drained and no connection ever completes, so reject the combination
  # here rather than at runtime.
  if(NOT PJLIB_WITH_IOQUEUE STREQUAL "select")
    message(FATAL_ERROR
      "PJLIB_WITH_SSL=apple requires PJLIB_WITH_IOQUEUE=select "
      "(got '${PJLIB_WITH_IOQUEUE}')")
  endif()
  find_library(Security_LIBRARY Security REQUIRED)
  find_library(Network_LIBRARY Network REQUIRED)
  # ssl_sock_apple.m uses NSLock
  find_library(Foundation_LIBRARY Foundation REQUIRED)
  target_link_libraries(pjlib-ssl
    INTERFACE
      "${Security_LIBRARY}"
      "${Network_LIBRARY}"
      "${Foundation_LIBRARY}"
  )
elseif(_pj_ssl STREQUAL "schannel")
  # ssl_sock_schannel.c compiles to nothing on other Windows compilers
  if(NOT MSVC)
    message(FATAL_ERROR "PJLIB_WITH_SSL=schannel requires MSVC")
  endif()
  target_link_libraries(pjlib-ssl INTERFACE secur32 crypt32 bcrypt shlwapi)
endif()
target_link_libraries(pjlib PRIVATE pjlib-ssl)

# The backend in use, for the configured header, pjsip and PjConfig.cmake.in
if(_pj_ssl)
  message(STATUS "SSL backend: ${_pj_ssl}")
else()
  message(STATUS "SSL backend: none")
endif()
# A value given with -D would win over the INTERNAL one, and the configured
# header would then claim a backend that is not built; drop it first
get_property(_pj_type CACHE PJ_SSL_BACKEND PROPERTY TYPE)
if(_pj_type AND NOT _pj_type STREQUAL "INTERNAL")
  message(WARNING "PJ_SSL_BACKEND is ignored; PJLIB_WITH_SSL chooses the SSL "
    "backend")
endif()
unset(_pj_type)
unset(PJ_SSL_BACKEND CACHE)
set(PJ_SSL_BACKEND "${_pj_ssl}" CACHE INTERNAL "SSL backend in use")
unset(_pj_ssl)

# ##############################################################################
# Configuration

# Do not attempt to guess default configuration
target_compile_definitions(pjlib PUBLIC PJ_AUTOCONF=1)

# architecture
block(SCOPE_FOR VARIABLES)
  include(Pj/DetectArch)
  pj_detect_arch(arch)

  # architecture name
  set(PJ_M_NAME "${arch}")

  # architecture macros
  target_compile_definitions(pjlib PUBLIC
    $<$<STREQUAL:${arch},"i386">:PJ_M_I386=1>
    $<$<STREQUAL:${arch},"x86_64">:PJ_M_X86_64=1>
    $<$<STREQUAL:${arch},"ia64">:PJ_M_IA64=1>
    $<$<STREQUAL:${arch},"m68k">:PJ_M_M68K=1>
    $<$<STREQUAL:${arch},"alpha">:PJ_M_ALPHA=1>
    $<$<STREQUAL:${arch},"mips64">:PJ_M_MIPS=1>
    $<$<STREQUAL:${arch},"mips">:PJ_M_MIPS=1>
    $<$<STREQUAL:${arch},"sparc">:PJ_M_SPARC=1>
    $<$<STREQUAL:${arch},"arm64">:PJ_M_ARM64=1>
    $<$<STREQUAL:${arch},"armv7">:PJ_M_ARMV7=1>
    $<$<STREQUAL:${arch},"armv4">:PJ_M_ARMV4=1>
    $<$<STREQUAL:${arch},"powerpc">:PJ_M_POWERPC=1>
    $<$<STREQUAL:${arch},"nios2">:PJ_M_NIOS2=1>
  )

  # endianness detection
  include(TestBigEndian)
  test_big_endian(WORDS_BIGENDIAN)

  # floating point support
  if(PJLIB_WITH_FLOATING_POINT)
    set(PJ_HAS_FLOATING_POINT 1)
  else()
    set(PJ_HAS_FLOATING_POINT 0)
  endif()

  # write configured header
  configure_file(
    include/pj/compat/m_auto.h.cm
    include/pj/compat/m_auto.h
    @ONLY
  )
endblock()

# operating system
block(SCOPE_FOR VARIABLES)
  #
  # os detection
  #

  string(TOLOWER ${CMAKE_SYSTEM_NAME} PJ_OS_NAME)

  if(ANDROID)
    set(PJ_ANDROID 1)
  elseif(WIN32 OR CYGWIN OR MINGW)
    set(PJ_WIN32 1)
    set(PJ_WIN32_WINNT 0x0501)
    set(WIN32_LEAN_AND_MEAN 1)
    set(NOMINMAX 1)

    # the target's, not the build machine's: it sizes pj_ssize_t
    if(CMAKE_SIZEOF_VOID_P EQUAL 8)
      set(PJ_WIN64 1)
    endif()
  elseif(APPLE)
    set(PJ_DARWINOS 1)
  elseif(LINUX)
    set(PJ_LINUX 1)
  elseif(BSD)
    set(PJ_BSD 1)
  else()
    # manual system name checks
    if(PJ_OS_NAME MATCHES "rtems")
      set(PJ_RTEMS 1)
    elseif(PJ_OS_NAME MATCHES "sunos|solaris")
      set(PJ_SUNOS 1)
    endif()
  endif()

  set(PJ_HAS_ERRNO_VAR 1)
  set(PJ_HAS_HIGH_RES_TIMER 1)
  set(PJ_HAS_MALLOC 1)
  set(PJ_NATIVE_STRING_IS_UNICODE 0)
  set(PJ_ATOMIC_VALUE_TYPE "long")

  if(CMAKE_SIZEOF_VOID_P EQUAL 8)
    set(PJ_POOL_ALIGNMENT 8)
  else()
    set(PJ_POOL_ALIGNMENT 4)
  endif()

  #
  # headers
  #

  check_include_file(arpa/inet.h PJ_HAS_ARPA_INET_H)
  check_include_file(assert.h PJ_HAS_ASSERT_H)
  check_include_file(ctype.h PJ_HAS_CTYPE_H)

  if(WIN32 OR CYGWIN OR MINGW)
    set(PJ_HAS_ERRNO_H 0)
  else()
    check_include_file(errno.h PJ_HAS_ERRNO_H)
  endif()

  check_include_file(fcntl.h PJ_HAS_FCNTL_H)
  check_include_file(limits.h PJ_HAS_LIMITS_H)
  check_include_file(linux/socket.h PJ_HAS_LINUX_SOCKET_H)
  check_include_file(malloc.h PJ_HAS_MALLOC_H)
  check_include_file(netdb.h PJ_HAS_NETDB_H)
  check_include_file(netinet/in_systm.h PJ_HAS_NETINET_IN_SYSTM_H)
  check_include_file(netinet/in.h PJ_HAS_NETINET_IN_H)
  check_include_file(netinet/ip.h PJ_HAS_NETINET_IP_H)
  check_include_file(netinet/tcp.h PJ_HAS_NETINET_TCP_H)
  check_include_file(net/if.h PJ_HAS_NET_IF_H)
  check_include_file(semaphore.h PJ_HAS_SEMAPHORE_H)
  check_include_file(setjmp.h PJ_HAS_SETJMP_H)
  check_include_file(stdarg.h PJ_HAS_STDARG_H)
  check_include_file(stddef.h PJ_HAS_STDDEF_H)
  check_include_file(stdio.h PJ_HAS_STDIO_H)
  check_include_file(stdint.h PJ_HAS_STDINT_H)
  check_include_file(stdlib.h PJ_HAS_STDLIB_H)
  check_include_file(string.h PJ_HAS_STRING_H)
  check_include_file(strings.h PJ_HAS_STRINGS_H)
  check_include_file(inttypes.h PJ_HAS_INTTYPES_H)
  check_include_file(sys/ioctl.h PJ_HAS_SYS_IOCTL_H)
  check_include_file(sys/select.h PJ_HAS_SYS_SELECT_H)
  check_include_file(sys/socket.h PJ_HAS_SYS_SOCKET_H)
  check_include_file(sys/time.h PJ_HAS_SYS_TIME_H)
  check_include_file(sys/timeb.h PJ_HAS_SYS_TIMEB_H)
  check_include_file(sys/types.h PJ_HAS_SYS_TYPES_H)
  check_include_file(sys/filio.h PJ_HAS_SYS_FILIO_H)
  check_include_file(sys/sockio.h PJ_HAS_SYS_SOCKIO_H)
  check_include_file(sys/utsname.h PJ_HAS_SYS_UTSNAME_H)
  check_include_file(time.h PJ_HAS_TIME_H)
  check_include_file(unistd.h PJ_HAS_UNISTD_H)
  check_include_file(execinfo.h PJ_HAS_EXECINFO_H)

  if(ANDROID)
    set(PJ_HAS_ANDROID_ALARM_H 1)
  endif()

  #
  # functions
  #

  include(CheckSymbolExists)
  check_symbol_exists(localtime_r time.h PJ_HAS_LOCALTIME_R)
  # The header alone is not enough: bionic ships <ifaddrs.h> at every API
  # level but declares getifaddrs() only from API 24.
  #
  # Probed under its own cache key, not straight into PJ_HAS_IFADDRS_H. That
  # name once held the result of a check_include_file() probe, and these
  # checks skip their test whenever the result variable is already cached, so
  # reusing it would leave every build tree configured before this change
  # stuck on the old answer.
  check_symbol_exists(getifaddrs ifaddrs.h PJ_HAS_GETIFADDRS)
  # Quoted: a failed check leaves PJ_HAS_GETIFADDRS empty, and an unquoted
  # empty expansion would turn this into an unset(), which would let that
  # stale cache entry show through again.
  set(PJ_HAS_IFADDRS_H "${PJ_HAS_GETIFADDRS}")
  if(WIN32)
    # Probed against the same _WIN32_WINNT the build uses, as ws2tcpip.h
    # declares inet_pton() and inet_ntop() only from Vista (0x0600). Under
    # their own cache keys, for the same reason as PJ_HAS_GETIFADDRS above:
    # the POSIX probes once failed into the PJ_SOCK_HAS_* names here.
    include(CMakePushCheckState)
    cmake_push_check_state()
    set(CMAKE_REQUIRED_DEFINITIONS -D_WIN32_WINNT=${PJ_WIN32_WINNT})
    set(CMAKE_REQUIRED_LIBRARIES ws2_32)
    check_symbol_exists(inet_pton "winsock2.h;ws2tcpip.h"
      PJ_WS2_HAS_INET_PTON)
    check_symbol_exists(inet_ntop "winsock2.h;ws2tcpip.h"
      PJ_WS2_HAS_INET_NTOP)
    check_symbol_exists(getaddrinfo "winsock2.h;ws2tcpip.h"
      PJ_WS2_HAS_GETADDRINFO)
    cmake_pop_check_state()
    set(PJ_SOCK_HAS_INET_PTON "${PJ_WS2_HAS_INET_PTON}")
    set(PJ_SOCK_HAS_INET_NTOP "${PJ_WS2_HAS_INET_NTOP}")
    set(PJ_SOCK_HAS_GETADDRINFO "${PJ_WS2_HAS_GETADDRINFO}")
  else()
    check_symbol_exists(inet_aton arpa/inet.h PJ_SOCK_HAS_INET_ATON)
    check_symbol_exists(inet_pton arpa/inet.h PJ_SOCK_HAS_INET_PTON)
    check_symbol_exists(inet_ntop arpa/inet.h PJ_SOCK_HAS_INET_NTOP)
    check_symbol_exists(getaddrinfo netdb.h PJ_SOCK_HAS_GETADDRINFO)
    check_symbol_exists(socketpair sys/socket.h PJ_SOCK_HAS_SOCKETPAIR)
  endif()

  #
  # compilation checks
  #

  include(CheckSourceCompiles)

  # determine if sockaddr_in has sin_len member
  check_source_compiles(C [=[
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>

    int main(void) {
        struct sockaddr_in a;
        a.sin_len=0;
        return 0;
    }
  ]=] PJ_SOCKADDR_HAS_LEN)

  # determine if socklen_t is available
  check_source_compiles(C [=[
    #include <sys/types.h>
    #include <sys/socket.h>

    int main(void) {
        socklen_t xxx = 0;
        return 0;
    }
  ]=] PJ_HAS_SOCKLEN_T)

  # determine if IPV6_V6ONLY is available
  check_source_compiles(C [=[
    #include <sys/socket.h>
    #include <netinet/in.h>

    int main(void) {
        int opt = IPV6_V6ONLY;
        return 0;
    }
  ]=] PJ_SOCK_HAS_IPV6_V6ONLY)

  # determine if SO_ERROR is available
  if(WIN32 OR CYGWIN OR MINGW)
    set(PJ_HAS_SO_ERROR 1)
  else()
    check_source_compiles(C [=[
      #include <sys/types.h>
      #include <sys/socket.h>
      #include <netinet/in.h>
      #include <arpa/inet.h>

      int main(void) {
          int i=SO_ERROR;
          return 0;
      }
    ]=] PJ_HAS_SO_ERROR)
  endif()

  #
  # pthread capabilities
  #

  if(UNIX)
    check_include_file(pthread.h PJ_HAS_PTHREAD_H)
    check_include_file(pthread_np.h PJ_HAS_PTHREAD_NP_H)
  endif()

  if(PJ_HAS_PTHREAD_H)
    # determine if RW-mutex is available
    check_source_compiles(C [=[
      #include <pthread.h>

      int main(void) {
          pthread_rwlock_t *x;
          return 0;
      }
    ]=] _has_pthread_rwlock)

    # if rwmutex is not detected, check again but this time with
    # _POSIX_READER_WRITER_LOCKS defined (newlib needs this), and build with
    # it if that works, as autoconf
    if(NOT _has_pthread_rwlock)
      check_source_compiles(C [=[
        #define _POSIX_READER_WRITER_LOCKS
        #include <pthread.h>

        int main(void) {
            pthread_rwlock_t *x;
            return 0;
        }
      ]=] _has_pthread_rwlock_posix)
      if(_has_pthread_rwlock_posix)
        set(_has_pthread_rwlock 1)
        target_compile_definitions(pjlib
          PUBLIC
            _POSIX_THREADS
            _POSIX_READER_WRITER_LOCKS
        )
      endif()
    endif()

    if(_has_pthread_rwlock)
      set(PJ_EMULATE_RWMUTEX 0)
    else()
      set(PJ_EMULATE_RWMUTEX 1)
    endif()

    unset(_has_pthread_rwlock)

    # do we have pthread_mutexattr_settype()?
    check_source_compiles(C [=[
      #include <pthread.h>

      int main(void) {
          pthread_mutexattr_settype(0, PTHREAD_MUTEX_FAST_NP);
          return 0;
      }
    ]=] PJ_HAS_PTHREAD_MUTEXATTR_SETTYPE)

    # does pthread_mutexattr_t has "recursive" member?
    check_source_compiles(C [=[
      #include <pthread.h>

      int main(void) {
          pthread_mutexattr_t attr;
          attr.recursive=1;
          return 0;
      }
    ]=] PJ_PTHREAD_MUTEXATTR_T_HAS_RECURSIVE)
  endif()


  if(PJ_HAS_PTHREAD_NP_H)
    check_symbol_exists(pthread_setname_np pthread_np.h
      PJ_HAS_PTHREAD_SETNAME_NP
    )
    check_symbol_exists(pthread_set_name_np pthread_np.h
      PJ_HAS_PTHREAD_SET_NAME_NP
    )
  else()
    # declared in pthread.h on Linux, Android and Darwin (glibc: _GNU_SOURCE)
    include(CMakePushCheckState)
    cmake_push_check_state()
    set(CMAKE_REQUIRED_DEFINITIONS -D_GNU_SOURCE)
    # glibc < 2.34 has it in libpthread only
    if(TARGET Threads::Threads)
      set(CMAKE_REQUIRED_LIBRARIES Threads::Threads)
    endif()
    check_symbol_exists(pthread_setname_np pthread.h
      PJ_HAS_PTHREAD_SETNAME_NP
    )
    cmake_pop_check_state()
  endif()

  #
  # manual checks
  #

  # Determine if select() requires nfds to be filled up with
  # correct value (max_fd+1). If zero, nfds will be filled up with
  # PJ_FD_SETSIZE
  if(PJ_RTEMS)
    set(PJ_SELECT_NEEDS_NFDS 1)
  else()
    set(PJ_SELECT_NEEDS_NFDS 0)
  endif()

  # Determine if pj_thread_create() should enforce thread stack size when
  # creating thread. Default is zero, to allow OS to allocate appropriate
  # thread's stack size.
  if(PJ_RTEMS)
    set(PJ_THREAD_SET_STACK_SIZE 1)
  else()
    set(PJ_THREAD_SET_STACK_SIZE 0)
  endif()

  # Determine if pj_thread_create() should allocate thread's stack from
  # the pool. Default is zero, to let OS allocate thread's stack.
  if(PJ_RTEMS)
    set(PJ_THREAD_ALLOCATE_STACK 1)
  else()
    set(PJ_THREAD_ALLOCATE_STACK 0)
  endif()

  # This value specifies the value set in errno by the OS when a non-blocking
  # socket recv() can not return immediate data.
  if(WIN32 OR CYGWIN OR MINGW)
    set(PJ_BLOCKING_ERROR_VAL WSAEWOULDBLOCK)
  else()
    set(PJ_BLOCKING_ERROR_VAL EAGAIN)
  endif()

  # This value specifies the value set in errno by the OS when a non-blocking
  # socket connect() can not get connected immediately.
  if(WIN32 OR CYGWIN OR MINGW)
    set(PJ_BLOCKING_CONNECT_ERROR_VAL WSAEWOULDBLOCK)
  else()
    set(PJ_BLOCKING_CONNECT_ERROR_VAL EINPROGRESS)
  endif()

  #
  # configuration checks
  #

  # i/o queue implementation
  if(PJLIB_WITH_IOQUEUE STREQUAL "iocp" AND NOT WIN32)
    message(FATAL_ERROR "PJLIB_WITH_IOQUEUE=iocp requires Windows")
  endif()
  if(NOT PJLIB_WITH_IOQUEUE STREQUAL "")
    string(TOUPPER "PJ_IOQUEUE_IMP_${PJLIB_WITH_IOQUEUE}" PJ_IOQUEUE_IMP)
  else()
    set(PJ_IOQUEUE_IMP "PJ_IOQUEUE_IMP_NONE")
  endif()

  # ssl
  if(NOT PJ_SSL_BACKEND STREQUAL "")
    set(PJ_HAS_SSL_SOCK 1)
    string(TOUPPER "PJ_SSL_SOCK_IMP_${PJ_SSL_BACKEND}" PJ_SSL_SOCK_IMP)
  else()
    set(PJ_HAS_SSL_SOCK 0)
    set(PJ_SSL_SOCK_IMP "PJ_SSL_SOCK_IMP_NONE")
  endif()

  # write configured header
  configure_file(
    include/pj/compat/os_auto.h.cm
    include/pj/compat/os_auto.h
    @ONLY
  )
endblock()

# generate a dummy `pj/config_site.h` if it does not exist
if(NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/include/pj/config_site.h")
  file(TOUCH "${CMAKE_CURRENT_SOURCE_DIR}/include/pj/config_site.h")
endif()

# add generated files includes
target_sources(pjlib
  PUBLIC
    FILE_SET config_headers TYPE HEADERS
      BASE_DIRS
        "${CMAKE_CURRENT_BINARY_DIR}/include"
        "${CMAKE_CURRENT_SOURCE_DIR}/include"
      FILES
        "${CMAKE_CURRENT_SOURCE_DIR}/include/pj/config_site.h"
        # config_site.h is where a build states its overrides, and the
        # documented way to write one is to include config_site_sample.h and
        # pick a profile from it. Installing the former without the latter
        # leaves such a config_site.h dangling in the installed tree.
        "${CMAKE_CURRENT_SOURCE_DIR}/include/pj/config_site_sample.h"
        "${CMAKE_CURRENT_BINARY_DIR}/include/pj/compat/m_auto.h"
        "${CMAKE_CURRENT_BINARY_DIR}/include/pj/compat/os_auto.h"
)

# ##############################################################################
# pjlib test application

if(BUILD_TESTING)
  add_executable(pjlib-test
    src/pjlib-test/activesock.c
    src/pjlib-test/atomic.c
    src/pjlib-test/atomic_slist.c
    src/pjlib-test/echo_clt.c
    src/pjlib-test/errno.c
    src/pjlib-test/exception.c
    src/pjlib-test/fifobuf.c
    src/pjlib-test/file.c
    src/pjlib-test/hash_test.c
    src/pjlib-test/ioq_perf.c
    src/pjlib-test/ioq_udp.c
    src/pjlib-test/ioq_stress_test.c
    src/pjlib-test/ioq_unreg.c
    src/pjlib-test/ioq_tcp.c
    src/pjlib-test/ioq_iocp_unreg_test.c
    src/pjlib-test/list.c
    src/pjlib-test/mutex.c
    src/pjlib-test/os.c
    src/pjlib-test/pool.c
    src/pjlib-test/pool_perf.c
    src/pjlib-test/rand.c
    src/pjlib-test/rbtree.c
    src/pjlib-test/select.c
    src/pjlib-test/sleep.c
    src/pjlib-test/sock.c
    src/pjlib-test/sock_perf.c
    src/pjlib-test/ssl_sock.c
    src/pjlib-test/ssl_sock_apple_test.c
    src/pjlib-test/ssl_sock_stress.c
    src/pjlib-test/string.c
    src/pjlib-test/test.c
    src/pjlib-test/thread.c
    src/pjlib-test/timer.c
    src/pjlib-test/timestamp.c
    src/pjlib-test/udp_echo_srv_sync.c
    src/pjlib-test/udp_echo_srv_ioqueue.c
    src/pjlib-test/unittest_test.c
    src/pjlib-test/util.c
    src/pjlib-test/${PJ_TEST_MAIN}
  )

  target_link_libraries(pjlib-test PRIVATE pjlib pjlib-ssl)
  if(APPLE)
    # ssl_sock_apple_test.c calls Security.framework directly,
    # independent of which SSL backend was configured.
    find_library(Security_LIBRARY Security REQUIRED)
    find_library(CoreFoundation_LIBRARY CoreFoundation REQUIRED)
    target_link_libraries(pjlib-test PRIVATE
      "${Security_LIBRARY}" "${CoreFoundation_LIBRARY}")
  endif()

  # The test certificates are found relative to pjlib/build, where make
  # runs it
  add_test(NAME pjlib-test
    COMMAND pjlib-test
    WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/build"
  )
endif()

# ##############################################################################
# pjlib++

add_library(pjlib++ INTERFACE)

# headers
target_sources(pjlib++
  INTERFACE
    FILE_SET HEADERS
      BASE_DIRS
        include/
      FILES
        include/pjlib++.hpp
        include/pj++/file.hpp
        include/pj++/hash.hpp
        include/pj++/list.hpp
        include/pj++/lock.hpp
        include/pj++/os.hpp
        include/pj++/pool.hpp
        include/pj++/proactor.hpp
        include/pj++/scanner.hpp
        include/pj++/sock.hpp
        include/pj++/string.hpp
        include/pj++/timer.hpp
        include/pj++/tree.hpp
        include/pj++/types.hpp
)

# dependencies
target_link_libraries(pjlib++ INTERFACE pjlib)

# ##############################################################################
# pjlib++ test application

if(BUILD_TESTING AND FALSE) # does not compile
  add_executable(pjlib++-test
    src/pjlib++-test/main.cpp
  )

  target_link_libraries(pjlib++-test PRIVATE pjlib++)

  add_test(NAME pjlib++-test COMMAND pjlib++-test)
endif()

# For the pkg-config file: the files of the dependencies found here
pj_pc_remember_imported_targets()
