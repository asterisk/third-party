include(Pj/PackageRoot)
find_package(PkgConfig QUIET)
if(PKG_CONFIG_FOUND)
  pj_pkg_search_module(PC_GSM QUIET gsm libgsm)
  set(GSM_VERSION ${PC_GSM_VERSION})
endif()

find_path(GSM_INCLUDE_DIR
  NAMES
    "gsm.h"
  HINTS
    ${PC_GSM_INCLUDEDIR}
    ${PC_GSM_INCLUDE_DIRS}
  PATH_SUFFIXES
    gsm
)
mark_as_advanced(GSM_INCLUDE_DIR)

find_library(GSM_LIBRARY
  NAMES
    gsm
    libgsm
  HINTS
    ${PC_GSM_LIBDIR}
    ${PC_GSM_LIBRARY_DIRS}
)
mark_as_advanced(GSM_LIBRARY)

if(GSM_INCLUDE_DIR AND GSM_LIBRARY)
  include(Pj/CheckLibraryUsable)
  pj_check_library_usable(GSM
    CODE "
#include <gsm.h>
int main(void) { gsm g = gsm_create(); gsm_destroy(g); return 0; }
"
    INCLUDE_DIRS ${GSM_INCLUDE_DIR}
    LIBRARIES ${GSM_LIBRARY}
  )
endif()

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(GSM
  REQUIRED_VARS
    GSM_INCLUDE_DIR
    GSM_LIBRARY
    GSM_USABLE
  VERSION_VAR
    GSM_VERSION
)

if(GSM_FOUND)
  set(GSM_LIBRARIES ${GSM_LIBRARY})
  set(GSM_INCLUDE_DIRS ${GSM_INCLUDE_DIR})
  set(GSM_DEFINITIONS ${PC_GSM_CFLAGS_OTHER})

  if(NOT TARGET GSM::GSM)
    add_library(GSM::GSM UNKNOWN IMPORTED)
    set_target_properties(GSM::GSM PROPERTIES
      IMPORTED_LOCATION "${GSM_LIBRARIES}"
      INTERFACE_INCLUDE_DIRECTORIES "${GSM_INCLUDE_DIRS}"
      INTERFACE_COMPILE_OPTIONS "${GSM_DEFINITIONS}"
    )
    include(Pj/DebugLibrary)
    pj_import_debug_library(GSM::GSM GSM_LIBRARY)
  endif()
endif()
