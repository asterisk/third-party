include(Pj/PackageRoot)
find_package(PkgConfig QUIET)
if(PKG_CONFIG_FOUND)
  pj_pkg_search_module(PC_OpenH264 QUIET openh264)
  set(OpenH264_VERSION ${PC_OpenH264_VERSION})
endif()

find_path(OpenH264_INCLUDE_DIR
  NAMES
    "wels/codec_api.h"
    "wels/codec_app_def.h"
    "wels/codec_def.h"
  HINTS
    ${PC_OpenH264_INCLUDEDIR}
    ${PC_OpenH264_INCLUDE_DIRS}
)
mark_as_advanced(OpenH264_INCLUDE_DIR)

find_library(OpenH264_LIBRARY
  NAMES
    openh264
    welsdec
  HINTS
    ${PC_OpenH264_LIBDIR}
    ${PC_OpenH264_LIBRARY_DIRS}
)
mark_as_advanced(OpenH264_LIBRARY)

if(OpenH264_INCLUDE_DIR AND OpenH264_LIBRARY)
  # C++: a static libopenh264 needs the C++ runtime to link
  include(Pj/CheckLibraryUsable)
  pj_check_library_usable(OpenH264
    LANGUAGE CXX
    INCLUDE_DIRS "${OpenH264_INCLUDE_DIR}"
    LIBRARIES "${OpenH264_LIBRARY}"
    STATIC_LIBS m Threads::Threads
    DEFINITIONS ${PC_OpenH264_CFLAGS_OTHER}
    CODE [=[
      #include <wels/codec_api.h>
      int main() { ISVCEncoder *enc; return WelsCreateSVCEncoder(&enc); }
    ]=]
  )
endif()

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(OpenH264
  REQUIRED_VARS
    OpenH264_INCLUDE_DIR
    OpenH264_LIBRARY
    OpenH264_USABLE
  VERSION_VAR
    OpenH264_VERSION
)

if(OpenH264_FOUND)
  set(OpenH264_LIBRARIES ${OpenH264_LIBRARY})
  set(OpenH264_INCLUDE_DIRS ${OpenH264_INCLUDE_DIR})
  set(OpenH264_DEFINITIONS ${PC_OpenH264_CFLAGS_OTHER})

  if(NOT TARGET OpenH264::OpenH264)
    add_library(OpenH264::OpenH264 UNKNOWN IMPORTED)
    set_target_properties(OpenH264::OpenH264 PROPERTIES
      IMPORTED_LOCATION "${OpenH264_LIBRARIES}"
      INTERFACE_INCLUDE_DIRECTORIES "${OpenH264_INCLUDE_DIRS}"
      INTERFACE_COMPILE_OPTIONS "${OpenH264_DEFINITIONS}"
    )
    include(Pj/DebugLibrary)
    pj_import_debug_library(OpenH264::OpenH264 OpenH264_LIBRARY)
  endif()
endif()
