include_guard(GLOBAL)

include(CheckSourceCompiles)
include(CMakePushCheckState)

# pj_check_library_usable(<package> [QUIET]
#   <CODE <source> | FUNCTION <name>>
#   [LANGUAGE <C|CXX>]
#   [INCLUDE_DIRS <dir>...]
#   [LIBRARIES <lib>...]
#   [STATIC_LIBS <lib>...]
#   [DEFINITIONS <flag>...]
# )
#
# Compile and link <source> against a library a Find module has located, to
# reject one that is present but unusable (e.g. built for another target).
# FUNCTION <name> instead links a call to that C function without its header,
# like autoconf's AC_CHECK_LIB.
# STATIC_LIBS are what the library needs when it is a static archive, which
# does not record its dependencies: they are linked too when the first of
# LIBRARIES is one, on a Unix-like target (on Windows a .lib may be an import
# library). "m" is left out on Apple, where libSystem has it, and
# Threads::Threads is looked up as needed.
# Sets the cache variable <package>_USABLE; pass it to
# find_package_handle_standard_args() as a REQUIRED_VARS entry. The check is
# re-run whenever its inputs change, for a target in LIBRARIES also the files
# it stands for. If LANGUAGE (default C) is not enabled in
# the calling project, the check is skipped and the library assumed usable.
# With CMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY (bare-metal toolchains)
# nothing is linked, so only the compile is checked.
# The check prints nothing with QUIET, when <package> was searched QUIET, or
# in pjproject's own configure unless --log-level=VERBOSE (PJ_FIND_QUIET).
function(pj_check_library_usable package)
  cmake_parse_arguments(PARSE_ARGV 1 arg
    "QUIET" "CODE;FUNCTION;LANGUAGE"
    "INCLUDE_DIRS;LIBRARIES;STATIC_LIBS;DEFINITIONS")
  if(arg_FUNCTION AND NOT arg_CODE)
    set(arg_CODE "
#ifdef __cplusplus
extern \"C\"
#endif
char ${arg_FUNCTION}(void);
int main(void) { return ${arg_FUNCTION}(); }
")
  elseif(NOT arg_CODE OR arg_FUNCTION)
    message(FATAL_ERROR
      "pj_check_library_usable: exactly one of CODE or FUNCTION is required")
  endif()
  if(NOT arg_LANGUAGE)
    set(arg_LANGUAGE C)
  endif()

  get_property(_languages GLOBAL PROPERTY ENABLED_LANGUAGES)
  if(NOT arg_LANGUAGE IN_LIST _languages)
    set(${package}_USABLE TRUE PARENT_SCOPE)
    return()
  endif()

  set(_library "")
  if(arg_LIBRARIES)
    list(GET arg_LIBRARIES 0 _library)
  endif()
  if(arg_STATIC_LIBS AND UNIX
     AND _library MATCHES "\\${CMAKE_STATIC_LIBRARY_SUFFIX}$")
    foreach(_lib IN LISTS arg_STATIC_LIBS)
      if(_lib STREQUAL "m" AND APPLE)
        continue()
      endif()
      if(_lib STREQUAL "Threads::Threads")
        find_package(Threads QUIET)
        if(NOT TARGET Threads::Threads)
          continue()
        endif()
      endif()
      list(APPEND arg_LIBRARIES "${_lib}")
    endforeach()
  endif()

  # A target counts with what it stands for, its files, include directories
  # and own links, so that the check runs again when they change, e.g. with
  # a new OPENSSL_ROOT_DIR, which leaves the name OpenSSL::Crypto as it was
  set(_targets "")
  set(_target_inputs "")
  set(_pending ${arg_LIBRARIES})
  # not while(_pending): a list ending in a *-NOTFOUND item reads as false
  while(NOT "${_pending}" STREQUAL "")
    list(POP_FRONT _pending _lib)
    if(NOT TARGET "${_lib}" OR "${_lib}" IN_LIST _targets)
      continue()
    endif()
    list(APPEND _targets "${_lib}")
    get_target_property(_configs ${_lib} IMPORTED_CONFIGURATIONS)
    if(NOT _configs)
      set(_configs "")
    endif()
    set(_props INTERFACE_INCLUDE_DIRECTORIES INTERFACE_LINK_LIBRARIES
      IMPORTED_LOCATION IMPORTED_IMPLIB)
    foreach(_config IN LISTS _configs)
      string(TOUPPER "${_config}" _config)
      list(APPEND _props
        IMPORTED_LOCATION_${_config} IMPORTED_IMPLIB_${_config})
    endforeach()
    foreach(_prop IN LISTS _props)
      get_target_property(_value ${_lib} ${_prop})
      # unset or empty; not if(_value), as for the while() above
      if(NOT _value STREQUAL "_value-NOTFOUND" AND NOT _value STREQUAL "")
        string(APPEND _target_inputs "|${_lib}.${_prop}=${_value}")
        if(_prop STREQUAL "INTERFACE_LINK_LIBRARIES")
          list(APPEND _pending ${_value})
        endif()
      endif()
    endforeach()
  endwhile()

  string(SHA1 _inputs "${arg_LANGUAGE}|${arg_INCLUDE_DIRS}|${arg_LIBRARIES}|${arg_DEFINITIONS}|${arg_CODE}${_target_inputs}")
  if(NOT _inputs STREQUAL "$CACHE{_PJ_${package}_USABLE_INPUTS}")
    unset(${package}_USABLE CACHE)
    set(_PJ_${package}_USABLE_INPUTS "${_inputs}" CACHE INTERNAL "")
  endif()

  # PJ_FIND_QUIET: quiet in pjproject's own configure unless it is verbose
  if(arg_QUIET OR ${package}_FIND_QUIETLY OR PJ_FIND_QUIET)
    set(_quiet TRUE)
  else()
    set(_quiet FALSE)
  endif()
  cmake_push_check_state(RESET)
    set(CMAKE_REQUIRED_INCLUDES ${arg_INCLUDE_DIRS})
    set(CMAKE_REQUIRED_LIBRARIES ${arg_LIBRARIES})
    set(CMAKE_REQUIRED_DEFINITIONS ${arg_DEFINITIONS})
    set(CMAKE_REQUIRED_QUIET ${_quiet})
    check_source_compiles(${arg_LANGUAGE} "${arg_CODE}" ${package}_USABLE)
  cmake_pop_check_state()
endfunction()
