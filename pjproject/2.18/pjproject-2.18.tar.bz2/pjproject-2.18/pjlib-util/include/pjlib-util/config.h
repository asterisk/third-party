/* 
 * Copyright (C) 2008-2026 Teluu Inc. (http://www.teluu.com)
 * Copyright (C) 2003-2008 Benny Prijono <benny@prijono.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
#ifndef __PJLIB_UTIL_CONFIG_H__
#define __PJLIB_UTIL_CONFIG_H__


/**
 * @file config.h
 * @brief Compile time settings
 */

/**
 * @defgroup PJLIB_UTIL_CONFIG Configuration
 * @ingroup PJLIB_UTIL_BASE
 * @{
 */


/* **************************************************************************
 * DNS CONFIGURATION
 */

/**
 * Maximum number of IP addresses in DNS A response.
 */
#ifndef PJ_DNS_MAX_IP_IN_A_REC
#   define PJ_DNS_MAX_IP_IN_A_REC   8
#endif


/**
 * Maximum server address entries per one SRV record
 */
#ifndef PJ_DNS_SRV_MAX_ADDR
#   define PJ_DNS_SRV_MAX_ADDR      8
#endif


/**
 * This constant specifies the maximum names to keep in the temporary name
 * table when performing name compression scheme when duplicating DNS packet
 * (the #pj_dns_packet_dup() function).
 *
 * Generally name compression is desired, since it saves some memory (see
 * PJ_DNS_RESOLVER_RES_BUF_SIZE setting). However it comes at the expense of 
 * a little processing overhead to perform name scanning and also a little
 * bit more stack usage (8 bytes per entry on 32bit platform).
 *
 * Default: 16
 */
#ifndef PJ_DNS_MAX_NAMES_IN_NAMETABLE
#   define PJ_DNS_MAX_NAMES_IN_NAMETABLE            16
#endif


/**
 * Maximum number of entries allowed in each DNS header section (query,
 * answer, authority, additional). This caps allocations during packet
 * parsing to prevent memory exhaustion from malicious responses with
 * inflated section counts. Practical DNS responses rarely exceed this.
 *
 * Default: 256
 */
#ifndef PJ_DNS_MAX_SECTION_COUNT
#   define PJ_DNS_MAX_SECTION_COUNT                 256
#endif


/* **************************************************************************
 * RESOLVER CONFIGURATION
 */


/**
 * Maximum numbers of DNS nameservers that can be configured in resolver,
 * at most 32.
 */
#ifndef PJ_DNS_RESOLVER_MAX_NS
#   define PJ_DNS_RESOLVER_MAX_NS                   16
#endif


/**
 * Default retransmission delay, in miliseconds. The combination of 
 * retransmission delay and count determines the query timeout.
 *
 * Default: 2000 (2 seconds, according to RFC 1035)
 */
#ifndef PJ_DNS_RESOLVER_QUERY_RETRANSMIT_DELAY
#   define PJ_DNS_RESOLVER_QUERY_RETRANSMIT_DELAY   2000
#endif


/**
 * Maximum number of transmissions before timeout is declared for
 * the query.
 *
 * Default: 5
 */
#ifndef PJ_DNS_RESOLVER_QUERY_RETRANSMIT_COUNT
#   define PJ_DNS_RESOLVER_QUERY_RETRANSMIT_COUNT   5
#endif


/**
 * Maximum life-time of DNS response in the resolver response cache, 
 * in seconds. If the value is zero, then DNS response caching will be 
 * disabled.
 *
 * Default is 300 seconds (5 minutes).
 *
 * @see PJ_DNS_RESOLVER_INVALID_TTL
 */
#ifndef PJ_DNS_RESOLVER_MAX_TTL
#   define PJ_DNS_RESOLVER_MAX_TTL                  (5*60)
#endif

/**
 * The life-time of invalid DNS response in the resolver response cache.
 * An invalid DNS response is a response which RCODE is non-zero and 
 * response without any answer section. These responses can be put in 
 * the cache too to minimize message round-trip.
 *
 * Default: 60 (one minute).
 *
 * @see PJ_DNS_RESOLVER_MAX_TTL
 */
#ifndef PJ_DNS_RESOLVER_INVALID_TTL
#   define PJ_DNS_RESOLVER_INVALID_TTL              60
#endif

/**
 * The interval on which nameservers which are known to be good to be 
 * probed again to determine whether they are still good. Note that
 * this applies to both active nameserver (the one currently being used)
 * and idle nameservers (good nameservers that are not currently selected).
 * The probing to query the "goodness" of nameservers involves sending
 * the same query to multiple servers, so it's probably not a good idea
 * to send this probing too often.
 *
 * Default: 600 (ten minutes)
 *
 * @see PJ_DNS_RESOLVER_BAD_NS_TTL
 */
#ifndef PJ_DNS_RESOLVER_GOOD_NS_TTL
#   define PJ_DNS_RESOLVER_GOOD_NS_TTL              (10*60)
#endif

/**
 * The interval on which nameservers which known to be bad to be probed
 * again to determine whether it is still bad.
 *
 * Default: 60 (one minute)
 *
 * @see PJ_DNS_RESOLVER_GOOD_NS_TTL
 */
#ifndef PJ_DNS_RESOLVER_BAD_NS_TTL
#   define PJ_DNS_RESOLVER_BAD_NS_TTL               (1*60)
#endif


/**
 * Default value of the resolver's setting to DISABLE validation that a DNS
 * response originates from one of the configured nameservers (matching address
 * and port). When not disabled (the default), such validation defends against
 * off-path response spoofing; it is standard resolver behavior and compatible
 * with anycast and load-balanced DNS (which preserve the queried address as the
 * source). It can be disabled per resolver via pj_dns_settings for unusual
 * deployments where responses legitimately arrive from a different address. The
 * flag is phrased as "disable" so that a zero-initialized pj_dns_settings keeps
 * the protection enabled.
 *
 * Default: PJ_FALSE (validation enabled)
 */
#ifndef PJ_DNS_RESOLVER_DISABLE_RESPONSE_SRC_CHECK
#   define PJ_DNS_RESOLVER_DISABLE_RESPONSE_SRC_CHECK   PJ_FALSE
#endif


/**
 * Default value of the resolver's setting to resolve with the system
 * resolver while no nameserver answers (pj_dns_settings.sys_fallback).
 *
 * A DNS A or AAAA query is then resolved with pj_getaddrinfo() when no
 * nameserver can be sent to, when it times out while no nameserver is
 * trusted, or when the nameserver refuses it or fails a DNS A query, e.g.
 * on a captive portal. The addresses are reported as its response and
 * cached for #PJ_DNS_RESOLVER_BAD_NS_TTL; an answer of a nameserver
 * replaces them, and #pj_dns_resolver_reset_ns_state() drops them. A
 * query of another type, e.g. DNS SRV, fails as without the setting, but
 * asynchronously, so that #pj_dns_srv_resolve() falls back to the address
 * of the domain as on a negative answer.
 *
 * The setting doesn't change the state of the nameservers: while one is
 * trusted, i.e. answered within #PJ_DNS_RESOLVER_GOOD_NS_TTL, a timeout is
 * reported as without it. They are not trusted right after being set or
 * reset, e.g. by #pj_dns_resolver_reset_ns_state() on a network change, nor
 * while marked as bad. A query which probes them again still waits for its
 * retransmissions, 10 s by default, 14 s with DNS SRV, as without the
 * setting, then gets the answer of the system resolver. With sparse
 * traffic, that is every request after #PJ_DNS_RESOLVER_BAD_NS_TTL of
 * quiet.
 *
 * The lookups run in threads of the resolver, up to
 * #PJ_DNS_RESOLVER_SYS_FALLBACK_THREADS, which #pj_dns_resolver_destroy()
 * waits for. Without threads they run from the timer of the resolver and
 * block its polling meanwhile.
 *
 * Default: PJ_FALSE
 */
#ifndef PJ_DNS_RESOLVER_SYS_FALLBACK
#   define PJ_DNS_RESOLVER_SYS_FALLBACK                 PJ_FALSE
#endif


/**
 * Default value of the resolver's setting for the most lookups with the
 * system resolver at a time (pj_dns_settings.sys_threads), see
 * #PJ_DNS_RESOLVER_SYS_FALLBACK, so that e.g. the A and AAAA records of a
 * domain and its STUN and TURN servers don't wait for each other. One
 * thread per lookup, created when needed, at most 16.
 *
 * Default: 4
 */
#ifndef PJ_DNS_RESOLVER_SYS_FALLBACK_THREADS
#   define PJ_DNS_RESOLVER_SYS_FALLBACK_THREADS         4
#endif


/**
 * Maximum size of UDP packet. RFC 1035 states that maximum size of
 * DNS packet carried over UDP is 512 bytes.
 *
 * Default: 512 byes
 */
#ifndef PJ_DNS_RESOLVER_MAX_UDP_SIZE
#   define PJ_DNS_RESOLVER_MAX_UDP_SIZE             512
#endif


/**
 * Size of memory pool allocated for each individual DNS response cache.
 * This value here should be more or less the same as maximum UDP packet
 * size (PJ_DNS_RESOLVER_MAX_UDP_SIZE), since the DNS replicator function
 * (#pj_dns_packet_dup()) is also capable of performing name compressions.
 *
 * Default: 512
 */
#ifndef PJ_DNS_RESOLVER_RES_BUF_SIZE
#   define PJ_DNS_RESOLVER_RES_BUF_SIZE             512
#endif


/**
 * Size of temporary pool buffer for parsing DNS packets in resolver.
 *
 * default: 4000
 */
#ifndef PJ_DNS_RESOLVER_TMP_BUF_SIZE
#   define PJ_DNS_RESOLVER_TMP_BUF_SIZE             4000
#endif


/**
 * Specifies whether DNS resolver should discard truncated answer.
 *
 * Default: 1 (yes)
 */
#ifndef PJ_DNS_RESOLVER_DISCARD_TRUNCATED_ANSWER
#   define PJ_DNS_RESOLVER_DISCARD_TRUNCATED_ANSWER     1
#endif


/* **************************************************************************
 * SCANNER CONFIGURATION
 */


/**
 * Macro PJ_SCANNER_USE_BITWISE is defined and non-zero (by default yes)
 * will enable the use of bitwise for character input specification (cis).
 * This would save several kilobytes of .bss memory in the SIP parser.
 */
#ifndef PJ_SCANNER_USE_BITWISE
#  define PJ_SCANNER_USE_BITWISE                    1
#endif



/* **************************************************************************
 * STUN CLIENT CONFIGURATION
 */

/**
 * Maximum number of attributes in the STUN packet (for the old STUN
 * library).
 *
 * Default: 16
 */
#ifndef PJSTUN_MAX_ATTR
#   define PJSTUN_MAX_ATTR                          16
#endif


/**
 * Maximum number of attributes in the STUN packet (for the new STUN
 * library).
 *
 * Default: 16
 */
#ifndef PJ_STUN_MAX_ATTR
#   define PJ_STUN_MAX_ATTR                         16
#endif


/* **************************************************************************
 * ENCRYPTION
 */

/**
 * Specifies whether CRC32 algorithm should use the table based lookup table
 * for faster calculation, at the expense of about 1KB table size on the
 * executable. If zero, the CRC32 will use non-table based which is more than
 * an order of magnitude slower.
 *
 * Default: 1
 */
#ifndef PJ_CRC32_HAS_TABLES
#   define PJ_CRC32_HAS_TABLES                      1
#endif


/* **************************************************************************
 * HTTP Client configuration
 */
/**
 * Timeout value for HTTP request operation. The value is in ms.
 * Default: 60000ms
 */
#ifndef PJ_HTTP_DEFAULT_TIMEOUT
#   define PJ_HTTP_DEFAULT_TIMEOUT         (60000)
#endif

/**
 * Maximum size (in bytes) of an HTTP response body that the HTTP client will
 * buffer internally. A response advertising a larger Content-Length is
 * rejected before its body is allocated, and a response without Content-Length
 * is aborted once the received body grows past this limit. This bounds memory
 * usage against a malicious or malfunctioning server. Applications that stream
 * the body themselves via the on_data_read() callback are not subject to this
 * limit. Set to 0 to disable the check (not recommended).
 *
 * Default: 8 MB
 */
#ifndef PJ_HTTP_MAX_CONTENT_LENGTH
#   define PJ_HTTP_MAX_CONTENT_LENGTH      (8 * 1024 * 1024)
#endif

/* **************************************************************************
 * CLI configuration
 */

/**
 * Initial pool size for CLI.
 * Default: 1024 bytes
 */
#ifndef PJ_CLI_POOL_SIZE
#   define PJ_CLI_POOL_SIZE    1024
#endif

/**
 * Pool increment size for CLI.
 * Default: 512 bytes
 */
#ifndef PJ_CLI_POOL_INC
#   define PJ_CLI_POOL_INC     512
#endif

/**
 * Maximum length of command buffer.
 * Default: 512
 */
#ifndef PJ_CLI_MAX_CMDBUF
#   define PJ_CLI_MAX_CMDBUF            512
#endif

/**
 * Maximum command arguments.
 * Default: 8
 */
#ifndef PJ_CLI_MAX_ARGS
#   define PJ_CLI_MAX_ARGS              8
#endif

/**
 * Maximum number of hints.
 * Default: 32
 */
#ifndef PJ_CLI_MAX_HINTS
#   define PJ_CLI_MAX_HINTS             32
#endif

/**
 * Maximum short name version (shortcuts) for a command.
 * Default: 4
 */
#ifndef PJ_CLI_MAX_SHORTCUTS
#   define PJ_CLI_MAX_SHORTCUTS         4
#endif

/**
 * Initial pool size for console CLI.
 * Default: 256 bytes
 */
#ifndef PJ_CLI_CONSOLE_POOL_SIZE
#   define PJ_CLI_CONSOLE_POOL_SIZE    256
#endif

/**
 * Pool increment size for console CLI.
 * Default: 256 bytes
 */
#ifndef PJ_CLI_CONSOLE_POOL_INC
#   define PJ_CLI_CONSOLE_POOL_INC     256
#endif

/**
 * Initial pool size for telnet CLI.
 * Default: 1024 bytes
 */
#ifndef PJ_CLI_TELNET_POOL_SIZE
#   define PJ_CLI_TELNET_POOL_SIZE 1024
#endif

/**
 * Pool increment size for telnet CLI.
 * Default: 512 bytes
 */
#ifndef PJ_CLI_TELNET_POOL_INC
#   define PJ_CLI_TELNET_POOL_INC  512
#endif

/**
 * Maximum number of argument values of choice type.
 * Default: 64
 */
#ifndef PJ_CLI_MAX_CHOICE_VAL
#   define PJ_CLI_MAX_CHOICE_VAL   64
#endif

/**
 * Maximum number of command history.
 * Default: 16
 */
#ifndef PJ_CLI_MAX_CMD_HISTORY
#   define PJ_CLI_MAX_CMD_HISTORY  16
#endif

/**
 * Maximum XML nesting depth accepted by pj_xml_parse(), to bound the parser's
 * recursion and prevent stack exhaustion from deeply nested documents.
 * Parsing fails with a syntax error beyond this depth.
 *
 * Each level costs one parser stack frame, around 112 bytes on 64bit builds
 * and more in debug builds, so the default needs about 30KB of stack. Lower
 * this on platforms with small thread stacks.
 *
 * Default: 256
 */
#ifndef PJ_XML_MAX_NESTING
#   define PJ_XML_MAX_NESTING      256
#endif

/**
 * Maximum JSON nesting depth accepted by pj_json_parse(), to bound the
 * parser's recursion and prevent stack exhaustion from deeply nested arrays
 * or objects. Parsing fails beyond this depth.
 *
 * Default: 256
 */
#ifndef PJ_JSON_MAX_NESTING
#   define PJ_JSON_MAX_NESTING     256
#endif

/**
 * @}
 */

#endif  /* __PJLIB_UTIL_CONFIG_H__ */

