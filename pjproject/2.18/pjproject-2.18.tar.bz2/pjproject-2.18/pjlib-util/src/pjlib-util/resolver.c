/* 
 * Copyright (C) 2008-2026 Teluu Inc. (http://www.teluu.com)
 * Copyright (C) 2003-2008 Benny Prijono <benny@prijono.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
#include <pjlib-util/resolver.h>
#include <pjlib-util/errno.h>
#include <pjlib-util/hmac_sha1.h>
#include <pj/compat/socket.h>
#include <pj/addr_resolv.h>
#include <pj/assert.h>
#include <pj/ctype.h>
#include <pj/except.h>
#include <pj/guid.h>
#include <pj/hash.h>
#include <pj/ioqueue.h>
#include <pj/log.h>
#include <pj/os.h>
#include <pj/pool.h>
#include <pj/pool_buf.h>
#include <pj/rand.h>
#include <pj/string.h>
#include <pj/sock.h>
#include <pj/timer.h>


#define THIS_FILE           "resolver.c"


/* Check that maximum DNS nameservers is not too large. 
 * This has got todo with the datatype to index the nameserver in the query.
 */
#if PJ_DNS_RESOLVER_MAX_NS > 256
#   error "PJ_DNS_RESOLVER_MAX_NS is too large (max=256)"
#endif


#define RES_HASH_TABLE_SIZE 127         /**< Hash table size (must be 2^n-1 */
#define PORT                53          /**< Default NS port.               */
#define Q_HASH_TABLE_SIZE   127         /**< Query hash table size          */
#define TIMER_SIZE          127         /**< Initial number of timers.      */
#define MAX_FD              3           /**< Maximum internal sockets.      */

#define RES_BUF_SZ          PJ_DNS_RESOLVER_RES_BUF_SIZE
#define UDPSZ               PJ_DNS_RESOLVER_MAX_UDP_SIZE
#define TMP_SZ              PJ_DNS_RESOLVER_TMP_BUF_SIZE


/* Nameserver state */
enum ns_state
{
    STATE_PROBING,
    STATE_ACTIVE,
    STATE_BAD,
};

static const char *state_names[3] =
{
    "Probing",
    "Active",
    "Bad"
};


/* 
 * Each nameserver entry.
 * A name server is identified by its socket address (IP and port).
 * Each NS will have a flag to indicate whether it's properly functioning.
 */
struct nameserver
{
    pj_sockaddr     addr;               /**< Server address.                */

    enum ns_state   state;              /**< Nameserver state.              */
    pj_time_val     state_expiry;       /**< Time set next state.           */
    pj_time_val     rt_delay;           /**< Response time.                 */
    

    /* For calculating rt_delay: */
    pj_uint16_t     q_id;               /**< Query ID.                      */
    pj_time_val     sent_time;          /**< Time this query is sent.       */
};


/* Child query list head 
 * See comments on pj_dns_async_query below.
 */
struct query_head
{
    PJ_DECL_LIST_MEMBER(pj_dns_async_query);
};


/* Key to look for outstanding query and/or cached response */
struct res_key
{
    pj_uint16_t              qtype;                 /**< Query type.        */
    char                     name[PJ_MAX_HOSTNAME]; /**< Name being queried */
};


/* Lookup threads at most, and the maximum count of their semaphore:
 * Windows refuses a post above it.
 */
#define SYS_MAX_THREADS     16
#define SYS_SEM_MAX         0x7FFF


/* The system resolver fallback of a query, see start_sys_fallback(). */
struct sys_fallback_state
{
    pj_status_t              dns_status;    /**< Why no nameserver answered */
    pj_bool_t                lookup;        /**< The system resolver applies*/
    pj_bool_t                pending;       /**< The lookup is still to do  */
    pj_status_t              status;        /**< The lookup status.         */
    unsigned                 count;         /**< Addresses found.           */
    union {
        pj_in_addr           v4;            /**< For a DNS A query.         */
        pj_in6_addr          v6;            /**< For a DNS AAAA query.      */
    }                        ip[PJ_DNS_MAX_IP_IN_A_REC]; /**< The addresses */
};


/* 
 * This represents each asynchronous query entry.
 * This entry will be put in two hash tables, the first one keyed on the DNS 
 * transaction ID to match response with the query, and the second one keyed
 * on "res_key" structure above to match a new request against outstanding 
 * requests.
 *
 * An asynchronous entry may have child entries; child entries are subsequent
 * queries to the same resource while there is pending query on the same
 * DNS resource name and type. When a query has child entries, once the
 * response is received (or error occurs), the response will trigger callback
 * invocations for all childs entries.
 *
 * Note: when application cancels the query, the callback member will be
 *       set to NULL, but for simplicity, the query will be let running.
 */
struct pj_dns_async_query
{
    PJ_DECL_LIST_MEMBER(pj_dns_async_query);    /**< List member.           */

    pj_dns_resolver     *resolver;      /**< The resolver instance.         */
    pj_uint16_t          id;            /**< Transaction ID.                */

    unsigned             transmit_cnt;  /**< Number of transmissions.       */

    struct res_key       key;           /**< Key to index this query.       */
    pj_hash_entry_buf    hbufid;        /**< Hash buffer 1                  */
    pj_hash_entry_buf    hbufkey;       /**< Hash buffer 2                  */
    pj_timer_entry       timer_entry;   /**< Timer to manage timeouts       */
    struct sys_fallback_state sys;      /**< System resolver fallback.      */
    unsigned             options;       /**< Query options.                 */
    void                *user_data;     /**< Application data.              */
    pj_dns_callback     *cb;            /**< Callback to be called.         */
    struct query_head    child_head;    /**< Child queries list head.       */
    unsigned             cache_gen;     /**< cache_gen of the resolver when
                                             the query started.             */
};



/* This structure is used to keep cached response entry.
 * The cache is a hash table keyed on "res_key" structure above.
 */
struct cached_res
{
    PJ_DECL_LIST_MEMBER(struct cached_res);

    pj_pool_t               *pool;          /**< Cache's pool.              */
    struct res_key           key;           /**< Resource key.              */
    pj_hash_entry_buf        hbuf;          /**< Hash buffer                */
    pj_time_val              expiry_time;   /**< Expiration time.           */
    pj_dns_parsed_packet    *pkt;           /**< The response packet.       */
    unsigned                 ref_cnt;       /**< Reference counter.         */
    pj_bool_t                from_sys;      /**< Answer of the system
                                                 resolver.                  */
};


/* Resolver entry */
struct pj_dns_resolver
{
    pj_str_t             name;          /**< Resolver instance name for id. */

    /* Internals */
    pj_pool_t           *pool;          /**< Internal pool.                 */
    pj_grp_lock_t       *grp_lock;      /**< Group lock protection.         */
    pj_bool_t            own_timer;     /**< Do we own timer?               */
    pj_timer_heap_t     *timer;         /**< Timer instance.                */
    pj_bool_t            own_ioqueue;   /**< Do we own ioqueue?             */
    pj_ioqueue_t        *ioqueue;       /**< Ioqueue instance.              */

    /* Socket */
    pj_sock_t            udp_sock;      /**< UDP socket.                    */
    pj_ioqueue_key_t    *udp_key;       /**< UDP socket ioqueue key.        */
    unsigned char        udp_rx_pkt[UDPSZ];/**< UDP receive buffer.         */
    char                 udp_tmp_pool[TMP_SZ];/**< Parse pool buffer.       */
    unsigned char        udp_tx_pkt[UDPSZ];/**< UDP transmit buffer.        */
    pj_ioqueue_op_key_t  udp_op_rx_key; /**< UDP read operation key.        */
    pj_ioqueue_op_key_t  udp_op_tx_key; /**< UDP write operation key.       */
    pj_sockaddr          udp_src_addr;  /**< Source address of packet       */
    int                  udp_addr_len;  /**< Source address length.         */

#if PJ_HAS_IPV6
    /* IPv6 socket */
    pj_sock_t            udp6_sock;     /**< UDP socket.                    */
    pj_ioqueue_key_t    *udp6_key;      /**< UDP socket ioqueue key.        */
    unsigned char        udp6_rx_pkt[UDPSZ];/**< UDP receive buffer.        */
    char                 udp6_tmp_pool[TMP_SZ];/**< Parse pool buffer.      */
    //unsigned char      udp6_tx_pkt[UDPSZ];/**< UDP transmit buffer.       */
    pj_ioqueue_op_key_t  udp6_op_rx_key;/**< UDP read operation key.        */
    pj_ioqueue_op_key_t  udp6_op_tx_key;/**< UDP write operation key.       */
    pj_sockaddr          udp6_src_addr; /**< Source address of packet       */
    int                  udp6_addr_len; /**< Source address length.         */
#endif

    /* Settings */
    pj_dns_settings      settings;      /**< Resolver settings.             */

    /* Nameservers */
    unsigned             ns_count;      /**< Number of name servers.        */
    struct nameserver    ns[PJ_DNS_RESOLVER_MAX_NS];    /**< Array of NS.   */

    /* Transaction ID generator: id = truncated HMAC-SHA1 of a counter under a
     * per-resolver secret key, so observed IDs do not reveal the generator
     * state. The key is seeded with entropy at create.
     */
    pj_uint8_t           id_key[20];
    pj_uint32_t          id_counter;

    /* Throttle for logging dropped suspicious (likely forged) responses. */
    pj_time_val          susp_last_log;
    unsigned             susp_count;

    /* Hash table for cached response */
    pj_hash_table_t     *hrescache;     /**< Cached response in hash table  */
    unsigned             cache_gen;     /**< Incremented when the cache is
                                             dropped, see drop_cache().     */

    /* Pending asynchronous query, hashed by transaction ID. */
    pj_hash_table_t     *hquerybyid;

    /* Pending asynchronous query, hashed by "res_key" */
    pj_hash_table_t     *hquerybyres;

    /* Query entries free list */
    struct query_head    query_free_nodes;

    /* System resolver fallback, see start_sys_fallback() */
    struct query_head    sys_jobs;      /**< Queries waiting for a lookup.  */
    struct query_head    done_list;     /**< Queries waiting to be reported.*/
    pj_timer_entry       done_timer;    /**< Reports the done_list.         */
    pj_bool_t            done_scheduled;/**< The done_timer is scheduled.   */
#if PJ_HAS_THREADS
    pj_thread_t         *sys_threads[SYS_MAX_THREADS]; /**< Lookup threads */
    unsigned             sys_thread_cnt;/**< Threads created.               */
    unsigned             sys_busy;      /**< Threads in a lookup.           */
    unsigned             sys_queued;    /**< Queries on sys_jobs.           */
    pj_sem_t            *sys_sem;       /**< Wakes the lookup threads up.   */
    pj_bool_t            sys_quit;      /**< The lookup threads must quit.  */
#endif

    /* Set once pj_dns_resolver_destroy() has started, to reject new queries
     * and cache updates that would otherwise miss the teardown.
     */
    pj_bool_t            shutting_down;
};


/* Callback from ioqueue when packet is received */
static void on_read_complete(pj_ioqueue_key_t *key, 
                             pj_ioqueue_op_key_t *op_key, 
                             pj_ssize_t bytes_read);

/* Callback to be called when query has timed out */
static void on_timeout( pj_timer_heap_t *timer_heap,
                        struct pj_timer_entry *entry);

/* Callback to be called when there are queries of the system resolver
 * fallback to report
 */
static void on_done_timer( pj_timer_heap_t *timer_heap,
                           struct pj_timer_entry *entry);

static void set_nameserver_state(pj_dns_resolver *resolver,
                                 unsigned index,
                                 enum ns_state state,
                                 const pj_time_val *now);

static void sys_collect(pj_dns_resolver *resolver, struct query_head *list);

static void report_sys(pj_dns_resolver *resolver, pj_dns_async_query *q);

static void drop_cache(pj_dns_resolver *resolver, pj_bool_t keep_answers);

static void update_res_cache(pj_dns_resolver *resolver,
                             const struct res_key *key,
                             pj_status_t status,
                             pj_bool_t set_expiry,
                             const pj_dns_parsed_packet *pkt,
                             pj_bool_t from_sys);

/* Select which nameserver to use */
static pj_status_t select_nameservers(pj_dns_resolver *resolver,
                                      unsigned *count,
                                      unsigned servers[]);

/* Destructor */
static void dns_resolver_on_destroy(void *member);

/* Close UDP socket */
static void close_sock(pj_dns_resolver *resv)
{
    /* Close existing socket */
    if (resv->udp_key != NULL) {
        pj_ioqueue_unregister(resv->udp_key);
        resv->udp_key = NULL;
        resv->udp_sock = PJ_INVALID_SOCKET;
    } else if (resv->udp_sock != PJ_INVALID_SOCKET) {
        pj_sock_close(resv->udp_sock);
        resv->udp_sock = PJ_INVALID_SOCKET;
    }

#if PJ_HAS_IPV6
    if (resv->udp6_key != NULL) {
        pj_ioqueue_unregister(resv->udp6_key);
        resv->udp6_key = NULL;
        resv->udp6_sock = PJ_INVALID_SOCKET;
    } else if (resv->udp6_sock != PJ_INVALID_SOCKET) {
        pj_sock_close(resv->udp6_sock);
        resv->udp6_sock = PJ_INVALID_SOCKET;
    }
#endif
}


/* Initialize UDP socket */
static pj_status_t init_sock(pj_dns_resolver *resv)
{
    pj_ioqueue_callback socket_cb;
    pj_sockaddr bound_addr;
    pj_ssize_t rx_pkt_size;
    pj_status_t status;

    /* Create the UDP socket */
    status = pj_sock_socket(pj_AF_INET(), pj_SOCK_DGRAM(), 0, &resv->udp_sock);
    if (status != PJ_SUCCESS)
        return status;

    /* Bind to any address/port */
    status = pj_sock_bind_in(resv->udp_sock, 0, 0);
    if (status != PJ_SUCCESS)
        return status;

    /* Register to ioqueue */
    pj_bzero(&socket_cb, sizeof(socket_cb));
    socket_cb.on_read_complete = &on_read_complete;
    status = pj_ioqueue_register_sock2(resv->pool, resv->ioqueue,
                                       resv->udp_sock, resv->grp_lock,
                                       resv, &socket_cb, &resv->udp_key);
    if (status != PJ_SUCCESS)
        return status;

    pj_ioqueue_op_key_init(&resv->udp_op_rx_key, sizeof(resv->udp_op_rx_key));
    pj_ioqueue_op_key_init(&resv->udp_op_tx_key, sizeof(resv->udp_op_tx_key));

    /* Start asynchronous read to the UDP socket */
    rx_pkt_size = sizeof(resv->udp_rx_pkt);
    resv->udp_addr_len = sizeof(resv->udp_src_addr);
    status = pj_ioqueue_recvfrom(resv->udp_key, &resv->udp_op_rx_key,
                                 resv->udp_rx_pkt, &rx_pkt_size,
                                 PJ_IOQUEUE_ALWAYS_ASYNC,
                                 &resv->udp_src_addr, &resv->udp_addr_len);
    if (status != PJ_EPENDING)
        return status;


#if PJ_HAS_IPV6
    /* Also setup IPv6 socket */

    /* Create the UDP socket */
    status = pj_sock_socket(pj_AF_INET6(), pj_SOCK_DGRAM(), 0,
                            &resv->udp6_sock);
    if (status != PJ_SUCCESS) {
        /* Skip IPv6 socket on system without IPv6 (see ticket #1953) */
        if (status == PJ_STATUS_FROM_OS(OSERR_EAFNOSUPPORT)) {
            PJ_LOG(3,(resv->name.ptr,
                      "System does not support IPv6, resolver will "
                      "ignore any IPv6 nameservers"));
            return PJ_SUCCESS;
        }
        return status;
    }

    /* Bind to any address/port */
    pj_sockaddr_init(pj_AF_INET6(), &bound_addr, NULL, 0);
    status = pj_sock_bind(resv->udp6_sock, &bound_addr,
                          pj_sockaddr_get_len(&bound_addr));
    if (status != PJ_SUCCESS)
        return status;

    /* Register to ioqueue */
    pj_bzero(&socket_cb, sizeof(socket_cb));
    socket_cb.on_read_complete = &on_read_complete;
    status = pj_ioqueue_register_sock2(resv->pool, resv->ioqueue,
                                       resv->udp6_sock, resv->grp_lock,
                                       resv, &socket_cb, &resv->udp6_key);
    if (status != PJ_SUCCESS)
        return status;

    pj_ioqueue_op_key_init(&resv->udp6_op_rx_key,
                           sizeof(resv->udp6_op_rx_key));
    pj_ioqueue_op_key_init(&resv->udp6_op_tx_key,
                           sizeof(resv->udp6_op_tx_key));

    /* Start asynchronous read to the UDP socket */
    rx_pkt_size = sizeof(resv->udp6_rx_pkt);
    resv->udp6_addr_len = sizeof(resv->udp6_src_addr);
    status = pj_ioqueue_recvfrom(resv->udp6_key, &resv->udp6_op_rx_key,
                                 resv->udp6_rx_pkt, &rx_pkt_size,
                                 PJ_IOQUEUE_ALWAYS_ASYNC,
                                 &resv->udp6_src_addr, &resv->udp6_addr_len);
    if (status != PJ_EPENDING)
        return status;
#else
    PJ_UNUSED_ARG(bound_addr);
#endif

    return PJ_SUCCESS;
}


/* Initialize DNS settings with default values */
PJ_DEF(void) pj_dns_settings_default(pj_dns_settings *s)
{
    pj_bzero(s, sizeof(pj_dns_settings));
    s->qretr_delay = PJ_DNS_RESOLVER_QUERY_RETRANSMIT_DELAY;
    s->qretr_count = PJ_DNS_RESOLVER_QUERY_RETRANSMIT_COUNT;
    s->cache_max_ttl = PJ_DNS_RESOLVER_MAX_TTL;
    s->good_ns_ttl = PJ_DNS_RESOLVER_GOOD_NS_TTL;
    s->bad_ns_ttl = PJ_DNS_RESOLVER_BAD_NS_TTL;
    s->disable_response_src_check = PJ_DNS_RESOLVER_DISABLE_RESPONSE_SRC_CHECK;
    s->sys_fallback = PJ_DNS_RESOLVER_SYS_FALLBACK;
    s->sys_threads = PJ_DNS_RESOLVER_SYS_FALLBACK_THREADS;
}


/*
 * Create the resolver.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_create( pj_pool_factory *pf,
                                            const char *name,
                                            unsigned options,
                                            pj_timer_heap_t *timer,
                                            pj_ioqueue_t *ioqueue,
                                            pj_dns_resolver **p_resolver)
{
    pj_pool_t *pool;
    pj_dns_resolver *resv;
    pj_status_t status;

    /* Sanity check */
    PJ_ASSERT_RETURN(pf && p_resolver, PJ_EINVAL);

    if (name == NULL)
        name = THIS_FILE;

    /* Create and initialize resolver instance */
    pool = pj_pool_create(pf, name, 4000, 4000, NULL);
    if (!pool)
        return PJ_ENOMEM;

    /* Create pool and name */
    resv = PJ_POOL_ZALLOC_T(pool, struct pj_dns_resolver);
    resv->pool = pool;
    resv->udp_sock = PJ_INVALID_SOCKET;
    pj_strdup2_with_null(pool, &resv->name, name);
    pj_list_init(&resv->query_free_nodes);
    pj_list_init(&resv->sys_jobs);
    pj_list_init(&resv->done_list);
    pj_timer_entry_init(&resv->done_timer, 0, resv, &on_done_timer);
    
    /* Create group lock */
    status = pj_grp_lock_create_w_handler(pool, NULL, resv,
                                          &dns_resolver_on_destroy,
                                          &resv->grp_lock); 
    if (status != PJ_SUCCESS)
        goto on_error;

    pj_grp_lock_add_ref(resv->grp_lock);

    /* Timer, ioqueue, and settings */
    resv->timer = timer;
    resv->ioqueue = ioqueue;

    /* Seed the transaction ID key with entropy. Fresh GUID(s) provide OS
     * entropy on platforms with a real UUID backend; a high-resolution
     * timestamp and the instance address (ASLR) are mixed in as a fallback.
     */
    {
        char guidbuf[PJ_GUID_MAX_LENGTH];
        pj_str_t guid;
        pj_timestamp ts;
        pj_size_t self = (pj_size_t)resv;
        unsigned i, n, k = 0;

        pj_bzero(resv->id_key, sizeof(resv->id_key));
        pj_get_timestamp(&ts);
        for (i = 0; i < sizeof(ts); ++i)
            resv->id_key[(k++) % sizeof(resv->id_key)] ^= ((pj_uint8_t*)&ts)[i];
        for (i = 0; i < sizeof(self); ++i)
            resv->id_key[(k++) % sizeof(resv->id_key)] ^= ((pj_uint8_t*)&self)[i];
        for (n = 0; n < 2; ++n) {
            guid.ptr = guidbuf;
            guid.slen = 0;
            if (pj_generate_unique_string(&guid) != NULL && guid.slen > 0) {
                for (i = 0; i < (unsigned)guid.slen; ++i)
                    resv->id_key[(k++) % sizeof(resv->id_key)] ^=
                        (pj_uint8_t)guidbuf[i];
            }
        }
        resv->id_counter = ts.u32.lo;
    }

    pj_dns_settings_default(&resv->settings);
    resv->settings.options = options;

    /* Create the timer heap if one is not specified */
    if (resv->timer == NULL) {
        resv->own_timer = PJ_TRUE;
        status = pj_timer_heap_create(pool, TIMER_SIZE, &resv->timer);
        if (status != PJ_SUCCESS)
            goto on_error;
    }

    /* Create the ioqueue if one is not specified */
    if (resv->ioqueue == NULL) {
        resv->own_ioqueue = PJ_TRUE;
        status = pj_ioqueue_create(pool, MAX_FD, &resv->ioqueue);
        if (status != PJ_SUCCESS)
            goto on_error;
    }

    /* Response cache hash table */
    resv->hrescache = pj_hash_create(pool, RES_HASH_TABLE_SIZE);

    /* Query hash table and free list. */
    resv->hquerybyid = pj_hash_create(pool, Q_HASH_TABLE_SIZE);
    resv->hquerybyres = pj_hash_create(pool, Q_HASH_TABLE_SIZE);

    /* Initialize the UDP socket */
    status = init_sock(resv);
    if (status != PJ_SUCCESS)
        goto on_error;

    /* Looks like everything is okay */
    *p_resolver = resv;
    return PJ_SUCCESS;

on_error:
    pj_dns_resolver_destroy(resv, PJ_FALSE);
    return status;
}


void dns_resolver_on_destroy(void *member)
{
    pj_dns_resolver *resolver = (pj_dns_resolver*)member;
    pj_pool_safe_release(&resolver->pool);
}


/*
 * Destroy DNS resolver instance.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_destroy( pj_dns_resolver *resolver,
                                             pj_bool_t notify)
{
    pj_hash_iterator_t it_buf, *it;
    struct query_head cancel_list;
    pj_dns_async_query *q;
    PJ_ASSERT_RETURN(resolver, PJ_EINVAL);

    /*
     * Cancel and dequeue every pending query. This must be done regardless
     * of the notify flag: a query's retransmit timer lives in the (possibly
     * shared) timer heap, so a timer that is still armed -- or one that has
     * already been dispatched and is blocked in on_timeout() on the group
     * lock -- would otherwise fire after the socket is closed below and
     * retransmit on a NULL udp_key. Removing the query from the hash tables
     * makes an already-dispatched on_timeout() exit at its recheck instead.
     * The dequeued queries are moved to a local list and notified after the
     * lock is released, to avoid the lock inversion that on_timeout() also
     * guards against (#1565).
     */
    pj_list_init(&cancel_list);

    pj_grp_lock_acquire(resolver->grp_lock);
    resolver->shutting_down = PJ_TRUE;
    it = pj_hash_first(resolver->hquerybyid, &it_buf);
    while (it) {
        q = (pj_dns_async_query *)pj_hash_this(resolver->hquerybyid, it);

        if (q->timer_entry.id == 1)
            pj_timer_heap_cancel_if_active(resolver->timer,
                                           &q->timer_entry, 0);

        pj_hash_set(NULL, resolver->hquerybyres, &q->key, sizeof(q->key),
                    0, NULL);
        pj_hash_set(NULL, resolver->hquerybyid, &q->id, sizeof(q->id),
                    0, NULL);

        /* A pending parent query is on no list, so its list links are free
         * to move it onto the local cancel list. The queries are not returned
         * to query_free_nodes here; the whole pool is released once the
         * resolver's group lock reference count reaches zero.
         */
        pj_list_push_back(&cancel_list, q);

        it = pj_hash_first(resolver->hquerybyid, &it_buf);
    }

    /* The queries of the system resolver fallback, which are on no timer */
    sys_collect(resolver, &cancel_list);
    if (resolver->done_scheduled) {
        pj_timer_heap_cancel_if_active(resolver->timer, &resolver->done_timer,
                                       0);
        resolver->done_scheduled = PJ_FALSE;
    }
#if PJ_HAS_THREADS
    resolver->sys_quit = PJ_TRUE;
#endif
    pj_grp_lock_release(resolver->grp_lock);

#if PJ_HAS_THREADS
    if (resolver->sys_thread_cnt) {
        unsigned i;

        /* The lookups in progress can't be interrupted: this waits for
         * them, up to the timeout of the system resolver.
         */
        for (i = 0; i < resolver->sys_thread_cnt; ++i)
            pj_sem_post(resolver->sys_sem);
        for (i = 0; i < resolver->sys_thread_cnt; ++i) {
            pj_thread_join(resolver->sys_threads[i]);
            pj_thread_destroy(resolver->sys_threads[i]);
            resolver->sys_threads[i] = NULL;
        }
        resolver->sys_thread_cnt = 0;
        pj_sem_destroy(resolver->sys_sem);
        resolver->sys_sem = NULL;

        /* The queries the threads were looking up */
        pj_grp_lock_acquire(resolver->grp_lock);
        sys_collect(resolver, &cancel_list);
        pj_grp_lock_release(resolver->grp_lock);
    }
#endif

    /* Capture and clear each callback under the lock, but invoke it after
     * releasing, so it neither runs under the lock nor races a concurrent
     * cancel into a duplicate call.
     */
    q = cancel_list.next;
    while (q != (pj_dns_async_query*)&cancel_list) {
        pj_dns_async_query *next_q = q->next;
        pj_dns_async_query *cq;
        pj_dns_callback *cb;

        pj_grp_lock_acquire(resolver->grp_lock);
        cb = q->cb;
        q->cb = NULL;
        pj_grp_lock_release(resolver->grp_lock);

        if (notify && cb)
            (*cb)(q->user_data, PJ_ECANCELLED, NULL);

        cq = q->child_head.next;
        while (cq != (pj_dns_async_query*)&q->child_head) {
            pj_dns_async_query *next_cq = cq->next;
            pj_dns_callback *ccb;

            pj_grp_lock_acquire(resolver->grp_lock);
            ccb = cq->cb;
            cq->cb = NULL;
            pj_grp_lock_release(resolver->grp_lock);

            if (notify && ccb)
                (*ccb)(cq->user_data, PJ_ECANCELLED, NULL);

            cq = next_cq;
        }

        q = next_q;
    }

    /* Destroy cached entries */
    it = pj_hash_first(resolver->hrescache, &it_buf);
    while (it) {
        struct cached_res *cache;

        cache = (struct cached_res*) pj_hash_this(resolver->hrescache, it);
        pj_hash_set(NULL, resolver->hrescache, &cache->key, 
                    sizeof(cache->key), 0, NULL);
        pj_pool_release(cache->pool);

        it = pj_hash_first(resolver->hrescache, &it_buf);
    }

    if (resolver->own_timer && resolver->timer) {
        pj_timer_heap_destroy(resolver->timer);
        resolver->timer = NULL;
    }

    close_sock(resolver);

    if (resolver->own_ioqueue && resolver->ioqueue) {
        pj_ioqueue_destroy(resolver->ioqueue);
        resolver->ioqueue = NULL;
    }

    pj_grp_lock_dec_ref(resolver->grp_lock);

    return PJ_SUCCESS;
}



/*
 * Configure name servers for the DNS resolver. 
 */
PJ_DEF(pj_status_t) pj_dns_resolver_set_ns( pj_dns_resolver *resolver,
                                            unsigned count,
                                            const pj_str_t servers[],
                                            const pj_uint16_t ports[])
{
    unsigned i;
    pj_time_val now;
    pj_status_t status;

    PJ_ASSERT_RETURN(resolver && count && servers, PJ_EINVAL);
    PJ_ASSERT_RETURN(count <= PJ_DNS_RESOLVER_MAX_NS, PJ_ETOOMANY);

    pj_grp_lock_acquire(resolver->grp_lock);

    resolver->ns_count = 0;
    pj_bzero(resolver->ns, sizeof(resolver->ns));

    pj_gettimeofday(&now);

    for (i=0; i<count; ++i) {
        struct nameserver *ns = &resolver->ns[i];

        status = pj_sockaddr_init(pj_AF_INET(), &ns->addr, &servers[i], 
                                  (pj_uint16_t)(ports ? ports[i] : PORT));
        if (status != PJ_SUCCESS)
            status = pj_sockaddr_init(pj_AF_INET6(), &ns->addr, &servers[i], 
                                      (pj_uint16_t)(ports ? ports[i] : PORT));
        if (status != PJ_SUCCESS) {
            pj_grp_lock_release(resolver->grp_lock);
            return PJLIB_UTIL_EDNSINNSADDR;
        }

        ns->state = STATE_ACTIVE;
        ns->state_expiry = now;
        ns->rt_delay.sec = 10;
    }
    
    resolver->ns_count = count;

    pj_grp_lock_release(resolver->grp_lock);
    return PJ_SUCCESS;
}



/*
 * Reset the state of the name servers.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_reset_ns_state(pj_dns_resolver *resolver)
{
    unsigned i;
    pj_time_val now;

    PJ_ASSERT_RETURN(resolver, PJ_EINVAL);

    pj_grp_lock_acquire(resolver->grp_lock);

    /* As pj_dns_resolver_set_ns() does, keeping what the pending queries
     * use: the response time and the query measuring it.
     */
    pj_gettimeofday(&now);
    for (i = 0; i < resolver->ns_count; ++i) {
        resolver->ns[i].state = STATE_ACTIVE;
        resolver->ns[i].state_expiry = now;
    }

    /* What the resolver timed itself may not hold on the new network */
    drop_cache(resolver, PJ_TRUE);
    if (resolver->ns_count)
        PJ_LOG(4,(resolver->name.ptr, "Nameserver state reset"));

    pj_grp_lock_release(resolver->grp_lock);
    return PJ_SUCCESS;
}


/*
 * Modify the resolver settings.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_set_settings(pj_dns_resolver *resolver,
                                                 const pj_dns_settings *st)
{
    PJ_ASSERT_RETURN(resolver && st, PJ_EINVAL);

    pj_grp_lock_acquire(resolver->grp_lock);
    pj_memcpy(&resolver->settings, st, sizeof(*st));
    pj_grp_lock_release(resolver->grp_lock);
    return PJ_SUCCESS;
}


/*
 * Get the resolver current settings.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_get_settings( pj_dns_resolver *resolver,
                                                  pj_dns_settings *st)
{
    PJ_ASSERT_RETURN(resolver && st, PJ_EINVAL);

    pj_grp_lock_acquire(resolver->grp_lock);
    pj_memcpy(st, &resolver->settings, sizeof(*st));
    pj_grp_lock_release(resolver->grp_lock);
    return PJ_SUCCESS;
}


/*
 * Poll for events from the resolver. 
 */
PJ_DEF(void) pj_dns_resolver_handle_events(pj_dns_resolver *resolver,
                                           const pj_time_val *timeout)
{
    PJ_ASSERT_ON_FAIL(resolver, return);

    pj_grp_lock_acquire(resolver->grp_lock);
    pj_timer_heap_poll(resolver->timer, NULL);
    pj_grp_lock_release(resolver->grp_lock);

    pj_ioqueue_poll(resolver->ioqueue, timeout);
}


/* Get one query node from the free node, if any, or allocate 
 * a new one.
 */
static pj_dns_async_query *alloc_qnode(pj_dns_resolver *resolver,
                                       unsigned options,
                                       void *user_data,
                                       pj_dns_callback *cb)
{
    pj_dns_async_query *q;

    /* Merge query options with resolver options */
    options |= resolver->settings.options;

    if (!pj_list_empty(&resolver->query_free_nodes)) {
        q = resolver->query_free_nodes.next;
        pj_list_erase(q);
        pj_bzero(q, sizeof(*q));
    } else {
        q = PJ_POOL_ZALLOC_T(resolver->pool, pj_dns_async_query);
    }

    /* Init query */
    q->resolver = resolver;
    q->options = options;
    q->user_data = user_data;
    q->cb = cb;
    q->cache_gen = resolver->cache_gen;
    pj_list_init(&q->child_head);

    return q;
}


/* Whether the query started after the cache was last dropped */
static pj_bool_t query_is_current(const pj_dns_resolver *resolver,
                                  const pj_dns_async_query *q)
{
    return q->cache_gen == resolver->cache_gen;
}


/* Generate an unpredictable transaction ID that is not currently in use. */
/* Returns a free transaction ID, or 0 if none could be found (ID space
 * exhausted), in which case the caller should fail the query.
 */
static pj_uint16_t get_query_id(pj_dns_resolver *resolver)
{
    unsigned n;

    for (n = 0; n < 1000; ++n) {
        pj_uint8_t digest[20];
        pj_uint32_t ctr = resolver->id_counter++;
        pj_uint16_t id;

        pj_hmac_sha1((const pj_uint8_t*)&ctr, sizeof(ctr),
                     resolver->id_key, sizeof(resolver->id_key), digest);
        id = (pj_uint16_t)((digest[0] << 8) | digest[1]);
        if (id != 0 &&
            pj_hash_get(resolver->hquerybyid, &id, sizeof(id), NULL) == NULL)
        {
            return id;
        }
    }

    return 0;
}


/* Anti-forgery: a response is only accepted if it comes from one of the
 * configured nameservers (matching address and port). Any configured
 * nameserver is accepted (not only the one queried), since a query may be
 * sent to, or retried against, several nameservers.
 */
static pj_bool_t is_response_from_ns(pj_dns_resolver *resolver,
                                     const pj_sockaddr *src_addr)
{
    unsigned i;

    for (i = 0; i < resolver->ns_count; ++i) {
        if (pj_sockaddr_cmp(&resolver->ns[i].addr, src_addr) == 0)
            return PJ_TRUE;
    }

    return PJ_FALSE;
}


/* Throttled logging for dropped suspicious (likely forged) responses, so an
 * attacker flooding forged packets cannot flood the log. Reports at most once
 * per second, with a count of drops since the previous message.
 */
static void log_suspicious_drop(pj_dns_resolver *resolver, const char *reason,
                                const pj_sockaddr *src_addr)
{
    char addr[PJ_INET6_ADDRSTRLEN];
    pj_time_val now, diff;

    ++resolver->susp_count;

    pj_gettimeofday(&now);
    diff = now;
    PJ_TIME_VAL_SUB(diff, resolver->susp_last_log);

    if (resolver->susp_last_log.sec == 0 || diff.sec >= 1) {
        PJ_LOG(4,(resolver->name.ptr,
                  "Discarded %u suspicious DNS response(s); latest from "
                  "%s:%d (%s)",
                  resolver->susp_count,
                  pj_sockaddr_print(src_addr, addr, sizeof(addr), 2),
                  pj_sockaddr_get_port(src_addr), reason));
        resolver->susp_count = 0;
        resolver->susp_last_log = now;
    }
}


/*
 * Transmit query.
 */
static pj_status_t transmit_query(pj_dns_resolver *resolver,
                                  pj_dns_async_query *q)
{
    unsigned pkt_size;
    unsigned i, server_cnt, send_cnt;
    unsigned servers[PJ_DNS_RESOLVER_MAX_NS];
    pj_time_val now;
    pj_str_t name;
    pj_time_val delay;
    pj_status_t status;

    /* Select which nameserver(s) to send requests to. */
    server_cnt = PJ_ARRAY_SIZE(servers);
    status = select_nameservers(resolver, &server_cnt, servers);
    if (status != PJ_SUCCESS) {
        return status;
    }

    if (server_cnt == 0) {
        return PJLIB_UTIL_EDNSNOWORKINGNS;
    }

    /* Start retransmit/timeout timer for the query */
    pj_assert(q->timer_entry.id == 0);
    q->timer_entry.id = 1;
    q->timer_entry.user_data = q;
    q->timer_entry.cb = &on_timeout;

    delay.sec = 0;
    delay.msec = resolver->settings.qretr_delay;
    pj_time_val_normalize(&delay);
    status = pj_timer_heap_schedule_w_grp_lock(resolver->timer,
                                               &q->timer_entry,
                                               &delay, 1,
                                               resolver->grp_lock);
    if (status != PJ_SUCCESS) {
        return status;
    }

    /* Check if the socket is available for sending */
    if (pj_ioqueue_is_pending(resolver->udp_key, &resolver->udp_op_tx_key)
#if PJ_HAS_IPV6
        || (resolver->udp6_key &&
            pj_ioqueue_is_pending(resolver->udp6_key,
                                  &resolver->udp6_op_tx_key))
#endif
        )
    {
        ++q->transmit_cnt;
        PJ_LOG(4,(resolver->name.ptr,
                  "Socket busy in transmitting DNS %s query for %s%s",
                  pj_dns_get_type_name(q->key.qtype),
                  q->key.name,
                  (q->transmit_cnt < resolver->settings.qretr_count?
                   ", will try again later":"")));
        return PJ_SUCCESS;
    }

    /* Create DNS query packet */
    pkt_size = sizeof(resolver->udp_tx_pkt);
    name = pj_str(q->key.name);
    status = pj_dns_make_query(resolver->udp_tx_pkt, &pkt_size,
                               q->id, q->key.qtype, &name);
    if (status != PJ_SUCCESS) {
        pj_timer_heap_cancel(resolver->timer, &q->timer_entry);
        return status;
    }

    /* Get current time. */
    pj_gettimeofday(&now);

    /* Send the packet to name servers */
    send_cnt = 0;
    for (i=0; i<server_cnt; ++i) {
        char addr[PJ_INET6_ADDRSTRLEN];
        pj_ssize_t sent  = (pj_ssize_t) pkt_size;
        struct nameserver *ns = &resolver->ns[servers[i]];

        if (ns->addr.addr.sa_family == pj_AF_INET()) {
            status = pj_ioqueue_sendto(resolver->udp_key,
                                       &resolver->udp_op_tx_key,
                                       resolver->udp_tx_pkt, &sent, 0,
                                       &ns->addr,
                                       pj_sockaddr_get_len(&ns->addr));
            if (status == PJ_SUCCESS || status == PJ_EPENDING)
                send_cnt++;
        }
#if PJ_HAS_IPV6
        else if (resolver->udp6_key) {
            status = pj_ioqueue_sendto(resolver->udp6_key,
                                       &resolver->udp6_op_tx_key,
                                       resolver->udp_tx_pkt, &sent, 0,
                                       &ns->addr,
                                       pj_sockaddr_get_len(&ns->addr));
            if (status == PJ_SUCCESS || status == PJ_EPENDING)
                send_cnt++;
        }
#endif
        else {
            continue;
        }

        PJ_PERROR(4,(resolver->name.ptr, status,
                  "%s %d bytes to NS %d (%s:%d): DNS %s query for %s",
                  (q->transmit_cnt==0? "Transmitting":"Re-transmitting"),
                  (int)pkt_size, servers[i],
                  pj_sockaddr_print(&ns->addr, addr, sizeof(addr), 2),
                  pj_sockaddr_get_port(&ns->addr),
                  pj_dns_get_type_name(q->key.qtype), 
                  q->key.name));

        if (ns->q_id == 0) {
            ns->q_id = q->id;
            ns->sent_time = now;
        }
    }

    if (send_cnt == 0) {
        pj_timer_heap_cancel(resolver->timer, &q->timer_entry);
        return PJLIB_UTIL_EDNSNOWORKINGNS;
    }

    ++q->transmit_cnt;

    return PJ_SUCCESS;
}


/*
 * Initialize resource key for hash table lookup.
 */
static void init_res_key(struct res_key *key, int type, const pj_str_t *name)
{
    unsigned i;
    pj_size_t len;
    char *dst = key->name;
    const char *src = name->ptr;

    pj_bzero(key, sizeof(struct res_key));
    key->qtype = (pj_uint16_t)type;

    len = name->slen;
    if (len >= PJ_MAX_HOSTNAME) len = PJ_MAX_HOSTNAME - 1;

    /* Copy key, in lowercase */
    for (i=0; i<len; ++i) {
        *dst++ = (char)pj_tolower(*src++);
    }
}


/* Allocate new cache entry */
static struct cached_res *alloc_entry(pj_dns_resolver *resolver)
{
    pj_pool_t *pool;
    struct cached_res *cache;

    pool = pj_pool_create(resolver->pool->factory, "dnscache",
                          RES_BUF_SZ, 256, NULL);
    cache = PJ_POOL_ZALLOC_T(pool, struct cached_res);
    cache->pool = pool;
    cache->ref_cnt = 1;

    return cache;
}

/* Re-allocate cache entry, to free cached packet */
static void reset_entry(struct cached_res **p_cached)
{
    pj_pool_t *pool;
    struct cached_res *cache = *p_cached;
    unsigned ref_cnt;

    pool = cache->pool;
    ref_cnt = cache->ref_cnt;

    pj_pool_reset(pool);

    cache = PJ_POOL_ZALLOC_T(pool, struct cached_res);
    cache->pool = pool;
    cache->ref_cnt = ref_cnt;
    *p_cached = cache;
}

/*
 * System resolver fallback, see PJ_DNS_RESOLVER_SYS_FALLBACK.
 *
 * A query which no nameserver answers is given to start_sys_fallback(). A DNS A
 * or AAAA query then waits on sys_jobs for the lookup thread, which looks
 * it up without the lock and gives it back on done_list, and stays in
 * hquerybyres meanwhile, so that the queries started for the name join it,
 * until the cache is dropped.
 * Another query goes to done_list at once, with the error of the
 * nameservers. The done_timer reports the queries of done_list as
 * on_timeout() does, without the lock, and recycles them. Without threads,
 * the lookup runs from the done_timer.
 */

/* Whether the cache says the name doesn't exist: an NXDOMAIN answer for
 * its other address type applies to it as a whole (RFC 8020).
 */
static pj_bool_t name_is_unknown(pj_dns_resolver *resolver,
                                 const pj_dns_async_query *q,
                                 pj_status_t *status)
{
    struct res_key key;
    struct cached_res *cache;
    pj_str_t name = pj_str((char*)q->key.name);
    pj_time_val now;

    init_res_key(&key, (q->key.qtype == PJ_DNS_TYPE_A ? PJ_DNS_TYPE_AAAA :
                                                        PJ_DNS_TYPE_A), &name);
    cache = (struct cached_res *) pj_hash_get(resolver->hrescache, &key,
                                              sizeof(key), NULL);
    if (!cache)
        return PJ_FALSE;
    pj_gettimeofday(&now);
    if (!PJ_TIME_VAL_GT(cache->expiry_time, now) ||
        PJ_DNS_GET_RCODE(cache->pkt->hdr.flags) != PJ_DNS_RCODE_NXDOMAIN)
    {
        return PJ_FALSE;
    }
    *status = PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_RCODE_NXDOMAIN);
    return PJ_TRUE;
}


/* Whether some nameserver is still trusted */
static pj_bool_t has_active_ns(pj_dns_resolver *resolver)
{
    unsigned i;
    pj_time_val now;

    pj_gettimeofday(&now);
    for (i = 0; i < resolver->ns_count; ++i) {
        if (resolver->ns[i].state == STATE_ACTIVE &&
            PJ_TIME_VAL_GT(resolver->ns[i].state_expiry, now))
        {
            return PJ_TRUE;
        }
    }
    return PJ_FALSE;
}


/* Whether the query, or a query which joined it, is still waited for */
static pj_bool_t query_has_cb(const pj_dns_async_query *q)
{
    const pj_dns_async_query *cq;

    if (q->cb)
        return PJ_TRUE;
    cq = q->child_head.next;
    while (cq != (const void*)&q->child_head) {
        if (cq->cb)
            return PJ_TRUE;
        cq = cq->next;
    }
    return PJ_FALSE;
}


/* No query joins it anymore. By identity: after the cache is dropped, a
 * newer query for the name may hold the key.
 */
static void unjoin(pj_dns_resolver *resolver, const pj_dns_async_query *q)
{
    if (pj_hash_get(resolver->hquerybyres, &q->key, sizeof(q->key), NULL) == q)
        pj_hash_set(NULL, resolver->hquerybyres, &q->key, sizeof(q->key), 0,
                    NULL);
}


/* Queue the query for the done_timer to report it. */
static pj_status_t report_later(pj_dns_resolver *resolver,
                                pj_dns_async_query *q)
{
    pj_time_val delay = {0, 0};

    /* Without threads, joined until looked up from the done_timer */
    if (!q->sys.pending)
        unjoin(resolver, q);
    pj_list_push_back(&resolver->done_list, q);

    /* Once destroy has started, it reports the queries itself */
    if (!resolver->done_scheduled && !resolver->shutting_down) {
        pj_status_t status;

        status = pj_timer_heap_schedule_w_grp_lock(resolver->timer,
                                                   &resolver->done_timer,
                                                   &delay, 1,
                                                   resolver->grp_lock);
        if (status != PJ_SUCCESS) {
            /* The caller reports it on its own path: not left waiting */
            PJ_PERROR(4,(resolver->name.ptr, status,
                         "Error scheduling the report of DNS %s query for %s",
                         pj_dns_get_type_name(q->key.qtype), q->key.name));
            pj_list_erase(q);
            unjoin(resolver, q);
            return status;
        }
        resolver->done_scheduled = PJ_TRUE;
    }
    return PJ_SUCCESS;
}


/* Ask the system resolver for the addresses of the query's name. */
static void sys_lookup_run(pj_dns_resolver *resolver, pj_dns_async_query *q)
{
    pj_addrinfo ai[PJ_DNS_MAX_IP_IN_A_REC];
    unsigned i, count = PJ_ARRAY_SIZE(ai);
    int af = (q->key.qtype == PJ_DNS_TYPE_A ? pj_AF_INET() : pj_AF_INET6());
    pj_str_t name = pj_str(q->key.name);
    pj_dns_sys_lookup *lookup;

    pj_grp_lock_acquire(resolver->grp_lock);
    lookup = resolver->settings.sys_lookup;
    pj_grp_lock_release(resolver->grp_lock);
    if (!lookup)
        lookup = &pj_getaddrinfo;

    q->sys.count = 0;
    q->sys.status = (*lookup)(af, &name, &count, ai);
    if (q->sys.status == PJ_SUCCESS) {
        for (i = 0; i < count; ++i) {
            if (ai[i].ai_addr.addr.sa_family != af)
                continue;
            if (af == pj_AF_INET())
                q->sys.ip[q->sys.count].v4 = ai[i].ai_addr.ipv4.sin_addr;
            else
                q->sys.ip[q->sys.count].v6 = ai[i].ai_addr.ipv6.sin6_addr;
            ++q->sys.count;
        }
        if (q->sys.count == 0)
            q->sys.status = PJ_ERESOLVE;
    }
    q->sys.pending = PJ_FALSE;
}


#if PJ_HAS_THREADS
static int sys_thread_proc(void *arg)
{
    pj_dns_resolver *resolver = (pj_dns_resolver*)arg;

    for (;;) {
        pj_sem_wait(resolver->sys_sem);

        pj_grp_lock_acquire(resolver->grp_lock);
        while (!pj_list_empty(&resolver->sys_jobs)) {
            pj_dns_async_query *q = resolver->sys_jobs.next;

            pj_list_erase(q);
            resolver->sys_queued--;

            /* Nobody waits for it, or the option is off: no lookup */
            if (!query_has_cb(q) || !resolver->settings.sys_fallback) {
                q->sys.lookup = PJ_FALSE;
                q->sys.pending = PJ_FALSE;
            } else {
                /* Looked up without the lock: the query is this thread's
                 * until it is given back.
                 */
                resolver->sys_busy++;
                pj_grp_lock_release(resolver->grp_lock);
                sys_lookup_run(resolver, q);
                pj_grp_lock_acquire(resolver->grp_lock);
                resolver->sys_busy--;
            }

            /* Reported from here when the timer can't be scheduled */
            if (report_later(resolver, q) != PJ_SUCCESS) {
                pj_grp_lock_release(resolver->grp_lock);
                report_sys(resolver, q);
                pj_grp_lock_acquire(resolver->grp_lock);
            }
        }
        if (resolver->sys_quit) {
            pj_grp_lock_release(resolver->grp_lock);
            break;
        }
        pj_grp_lock_release(resolver->grp_lock);
    }

    return 0;
}


/* A new lookup thread while all are busy, up to the setting. Fails only
 * when there is none at all.
 */
static pj_status_t sys_thread_start(pj_dns_resolver *resolver)
{
    unsigned limit = resolver->settings.sys_threads;
    pj_status_t status;

    if (limit == 0)
        limit = 1;
    else if (limit > SYS_MAX_THREADS)
        limit = SYS_MAX_THREADS;
    if (resolver->sys_thread_cnt >= limit ||
        resolver->sys_busy + resolver->sys_queued < resolver->sys_thread_cnt)
    {
        return PJ_SUCCESS;
    }

    status = PJ_SUCCESS;
    if (!resolver->sys_sem) {
        status = pj_sem_create(resolver->pool, NULL, 0, SYS_SEM_MAX,
                               &resolver->sys_sem);
    }
    if (status == PJ_SUCCESS) {
        status = pj_thread_create(resolver->pool, "dnssys%p",
                                  &sys_thread_proc, resolver, 0, 0,
                                  &resolver->sys_threads[
                                                resolver->sys_thread_cnt]);
        if (status == PJ_SUCCESS)
            resolver->sys_thread_cnt++;
    }
    if (status != PJ_SUCCESS) {
        if (resolver->sys_thread_cnt) {
            PJ_PERROR(4,(resolver->name.ptr, status,
                         "Error creating another system resolver thread"));
            return PJ_SUCCESS;
        }
        PJ_PERROR(2,(resolver->name.ptr, status,
                     "Error creating the system resolver thread"));
        if (resolver->sys_sem) {
            pj_sem_destroy(resolver->sys_sem);
            resolver->sys_sem = NULL;
        }
    }
    return status;
}
#endif


/* No nameserver answers the query: resolve it with the system resolver
 * when it is for an address, otherwise report the failure. Both later, so
 * that the caller neither gets the callback from within
 * pj_dns_resolver_start_query() nor waits for the lookup. Called with the
 * lock held, with the query on no timer and out of hquerybyid.
 */
static pj_status_t start_sys_fallback(pj_dns_resolver *resolver,
                                      pj_dns_async_query *q,
                                      pj_status_t dns_status)
{
    pj_bzero(&q->sys, sizeof(q->sys));
    q->sys.dns_status = dns_status;
    q->timer_entry.id = 0;

    if ((q->key.qtype == PJ_DNS_TYPE_A || q->key.qtype == PJ_DNS_TYPE_AAAA) &&
        !name_is_unknown(resolver, q, &q->sys.dns_status))
    {
        PJ_LOG(5,(resolver->name.ptr,
                  "No nameserver answers DNS %s query for %s, resolving with "
                  "the system resolver",
                  pj_dns_get_type_name(q->key.qtype), q->key.name));
        q->sys.lookup = PJ_TRUE;
        q->sys.pending = PJ_TRUE;

        /* The queries started for the name join it meanwhile, unless the
         * cache was dropped since it started: a newer query may hold the key
         */
        if (query_is_current(resolver, q)) {
            pj_hash_set_np(resolver->hquerybyres, &q->key, sizeof(q->key), 0,
                           q->hbufkey, q);
        }
#if PJ_HAS_THREADS
        q->sys.status = sys_thread_start(resolver);
        if (q->sys.status == PJ_SUCCESS) {
            pj_list_push_back(&resolver->sys_jobs, q);
            resolver->sys_queued++;
            pj_sem_post(resolver->sys_sem);
            return PJ_SUCCESS;
        }
        /* Reported with the error of the nameservers instead */
        q->sys.pending = PJ_FALSE;
#else
        /* Looked up when reported */
#endif
    } else {
        PJ_LOG(5,(resolver->name.ptr,
                  "No nameserver answers DNS %s query for %s",
                  pj_dns_get_type_name(q->key.qtype), q->key.name));
    }

    return report_later(resolver, q);
}


/* Report the query: the addresses found as its response, or the error of
 * the nameservers. Then recycle it, as on_timeout() does.
 */
static void report_sys(pj_dns_resolver *resolver, pj_dns_async_query *q)
{
    pj_dns_parsed_packet pkt;
    pj_dns_parsed_query question;
    pj_dns_parsed_rr ans[PJ_DNS_MAX_IP_IN_A_REC];
    pj_dns_parsed_packet *resp = NULL;
    pj_dns_async_query *cq;
    pj_dns_callback *cb;
    pj_status_t status = q->sys.dns_status;

    if (q->sys.lookup && q->sys.status == PJ_SUCCESS) {
        unsigned i;

        pj_bzero(&pkt, sizeof(pkt));
        pj_bzero(&question, sizeof(question));
        pj_bzero(ans, sizeof(ans));
        pkt.hdr.flags = PJ_DNS_SET_QR(1);
        pkt.hdr.qdcount = 1;
        pkt.hdr.anscount = (pj_uint16_t)q->sys.count;
        pkt.q = &question;
        pkt.ans = ans;
        question.type = q->key.qtype;
        question.dnsclass = PJ_DNS_CLASS_IN;
        question.name = pj_str(q->key.name);
        for (i = 0; i < q->sys.count; ++i) {
            ans[i].name = question.name;
            ans[i].type = q->key.qtype;
            ans[i].dnsclass = PJ_DNS_CLASS_IN;
            ans[i].ttl = resolver->settings.bad_ns_ttl;
            if (q->key.qtype == PJ_DNS_TYPE_A)
                ans[i].rdata.a.ip_addr = q->sys.ip[i].v4;
            else
                ans[i].rdata.aaaa.ip_addr = q->sys.ip[i].v6;
        }
        resp = &pkt;
        status = PJ_SUCCESS;

        PJ_LOG(5,(resolver->name.ptr,
                  "DNS %s query for %s resolved with the system resolver, "
                  "%u address(es)",
                  pj_dns_get_type_name(q->key.qtype), q->key.name,
                  q->sys.count));
    } else if (q->sys.lookup) {
        char errmsg[PJ_ERR_MSG_SIZE];
        int rcode = 0;

        PJ_PERROR(4,(resolver->name.ptr, q->sys.status,
                     "DNS %s query for %s: no nameserver answers (%s) and the "
                     "system resolver failed",
                     pj_dns_get_type_name(q->key.qtype), q->key.name,
                     pj_strerror(status, errmsg, sizeof(errmsg)).ptr));

        /* Both failed: the nameserver's error is cached, as without the
         * fallback
         */
        if (status == PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_RCODE_REFUSED))
            rcode = PJ_DNS_RCODE_REFUSED;
        else if (status == PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_RCODE_SERVFAIL))
            rcode = PJ_DNS_RCODE_SERVFAIL;
        if (rcode) {
            pj_bzero(&pkt, sizeof(pkt));
            pj_bzero(&question, sizeof(question));
            pkt.hdr.flags = PJ_DNS_SET_QR(1) | PJ_DNS_SET_RCODE(rcode);
            pkt.hdr.qdcount = 1;
            pkt.q = &question;
            question.type = q->key.qtype;
            question.dnsclass = PJ_DNS_CLASS_IN;
            question.name = pj_str(q->key.name);
            pj_grp_lock_acquire(resolver->grp_lock);
            if (!resolver->shutting_down &&
                query_is_current(resolver, q))
            {
                update_res_cache(resolver, &q->key, status, PJ_TRUE, &pkt,
                                 PJ_FALSE);
            }
            pj_grp_lock_release(resolver->grp_lock);
        }
    }

    /* Capture and clear the callback under the lock; invoke it unlocked. */
    pj_grp_lock_acquire(resolver->grp_lock);
    cb = q->cb;
    q->cb = NULL;
    pj_grp_lock_release(resolver->grp_lock);

    if (cb)
        (*cb)(q->user_data, status, resp);

    cq = q->child_head.next;
    while (cq != (void*)&q->child_head) {
        pj_dns_async_query *next = cq->next;
        pj_dns_callback *ccb;

        pj_grp_lock_acquire(resolver->grp_lock);
        ccb = cq->cb;
        cq->cb = NULL;
        pj_grp_lock_release(resolver->grp_lock);

        if (ccb)
            (*ccb)(cq->user_data, status, resp);

        cq = next;
    }

    pj_grp_lock_acquire(resolver->grp_lock);

    /* Cached as a nameserver's answer is, for bad_ns_ttl */
    if (resp && !resolver->shutting_down &&
        query_is_current(resolver, q))
    {
        update_res_cache(resolver, &q->key, PJ_SUCCESS, PJ_TRUE, &pkt,
                         PJ_TRUE);
    }

    q->user_data = NULL;
    cq = q->child_head.next;
    while (cq != (void*)&q->child_head) {
        pj_dns_async_query *next = cq->next;
        pj_list_push_back(&resolver->query_free_nodes, cq);
        cq = next;
    }
    pj_list_push_back(&resolver->query_free_nodes, q);
    pj_grp_lock_release(resolver->grp_lock);
}


static void on_done_timer( pj_timer_heap_t *timer_heap,
                           struct pj_timer_entry *entry)
{
    pj_dns_resolver *resolver = (pj_dns_resolver*)entry->user_data;

    PJ_UNUSED_ARG(timer_heap);

    pj_grp_lock_acquire(resolver->grp_lock);
    resolver->done_scheduled = PJ_FALSE;
    for (;;) {
        pj_dns_async_query *q;

        /* One at a time: once destroy has started, it reports the ones
         * left itself, as cancelled
         */
        if (resolver->shutting_down || pj_list_empty(&resolver->done_list))
            break;
        q = resolver->done_list.next;
        pj_list_erase(q);
        if (q->sys.pending &&
            (!query_has_cb(q) || !resolver->settings.sys_fallback))
        {
            q->sys.lookup = PJ_FALSE;
            q->sys.pending = PJ_FALSE;
            unjoin(resolver, q);
        }
        pj_grp_lock_release(resolver->grp_lock);

        /* Without threads, the lookup runs here */
        if (q->sys.pending) {
            sys_lookup_run(resolver, q);
            pj_grp_lock_acquire(resolver->grp_lock);
            unjoin(resolver, q);
            pj_grp_lock_release(resolver->grp_lock);
        }
        report_sys(resolver, q);

        pj_grp_lock_acquire(resolver->grp_lock);
    }
    pj_grp_lock_release(resolver->grp_lock);
}


/* Move the queries of the system resolver fallback to the list, for
 * pj_dns_resolver_destroy() to report them. Called with the lock held.
 */
static void sys_collect(pj_dns_resolver *resolver, struct query_head *list)
{
    while (!pj_list_empty(&resolver->sys_jobs)) {
        pj_dns_async_query *q = resolver->sys_jobs.next;
        pj_list_erase(q);
        unjoin(resolver, q);
        pj_list_push_back(list, q);
    }
#if PJ_HAS_THREADS
    resolver->sys_queued = 0;
#endif
    while (!pj_list_empty(&resolver->done_list)) {
        pj_dns_async_query *q = resolver->done_list.next;
        pj_list_erase(q);
        unjoin(resolver, q);
        pj_list_push_back(list, q);
    }
}


/* Put unused/expired cached entry to the free list */
static void free_entry(pj_dns_resolver *resolver, struct cached_res *cache)
{
    PJ_UNUSED_ARG(resolver);
    pj_pool_release(cache->pool);
}


/*
 * Create and start asynchronous DNS query for a single resource.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_start_query( pj_dns_resolver *resolver,
                                                 const pj_str_t *name,
                                                 int type,
                                                 unsigned options,
                                                 pj_dns_callback *cb,
                                                 void *user_data,
                                                 pj_dns_async_query **p_query)
{
    pj_time_val now;
    struct res_key key;
    struct cached_res *cache;
    pj_dns_async_query *q, *p_q = NULL;
    pj_uint32_t hval;
    pj_status_t status = PJ_SUCCESS;

    /* Validate arguments */
    PJ_ASSERT_RETURN(resolver && name && type, PJ_EINVAL);

    /* Check name is not too long. */
    PJ_ASSERT_RETURN(name->slen>0 && name->slen < PJ_MAX_HOSTNAME,
                     PJ_ENAMETOOLONG);

    /* Check type */
    PJ_ASSERT_RETURN(type > 0 && type < 0xFFFF, PJ_EINVAL);

    /* Build resource key for looking up hash tables */
    init_res_key(&key, type, name);

    /* Start working with the resolver */
    pj_grp_lock_acquire(resolver->grp_lock);

    /* Reject new queries once destroy has started: a query started after
     * destroy collected the pending queries would arm a timer that survives
     * the teardown.
     */
    if (resolver->shutting_down) {
        if (p_query)
            *p_query = NULL;
        pj_grp_lock_release(resolver->grp_lock);
        return PJ_EGONE;
    }

    /* Get current time. */
    pj_gettimeofday(&now);

    /* First, check if we have cached response for the specified name/type,
     * and the cached entry has not expired.
     */
    hval = 0;
    cache = (struct cached_res *) pj_hash_get(resolver->hrescache, &key, 
                                              sizeof(key), &hval);
    if (cache) {
        /* We've found a cached entry. */

        /* Check for expiration */
        if (PJ_TIME_VAL_GT(cache->expiry_time, now)) {

            /* Log */
            PJ_LOG(5,(resolver->name.ptr, 
                      "Picked up DNS %s record for %.*s from cache, ttl=%d",
                      pj_dns_get_type_name(type),
                      (int)name->slen, name->ptr,
                      (int)(cache->expiry_time.sec - now.sec)));

            /* Map DNS Rcode in the response into PJLIB status name space */
            status = PJ_DNS_GET_RCODE(cache->pkt->hdr.flags);
            status = PJ_STATUS_FROM_DNS_RCODE(status);

            /* Workaround for deadlock problem. Need to increment the cache's
             * ref counter first before releasing mutex, so the cache won't be
             * destroyed by other thread while in callback.
             */
            cache->ref_cnt++;
            pj_grp_lock_release(resolver->grp_lock);

            /* Since we're returning an answer from cache,
             * there is no query object to return.
             */
            if (p_query)
                *p_query = NULL;

            /* This cached response is still valid. Just return this
             * response to caller.
             */
            if (cb) {
                (*cb)(user_data, status, cache->pkt);
            }

            /* Done. No host resolution is necessary */
            pj_grp_lock_acquire(resolver->grp_lock);

            /* Decrement the ref counter. Also check if it is time to free
             * the cache (as it has been expired).
             */
            cache->ref_cnt--;
            if (cache->ref_cnt <= 0)
                free_entry(resolver, cache);

            /* Must return PJ_SUCCESS */
            status = PJ_SUCCESS;

            /*
             * We cannot write to *p_query after calling cb because what
             * p_query points to may have been freed by cb.
             * Refer to ticket #1974.
             */
            pj_grp_lock_release(resolver->grp_lock);
            return status;
        }

        /* At this point, we have a cached entry, but this entry has expired.
         * Remove this entry from the cached list.
         */
        pj_hash_set(NULL, resolver->hrescache, &key, sizeof(key), 0, NULL);

        /* Also free the cache, if it is not being used (by callback). */
        cache->ref_cnt--;
        if (cache->ref_cnt <= 0)
            free_entry(resolver, cache);

        /* Must continue with creating a query now */
    }

    /* Next, check if we have pending query on the same resource */
    q = (pj_dns_async_query *) pj_hash_get(resolver->hquerybyres, &key, 
                                           sizeof(key), NULL);
    if (q) {
        /* Yes, there's another pending query to the same key.
         * Just create a new child query and add this query to
         * pending query's child queries.
         */
        pj_dns_async_query *nq;

        nq = alloc_qnode(resolver, options, user_data, cb);
        pj_list_push_back(&q->child_head, nq);

        /* Done. This child query will be notified once the "parent"
         * query completes.
         */
        p_q = nq;
        status = PJ_SUCCESS;
        goto on_return;
    } 

    /* There's no pending query to the same key, initiate a new one. */
    q = alloc_qnode(resolver, options, user_data, cb);

    /* Save the ID and key */
    q->id = get_query_id(resolver);
    if (q->id == 0) {
        /* No free transaction ID available. */
        pj_list_push_back(&resolver->query_free_nodes, q);
        status = PJ_EBUSY;
        goto on_return;
    }
    pj_memcpy(&q->key, &key, sizeof(struct res_key));

    /* Send the query */
    status = transmit_query(resolver, q);
    if (status != PJ_SUCCESS) {
        if (status == PJLIB_UTIL_EDNSNOWORKINGNS &&
            resolver->settings.sys_fallback && cb &&
            start_sys_fallback(resolver, q, status) == PJ_SUCCESS)
        {
            /* Reported later, or resolved with the system resolver */
            p_q = q;
            status = PJ_SUCCESS;
        } else {
            pj_list_push_back(&resolver->query_free_nodes, q);
        }
        goto on_return;
    }

    /* Add query entry to the hash tables */
    pj_hash_set_np(resolver->hquerybyid, &q->id, sizeof(q->id), 
                   0, q->hbufid, q);
    pj_hash_set_np(resolver->hquerybyres, &q->key, sizeof(q->key),
                   0, q->hbufkey, q);

    p_q = q;

on_return:
    if (p_query)
        *p_query = p_q;

    pj_grp_lock_release(resolver->grp_lock);
    return status;
}


/*
 * Cancel a pending query.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_cancel_query(pj_dns_async_query *query,
                                                 pj_bool_t notify)
{
    pj_grp_lock_t *grp_lock;
    pj_dns_callback *cb;
    void *user_data;

    PJ_ASSERT_RETURN(query, PJ_EINVAL);

    grp_lock = query->resolver->grp_lock;
    pj_grp_lock_acquire(grp_lock);

    /* Capture the callback and its user data under the lock. Unlike the
     * other delivery sites, this one does not remove the query from the
     * hash tables, so it may be completed and recycled once the lock is
     * released. The query goes on, for the queries which joined it or
     * will: were its timer cancelled, it would stay pending for good.
     */
    cb = query->cb;
    user_data = query->user_data;
    query->cb = NULL;

    pj_grp_lock_release(grp_lock);

    /* Invoke the callback unlocked, as the other delivery sites do. */
    if (notify && cb)
        (*cb)(user_data, PJ_ECANCELLED, NULL);

    return PJ_SUCCESS;
}


/* 
 * DNS response containing A packet. 
 */
PJ_DEF(pj_status_t) pj_dns_parse_a_response(const pj_dns_parsed_packet *pkt,
                                            pj_dns_a_record *rec)
{
    enum { MAX_SEARCH = 20 };
    pj_str_t hostname, alias = {NULL, 0}, *resname;
    pj_size_t bufstart = 0;
    pj_size_t bufleft = sizeof(rec->buf_);
    unsigned i, ansidx, search_cnt=0;

    PJ_ASSERT_RETURN(pkt && rec, PJ_EINVAL);

    /* Init the record */
    pj_bzero(rec, sizeof(pj_dns_a_record));

    /* Return error if there's error in the packet. */
    if (PJ_DNS_GET_RCODE(pkt->hdr.flags))
        return PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_GET_RCODE(pkt->hdr.flags));

    /* Return error if there's no query section */
    if (pkt->hdr.qdcount == 0)
        return PJLIB_UTIL_EDNSINANSWER;

    /* Return error if there's no answer */
    if (pkt->hdr.anscount == 0)
        return PJLIB_UTIL_EDNSNOANSWERREC;

    /* Get the hostname from the query. */
    hostname = pkt->q[0].name;

    /* Copy hostname to the record */
    if (hostname.slen > (int)bufleft) {
        return PJ_ENAMETOOLONG;
    }

    pj_memcpy(&rec->buf_[bufstart], hostname.ptr, hostname.slen);
    rec->name.ptr = &rec->buf_[bufstart];
    rec->name.slen = hostname.slen;

    bufstart += hostname.slen;
    bufleft -= hostname.slen;

    /* Find the first RR which name matches the hostname */
    for (ansidx=0; ansidx < pkt->hdr.anscount; ++ansidx) {
        if (pj_stricmp(&pkt->ans[ansidx].name, &hostname)==0)
            break;
    }

    if (ansidx == pkt->hdr.anscount)
        return PJLIB_UTIL_EDNSNOANSWERREC;

    resname = &hostname;

    /* Keep following CNAME records. */
    while (pkt->ans[ansidx].type == PJ_DNS_TYPE_CNAME &&
           search_cnt++ < MAX_SEARCH)
    {
        resname = &pkt->ans[ansidx].rdata.cname.name;

        if (!alias.slen)
            alias = *resname;

        for (i=0; i < pkt->hdr.anscount; ++i) {
            if (pj_stricmp(resname, &pkt->ans[i].name)==0) {
                break;
            }
        }

        if (i==pkt->hdr.anscount)
            return PJLIB_UTIL_EDNSNOANSWERREC;

        ansidx = i;
    }

    if (search_cnt >= MAX_SEARCH)
        return PJLIB_UTIL_EDNSINANSWER;

    if (pkt->ans[ansidx].type != PJ_DNS_TYPE_A)
        return PJLIB_UTIL_EDNSINANSWER;

    /* Copy alias to the record, if present. */
    if (alias.slen) {
        if (alias.slen > (int)bufleft)
            return PJ_ENAMETOOLONG;

        pj_memcpy(&rec->buf_[bufstart], alias.ptr, alias.slen);
        rec->alias.ptr = &rec->buf_[bufstart];
        rec->alias.slen = alias.slen;

        // bufstart += alias.slen;
        // bufleft -= alias.slen;
    }

    /* Get the IP addresses. */
    for (i=0; i < pkt->hdr.anscount; ++i) {
        if (pkt->ans[i].type == PJ_DNS_TYPE_A &&
            pj_stricmp(&pkt->ans[i].name, resname)==0 &&
            rec->addr_count < PJ_DNS_MAX_IP_IN_A_REC)
        {
            rec->addr[rec->addr_count++].s_addr =
                pkt->ans[i].rdata.a.ip_addr.s_addr;
        }
    }

    if (rec->addr_count == 0)
        return PJLIB_UTIL_EDNSNOANSWERREC;

    return PJ_SUCCESS;
}


/* 
 * DNS response containing A and/or AAAA packet. 
 */
PJ_DEF(pj_status_t) pj_dns_parse_addr_response(
                                            const pj_dns_parsed_packet *pkt,
                                            pj_dns_addr_record *rec)
{
    enum { MAX_SEARCH = 20 };
    pj_str_t hostname, alias = {NULL, 0}, *resname;
    pj_size_t bufstart = 0;
    pj_size_t bufleft;
    unsigned i, ansidx, cnt=0;

    PJ_ASSERT_RETURN(pkt && rec, PJ_EINVAL);

    /* Init the record */
    pj_bzero(rec, sizeof(*rec));

    bufleft = sizeof(rec->buf_);

    /* Return error if there's error in the packet. */
    if (PJ_DNS_GET_RCODE(pkt->hdr.flags))
        return PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_GET_RCODE(pkt->hdr.flags));

    /* Return error if there's no query section */
    if (pkt->hdr.qdcount == 0)
        return PJLIB_UTIL_EDNSINANSWER;

    /* Return error if there's no answer */
    if (pkt->hdr.anscount == 0)
        return PJLIB_UTIL_EDNSNOANSWERREC;

    /* Get the hostname from the query. */
    hostname = pkt->q[0].name;

    /* Copy hostname to the record */
    if (hostname.slen > (int)bufleft) {
        return PJ_ENAMETOOLONG;
    }

    pj_memcpy(&rec->buf_[bufstart], hostname.ptr, hostname.slen);
    rec->name.ptr = &rec->buf_[bufstart];
    rec->name.slen = hostname.slen;

    bufstart += hostname.slen;
    bufleft -= hostname.slen;

    /* Find the first RR which name matches the hostname. */
    for (ansidx=0; ansidx < pkt->hdr.anscount; ++ansidx) {
        if (pj_stricmp(&pkt->ans[ansidx].name, &hostname)==0)
            break;
    }

    if (ansidx == pkt->hdr.anscount)
        return PJLIB_UTIL_EDNSNOANSWERREC;

    resname = &hostname;

    /* Keep following CNAME records. */
    while (pkt->ans[ansidx].type == PJ_DNS_TYPE_CNAME &&
           cnt++ < MAX_SEARCH)
    {
        resname = &pkt->ans[ansidx].rdata.cname.name;

        if (!alias.slen)
            alias = *resname;

        for (i=0; i < pkt->hdr.anscount; ++i) {
            if (pj_stricmp(resname, &pkt->ans[i].name)==0)
                break;
        }

        if (i==pkt->hdr.anscount)
            return PJLIB_UTIL_EDNSNOANSWERREC;

        ansidx = i;
    }

    if (cnt >= MAX_SEARCH)
        return PJLIB_UTIL_EDNSINANSWER;

    if (pkt->ans[ansidx].type != PJ_DNS_TYPE_A &&
        pkt->ans[ansidx].type != PJ_DNS_TYPE_AAAA)
    {
        return PJLIB_UTIL_EDNSINANSWER;
    }

    /* Copy alias to the record, if present. */
    if (alias.slen) {
        if (alias.slen > (int)bufleft)
            return PJ_ENAMETOOLONG;

        pj_memcpy(&rec->buf_[bufstart], alias.ptr, alias.slen);
        rec->alias.ptr = &rec->buf_[bufstart];
        rec->alias.slen = alias.slen;

        // bufstart += alias.slen;
        // bufleft -= alias.slen;
    }

    /* Get the IP addresses. */
    cnt = 0;
    for (i=0; i < pkt->hdr.anscount && cnt < PJ_DNS_MAX_IP_IN_A_REC ; ++i) {
        if ((pkt->ans[i].type == PJ_DNS_TYPE_A ||
             pkt->ans[i].type == PJ_DNS_TYPE_AAAA) &&
            pj_stricmp(&pkt->ans[i].name, resname)==0)
        {
            if (pkt->ans[i].type == PJ_DNS_TYPE_A) {
                rec->addr[cnt].af = pj_AF_INET();
                rec->addr[cnt].ip.v4 = pkt->ans[i].rdata.a.ip_addr;
            } else {
                rec->addr[cnt].af = pj_AF_INET6();
                rec->addr[cnt].ip.v6 = pkt->ans[i].rdata.aaaa.ip_addr;
            }
            ++cnt;
        }
    }
    rec->addr_count = cnt;

    if (cnt == 0)
        return PJLIB_UTIL_EDNSNOANSWERREC;

    return PJ_SUCCESS;
}


/* Set nameserver state */
static void set_nameserver_state(pj_dns_resolver *resolver,
                                 unsigned index,
                                 enum ns_state state,
                                 const pj_time_val *now)
{
    struct nameserver *ns = &resolver->ns[index];
    enum ns_state old_state = ns->state;
    char addr[PJ_INET6_ADDRSTRLEN];

    ns->state = state;
    ns->state_expiry = *now;

    if (state == STATE_PROBING)
        ns->state_expiry.sec += ((resolver->settings.qretr_count + 2) *
                                 resolver->settings.qretr_delay) / 1000;
    else if (state == STATE_ACTIVE)
        ns->state_expiry.sec += resolver->settings.good_ns_ttl;
    else
        ns->state_expiry.sec += resolver->settings.bad_ns_ttl;

    PJ_LOG(5, (resolver->name.ptr, "Nameserver %s:%d state changed %s --> %s",
               pj_sockaddr_print(&ns->addr, addr, sizeof(addr), 2),
               pj_sockaddr_get_port(&ns->addr),
               state_names[old_state], state_names[state]));
}


/* Select which nameserver(s) to use. Note this may return multiple
 * name servers. The algorithm to select which nameservers to be
 * sent the request to is as follows:
 *  - select the first nameserver that is known to be good for the
 *    last PJ_DNS_RESOLVER_GOOD_NS_TTL interval.
 *  - for all NSes, if last_known_good >= PJ_DNS_RESOLVER_GOOD_NS_TTL, 
 *    include the NS to re-check again that the server is still good,
 *    unless the NS is known to be bad in the last PJ_DNS_RESOLVER_BAD_NS_TTL
 *    interval.
 *  - for all NSes, if last_known_bad >= PJ_DNS_RESOLVER_BAD_NS_TTL, 
 *    also include the NS to re-check again that the server is still bad.
 */
static pj_status_t select_nameservers(pj_dns_resolver *resolver,
                                      unsigned *count,
                                      unsigned servers[])
{
    unsigned i, max_count=*count;
    int min;
    pj_time_val now;

    pj_assert(max_count > 0);

    *count = 0;
    servers[0] = 0xFFFF;

    /* Check that nameservers are configured. */
    if (resolver->ns_count == 0)
        return PJLIB_UTIL_EDNSNONS;

    pj_gettimeofday(&now);

    /* Select one Active nameserver with best response time. */
    for (min=-1, i=0; i<resolver->ns_count; ++i) {
        struct nameserver *ns = &resolver->ns[i];

        if (ns->state != STATE_ACTIVE)
            continue;

        if (min == -1)
            min = i;
        else if (PJ_TIME_VAL_LT(ns->rt_delay, resolver->ns[min].rt_delay))
            min = i;
    }
    if (min != -1) {
        servers[0] = min;
        ++(*count);
    }

    /* Scan nameservers. */
    for (i=0; i<resolver->ns_count && *count < max_count; ++i) {
        struct nameserver *ns = &resolver->ns[i];

        if (PJ_TIME_VAL_LTE(ns->state_expiry, now)) {
            if (ns->state == STATE_PROBING) {
                set_nameserver_state(resolver, i, STATE_BAD, &now);
            } else {
                set_nameserver_state(resolver, i, STATE_PROBING, &now);
                if ((int)i != min) {
                    servers[*count] = i;
                    ++(*count);
                }
            }
        } else if (ns->state == STATE_PROBING && (int)i != min) {
            servers[*count] = i;
            ++(*count);
        }
    }

    return PJ_SUCCESS;
}


/* Update name server status.
 *
 * 'validated' indicates whether the response has been matched to an outstanding
 * query (transaction ID and question). Only a validated response may change a
 * nameserver's availability decisively: mark it BAD, or bring it back from BAD.
 * An unvalidated (but well-formed, from a configured nameserver) response may
 * only refresh a nameserver that is not currently BAD, keeping liveness
 * tracking working for genuine duplicate/late responses. Otherwise a packet
 * merely spoofed from the nameserver's address could force a healthy nameserver
 * out of rotation, or keep a dead one in rotation (RFC 5452).
 */
static void report_nameserver_status(pj_dns_resolver *resolver,
                                     const pj_sockaddr *ns_addr,
                                     const pj_dns_parsed_packet *pkt,
                                     pj_bool_t validated)
{
    unsigned i;
    int rcode;
    pj_uint32_t q_id;
    pj_time_val now;
    pj_bool_t is_good;

    /* Only mark nameserver as "bad" if it returned non-parseable response or
     * it returned the following status codes
     */
    if (pkt) {
        rcode = PJ_DNS_GET_RCODE(pkt->hdr.flags);
        q_id = pkt->hdr.id;
    } else {
        rcode = 0;
        q_id = (pj_uint32_t)-1;
    }

    /* Some nameserver is reported to respond with PJ_DNS_RCODE_SERVFAIL for
     * missing AAAA record, and the standard doesn't seem to specify that
     * SERVFAIL should prevent the server to be contacted again for other
     * queries. So let's not mark nameserver as bad for SERVFAIL response.
     */
    if (!pkt || /* rcode == PJ_DNS_RCODE_SERVFAIL || */
                rcode == PJ_DNS_RCODE_REFUSED ||
                rcode == PJ_DNS_RCODE_NOTAUTH) 
    {
        is_good = PJ_FALSE;
    } else {
        is_good = PJ_TRUE;
    }


    /* Mark time */
    pj_gettimeofday(&now);

    /* Recheck all nameservers. */
    for (i=0; i<resolver->ns_count; ++i) {
        struct nameserver *ns = &resolver->ns[i];

        if (pj_sockaddr_cmp(&ns->addr, ns_addr) == 0) {
            if (q_id == ns->q_id) {
                /* Calculate response time */
                pj_time_val rt = now;
                PJ_TIME_VAL_SUB(rt, ns->sent_time);
                ns->rt_delay = rt;
                ns->q_id = 0;
            }
            if (is_good && (validated || ns->state != STATE_BAD))
                set_nameserver_state(resolver, i, STATE_ACTIVE, &now);
            else if (!is_good && validated)
                set_nameserver_state(resolver, i, STATE_BAD, &now);
            break;
        }
    }
}


/* Update response cache */
static void update_res_cache(pj_dns_resolver *resolver,
                             const struct res_key *key,
                             pj_status_t status,
                             pj_bool_t set_expiry,
                             const pj_dns_parsed_packet *pkt,
                             pj_bool_t from_sys)
{
    struct cached_res *cache;
    pj_uint32_t hval=0, ttl;

    /* If status is unsuccessful, clear the same entry from the cache */
    if (status != PJ_SUCCESS) {
        cache = (struct cached_res *) pj_hash_get(resolver->hrescache, key, 
                                                  sizeof(*key), &hval);
        /* Remove the entry before releasing its pool (see ticket #1710) */
        pj_hash_set(NULL, resolver->hrescache, key, sizeof(*key), hval, NULL);
        
        /* Free the entry */
        if (cache && --cache->ref_cnt <= 0)
            free_entry(resolver, cache);
    }


    /* Calculate expiration time. */
    if (set_expiry) {
        if (pkt->hdr.anscount == 0 || status != PJ_SUCCESS) {
            /* If we don't have answers for the name, then give a different
             * ttl value (note: PJ_DNS_RESOLVER_INVALID_TTL may be zero, 
             * which means that invalid names won't be kept in the cache)
             */
            ttl = PJ_DNS_RESOLVER_INVALID_TTL;

        } else {
            /* Otherwise get the minimum TTL from the answers */
            unsigned i;
            ttl = 0xFFFFFFFF;
            for (i=0; i<pkt->hdr.anscount; ++i) {
                if (pkt->ans[i].ttl < ttl)
                    ttl = pkt->ans[i].ttl;
            }
        }
    } else {
        ttl = 0xFFFFFFFF;
    }

    /* Apply maximum TTL */
    if (ttl > resolver->settings.cache_max_ttl)
        ttl = resolver->settings.cache_max_ttl;

    /* Get a cache response entry */
    cache = (struct cached_res *) pj_hash_get(resolver->hrescache, key,
                                              sizeof(*key), &hval);

    /* If TTL is zero, clear the same entry in the hash table */
    if (ttl == 0) {
        /* Remove the entry before releasing its pool (see ticket #1710) */
        pj_hash_set(NULL, resolver->hrescache, key, sizeof(*key), hval, NULL);

        /* Free the entry */
        if (cache && --cache->ref_cnt <= 0)
            free_entry(resolver, cache);
        return;
    }

    if (cache == NULL) {
        cache = alloc_entry(resolver);
    } else {
        /* Remove the entry before resetting its pool (see ticket #1710) */
        pj_hash_set(NULL, resolver->hrescache, key, sizeof(*key), hval, NULL);

        if (cache->ref_cnt > 1) {
            /* When cache entry is being used by callback (to app),
             * just decrement ref_cnt so it will be freed after
             * the callback returns and allocate new entry.
             */
            cache->ref_cnt--;
            cache = alloc_entry(resolver);
        } else {
            /* Reset cache to avoid bloated cache pool */
            reset_entry(&cache);
        }
    }

    /* Duplicate the packet.
     * We don't need to keep the NS and AR sections from the packet,
     * so exclude from duplication. We do need to keep the Query
     * section since DNS A parser needs the query section to know
     * the name being requested.
     */
    pj_dns_packet_dup(cache->pool, pkt, 
                      PJ_DNS_NO_NS | PJ_DNS_NO_AR,
                      &cache->pkt);

    /* Calculate expiration time */
    if (set_expiry) {
        pj_gettimeofday(&cache->expiry_time);
        cache->expiry_time.sec += ttl;
    } else {
        cache->expiry_time.sec = 0x7FFFFFFFL;
        cache->expiry_time.msec = 0;
    }

    /* Copy key to the cached response */
    pj_memcpy(&cache->key, key, sizeof(*key));
    cache->from_sys = from_sys;

    /* Update the hash table */
    pj_hash_set_np(resolver->hrescache, &cache->key, sizeof(*key), hval,
                   cache->hbuf, cache);

}


/* Callback to be called when query has timed out */
static void on_timeout( pj_timer_heap_t *timer_heap,
                        struct pj_timer_entry *entry)
{
    pj_dns_resolver *resolver;
    pj_dns_async_query *q, *cq;
    pj_dns_callback *cb;
    pj_status_t status;

    PJ_UNUSED_ARG(timer_heap);

    q = (pj_dns_async_query *) entry->user_data;
    resolver = q->resolver;

    pj_grp_lock_acquire(resolver->grp_lock);

    /* Recheck that this query is still pending, since there is a slight
     * possibility of race condition (timer elapsed while at the same time
     * response arrives)
     */
    if (pj_hash_get(resolver->hquerybyid, &q->id, sizeof(q->id), NULL)==NULL) {
        /* Yeah, this query is done. */
        pj_grp_lock_release(resolver->grp_lock);
        return;
    }

    /* Invalidate id. */
    q->timer_entry.id = 0;

    /* Check to see if we should retransmit instead of time out */
    if (q->transmit_cnt < resolver->settings.qretr_count) {
        status = transmit_query(resolver, q);
        if (status == PJ_SUCCESS) {
            pj_grp_lock_release(resolver->grp_lock);
            return;
        } else {
            /* Error occurs */
            PJ_PERROR(4,(resolver->name.ptr, status,
                         "Error transmitting request"));

            /* Let it fallback to timeout section below */
        }
    }

    /* No trusted nameserver answered: ask the system resolver */
    if (resolver->settings.sys_fallback && !has_active_ns(resolver)) {
        pj_hash_set(NULL, resolver->hquerybyid, &q->id, sizeof(q->id), 0,
                    NULL);
        if (start_sys_fallback(resolver, q, PJ_ETIMEDOUT) == PJ_SUCCESS) {
            pj_grp_lock_release(resolver->grp_lock);
            return;
        }
        /* Reported here instead */
    }

    /* Clear hash table entries */
    pj_hash_set(NULL, resolver->hquerybyid, &q->id, sizeof(q->id), 0, NULL);
    unjoin(resolver, q);

    /* Capture and clear the callback under the lock; invoke it unlocked. */
    cb = q->cb;
    q->cb = NULL;

    /* Workaround for deadlock problem in #1565 (similar to #1108) */
    pj_grp_lock_release(resolver->grp_lock);

    if (cb)
        (*cb)(q->user_data, PJ_ETIMEDOUT, NULL);

    /* Call application callback for child queries. */
    cq = q->child_head.next;
    while (cq != (void*)&q->child_head) {
        pj_dns_async_query *next = cq->next;
        pj_dns_callback *ccb;

        pj_grp_lock_acquire(resolver->grp_lock);
        ccb = cq->cb;
        cq->cb = NULL;
        pj_grp_lock_release(resolver->grp_lock);

        if (ccb)
            (*ccb)(cq->user_data, PJ_ETIMEDOUT, NULL);

        cq = next;
    }

    /* Workaround for deadlock problem in #1565 (similar to #1108) */
    pj_grp_lock_acquire(resolver->grp_lock);

    /* Clear data */
    q->timer_entry.id = 0;
    q->user_data = NULL;

    /* Put child entries into recycle list */
    cq = q->child_head.next;
    while (cq != (void*)&q->child_head) {
        pj_dns_async_query *next = cq->next;
        pj_list_push_back(&resolver->query_free_nodes, cq);
        cq = next;
    }

    /* Put query entry into recycle list */
    pj_list_push_back(&resolver->query_free_nodes, q);

    pj_grp_lock_release(resolver->grp_lock);
}


/* Callback from ioqueue when packet is received */
static void on_read_complete(pj_ioqueue_key_t *key, 
                             pj_ioqueue_op_key_t *op_key, 
                             pj_ssize_t bytes_read)
{
    pj_dns_resolver *resolver;
    pj_pool_t *pool = NULL;
    pj_dns_parsed_packet *dns_pkt;
    pj_dns_async_query *q;
    pj_dns_callback *cb;
    char addr[PJ_INET6_ADDRSTRLEN];
    pj_sockaddr *src_addr;
    int *src_addr_len;
    unsigned char *rx_pkt;
    pj_ssize_t rx_pkt_size;
    char *tmp_pool;
    pj_size_t tmp_pool_size;
    pj_status_t status;
    PJ_USE_EXCEPTION;


    resolver = (pj_dns_resolver *) pj_ioqueue_get_user_data(key);
    pj_assert(resolver);

#if PJ_HAS_IPV6
    if (key == resolver->udp6_key) {
        src_addr = &resolver->udp6_src_addr;
        src_addr_len = &resolver->udp6_addr_len;
        rx_pkt = resolver->udp6_rx_pkt;
        rx_pkt_size = sizeof(resolver->udp6_rx_pkt);
        tmp_pool = resolver->udp6_tmp_pool;
        tmp_pool_size = sizeof(resolver->udp6_tmp_pool);
    } else 
#endif
    {
        src_addr = &resolver->udp_src_addr;
        src_addr_len = &resolver->udp_addr_len;
        rx_pkt = resolver->udp_rx_pkt;
        rx_pkt_size = sizeof(resolver->udp_rx_pkt);
        tmp_pool = resolver->udp_tmp_pool;
        tmp_pool_size = sizeof(resolver->udp_tmp_pool);
    }

    pj_grp_lock_acquire(resolver->grp_lock);


    /* Check for errors */
    if (bytes_read < 0) {
        status = (pj_status_t)-bytes_read;
        PJ_PERROR(4,(resolver->name.ptr, status, "DNS resolver read error"));

        goto read_next_packet;
    }

    PJ_LOG(5,(resolver->name.ptr, 
              "Received %d bytes DNS response from %s:%d",
              (int)bytes_read, 
              pj_sockaddr_print(src_addr, addr, sizeof(addr), 2),
              pj_sockaddr_get_port(src_addr)));


    /* Check for zero packet */
    if (bytes_read == 0)
        goto read_next_packet;

    /* Anti-forgery: only accept responses from a configured nameserver. Done
     * before parsing so packets from other sources are dropped cheaply and
     * cannot affect nameserver status (RFC 5452 section 5.2).
     */
    if (!resolver->settings.disable_response_src_check &&
        !is_response_from_ns(resolver, src_addr))
    {
        log_suspicious_drop(resolver, "unrecognized source", src_addr);
        goto read_next_packet;
    }

    /* Create temporary pool from this socket's own buffer. The packet is
     * used after the lock is released for the callbacks, while the other
     * socket may already be parsing its next packet.
     */
    pool = pj_pool_create_on_buf("restmp", tmp_pool, tmp_pool_size);

    /* Parse DNS response */
    dns_pkt = NULL;
    PJ_TRY {
        status = pj_dns_parse_packet(pool, rx_pkt, 
                                     (unsigned)bytes_read, &dns_pkt);
    }
    PJ_CATCH_ANY {
        status = PJ_ENOMEM;
    }
    PJ_END;

    /* Handle parse error */
    if (status != PJ_SUCCESS) {
        PJ_PERROR(3,(resolver->name.ptr, status,
                     "Error parsing DNS response from %s:%d", 
                     pj_sockaddr_print(src_addr, addr, sizeof(addr), 2),
                     pj_sockaddr_get_port(src_addr)));
        goto read_next_packet;
    }

    /* Anti-forgery: must be a response (QR bit set), not a request. */
    if (PJ_DNS_GET_QR(dns_pkt->hdr.flags) == 0) {
        log_suspicious_drop(resolver, "not a response", src_addr);
        goto read_next_packet;
    }

    /* Update nameserver liveness. The source is validated above and this is at
     * least a well-formed response (QR set), so it may promote the nameserver
     * to ACTIVE. It must not mark it bad, nor resurrect a BAD nameserver, as
     * the response is not yet matched to an outstanding query (see
     * report_nameserver_status()).
     */
    report_nameserver_status(resolver, src_addr, dns_pkt, PJ_FALSE);

    /* Find the query based on the transaction ID */
    q = (pj_dns_async_query*)
        pj_hash_get(resolver->hquerybyid, &dns_pkt->hdr.id,
                    sizeof(dns_pkt->hdr.id), NULL);
    if (!q) {
        PJ_LOG(5,(resolver->name.ptr, 
                  "DNS response from %s:%d id=%d discarded",
                  pj_sockaddr_print(src_addr, addr, sizeof(addr), 2),
                  pj_sockaddr_get_port(src_addr),
                  (unsigned)dns_pkt->hdr.id));
        goto read_next_packet;
    }

    /* Map DNS Rcode in the response into PJLIB status name space */
    status = PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_GET_RCODE(dns_pkt->hdr.flags));

    /* Anti-forgery: the response question must match the outstanding query (the
     * resolver only issues IN-class queries). A response without a question is
     * tolerated only when it carries an error rcode, which some minimal servers
     * return without echoing the question.
     */
    if (dns_pkt->hdr.qdcount >= 1) {
        if (dns_pkt->q[0].dnsclass != PJ_DNS_CLASS_IN ||
            dns_pkt->q[0].type != q->key.qtype ||
            pj_stricmp2(&dns_pkt->q[0].name, q->key.name) != 0)
        {
            log_suspicious_drop(resolver, "mismatched question", src_addr);
            goto read_next_packet;
        }
    } else if (status == PJ_SUCCESS) {
        log_suspicious_drop(resolver, "missing question", src_addr);
        goto read_next_packet;
    }

    /* The response is now validated (matched an outstanding query). Only such a
     * response may mark the nameserver bad or bring it back from bad, so
     * re-report it now that the match is confirmed. Not for a query started
     * before the cache was dropped, e.g. on the previous network.
     */
    report_nameserver_status(resolver, src_addr, dns_pkt,
                             query_is_current(resolver, q));

    /* Cancel query timeout timer. */
    pj_assert(q->timer_entry.id != 0);
    pj_timer_heap_cancel(resolver->timer, &q->timer_entry);
    q->timer_entry.id = 0;

    /* Clear hash table entries */
    pj_hash_set(NULL, resolver->hquerybyid, &q->id, sizeof(q->id), 0, NULL);
    unjoin(resolver, q);

    /* A refusal, or a failed A query, says nothing about the name. A
     * failed AAAA query stands: some nameservers fail a missing AAAA.
     */
    if (resolver->settings.sys_fallback &&
        (q->key.qtype == PJ_DNS_TYPE_A || q->key.qtype == PJ_DNS_TYPE_AAAA) &&
        (status == PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_RCODE_REFUSED) ||
         (status == PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_RCODE_SERVFAIL) &&
          q->key.qtype == PJ_DNS_TYPE_A)) &&
        start_sys_fallback(resolver, q, status) == PJ_SUCCESS)
    {
        goto read_next_packet;
    }

    /* Notify applications first, to allow application to modify the
     * record before it is saved to the hash table. Capture and clear
     * the callback under the lock; invoke it unlocked.
     */
    cb = q->cb;
    q->cb = NULL;

    /* Workaround for deadlock problem in #1108 */
    pj_grp_lock_release(resolver->grp_lock);

    if (cb)
        (*cb)(q->user_data, status, dns_pkt);

    /* If query has subqueries, notify subqueries's application callback */
    if (!pj_list_empty(&q->child_head)) {
        pj_dns_async_query *child_q;

        child_q = q->child_head.next;
        while (child_q != (pj_dns_async_query*)&q->child_head) {
            pj_dns_async_query *next = child_q->next;
            pj_dns_callback *ccb;

            pj_grp_lock_acquire(resolver->grp_lock);
            ccb = child_q->cb;
            child_q->cb = NULL;
            pj_grp_lock_release(resolver->grp_lock);

            if (ccb)
                (*ccb)(child_q->user_data, status, dns_pkt);

            child_q = next;
        }
    }

    /* Workaround for deadlock problem in #1108 */
    pj_grp_lock_acquire(resolver->grp_lock);

    /* Truncated responses MUST NOT be saved (cached). Skip caching as well
     * once destroy has started: destroy sweeps the cache, so a late entry
     * would never be freed. Nor if the cache was dropped since the query
     * started: the response may be of the previous network.
     */
    if (PJ_DNS_GET_TC(dns_pkt->hdr.flags) == 0 && !resolver->shutting_down &&
        query_is_current(resolver, q))
    {
        /* Save/update response cache. */
        update_res_cache(resolver, &q->key, status, PJ_TRUE, dns_pkt,
                         PJ_FALSE);
    }

    /* Recycle query objects, starting with the child queries */
    if (!pj_list_empty(&q->child_head)) {
        pj_dns_async_query *child_q;

        child_q = q->child_head.next;
        while (child_q != (pj_dns_async_query*)&q->child_head) {
            pj_dns_async_query *next = child_q->next;
            pj_list_erase(child_q);
            pj_list_push_back(&resolver->query_free_nodes, child_q);
            child_q = next;
        }
    }
    pj_list_push_back(&resolver->query_free_nodes, q);

read_next_packet:
    if (pool) {
        /* needed just in case PJ_HAS_POOL_ALT_API is set */
        pj_pool_release(pool);
    }

    status = pj_ioqueue_recvfrom(key, op_key, rx_pkt, &rx_pkt_size,
                                 PJ_IOQUEUE_ALWAYS_ASYNC,
                                 src_addr, src_addr_len);

    if (status != PJ_EPENDING && status != PJ_ECANCELLED) {
        PJ_PERROR(4,(resolver->name.ptr, status,
                     "DNS resolver ioqueue read error"));

        pj_assert(!"Unhandled error");
    }

    pj_grp_lock_release(resolver->grp_lock);
}


/*
 * Put the specified DNS packet into DNS cache. This function is mainly used
 * for testing the resolver, however it can also be used to inject entries
 * into the resolver.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_add_entry( pj_dns_resolver *resolver,
                                               const pj_dns_parsed_packet *pkt,
                                               pj_bool_t set_ttl)
{
    struct res_key key;

    /* Sanity check */
    PJ_ASSERT_RETURN(resolver && pkt, PJ_EINVAL);

    /* Packet must be a DNS response */
    PJ_ASSERT_RETURN(PJ_DNS_GET_QR(pkt->hdr.flags) & 1, PJ_EINVAL);

    /* Make sure there are answers in the packet */
    PJ_ASSERT_RETURN((pkt->hdr.anscount && pkt->ans) ||
                      (pkt->hdr.qdcount && pkt->q && !pkt->hdr.anscount),
                     PJLIB_UTIL_EDNSNOANSWERREC);

    pj_grp_lock_acquire(resolver->grp_lock);

    /* Build resource key for looking up hash tables */
    pj_bzero(&key, sizeof(struct res_key));
    if (pkt->hdr.anscount) {
        /* Make sure name is not too long. */
        PJ_ASSERT_ON_FAIL(pkt->ans[0].name.slen < PJ_MAX_HOSTNAME, 
                  { pj_grp_lock_release(resolver->grp_lock); return PJ_ENAMETOOLONG; });

        init_res_key(&key, pkt->ans[0].type, &pkt->ans[0].name);

    } else {
        /* Make sure name is not too long. */
        PJ_ASSERT_ON_FAIL(pkt->q[0].name.slen < PJ_MAX_HOSTNAME, 
                  { pj_grp_lock_release(resolver->grp_lock); return PJ_ENAMETOOLONG; });

        init_res_key(&key, pkt->q[0].type, &pkt->q[0].name);
    }

    /* Insert entry. */
    update_res_cache(resolver, &key, PJ_SUCCESS, set_ttl, pkt, PJ_FALSE);

    pj_grp_lock_release(resolver->grp_lock);

    return PJ_SUCCESS;
}


/*
 * Get the total number of response in the response cache.
 */
PJ_DEF(unsigned) pj_dns_resolver_get_cached_count(pj_dns_resolver *resolver)
{
    unsigned count;

    PJ_ASSERT_RETURN(resolver, 0);

    pj_grp_lock_acquire(resolver->grp_lock);
    count = pj_hash_count(resolver->hrescache);
    pj_grp_lock_release(resolver->grp_lock);

    return count;
}


/* Remove the cached entries, but for those added by the application
 * without TTL and, with keep_answers, the answers with records not from
 * the system resolver. The responses of the pending queries won't be
 * cached nor mark a nameserver bad, and the queries started from now on
 * don't join them. Called with the lock held.
 */
static void drop_cache(pj_dns_resolver *resolver, pj_bool_t keep_answers)
{
    pj_hash_iterator_t it_buf, *it;

    ++resolver->cache_gen;

    it = pj_hash_first(resolver->hquerybyres, &it_buf);
    while (it) {
        pj_dns_async_query *q;

        q = (pj_dns_async_query*) pj_hash_this(resolver->hquerybyres, it);
        it = pj_hash_next(resolver->hquerybyres, it);
        pj_hash_set(NULL, resolver->hquerybyres, &q->key, sizeof(q->key), 0,
                    NULL);
    }

    it = pj_hash_first(resolver->hrescache, &it_buf);
    while (it) {
        struct cached_res *cache;

        cache = (struct cached_res*) pj_hash_this(resolver->hrescache, it);
        it = pj_hash_next(resolver->hrescache, it);

        if (cache->expiry_time.sec == 0x7FFFFFFFL)
            continue;
        if (keep_answers && !cache->from_sys && cache->pkt->hdr.anscount &&
            PJ_DNS_GET_RCODE(cache->pkt->hdr.flags) == 0)
        {
            continue;
        }

        pj_hash_set(NULL, resolver->hrescache, &cache->key,
                    sizeof(cache->key), 0, NULL);

        /* An entry in use by a callback is freed when the callback returns */
        if (--cache->ref_cnt <= 0)
            free_entry(resolver, cache);
    }
}


/*
 * Clear the response cache.
 */
PJ_DEF(pj_status_t) pj_dns_resolver_clear_cache(pj_dns_resolver *resolver)
{
    PJ_ASSERT_RETURN(resolver, PJ_EINVAL);

    pj_grp_lock_acquire(resolver->grp_lock);
    drop_cache(resolver, PJ_FALSE);
    pj_grp_lock_release(resolver->grp_lock);
    return PJ_SUCCESS;
}


/*
 * Dump resolver state to the log.
 */
PJ_DEF(void) pj_dns_resolver_dump(pj_dns_resolver *resolver,
                                  pj_bool_t detail)
{
#if PJ_LOG_MAX_LEVEL >= 3
    unsigned i;
    pj_time_val now;

    pj_grp_lock_acquire(resolver->grp_lock);

    pj_gettimeofday(&now);

    PJ_LOG(3,(resolver->name.ptr, " Dumping resolver state:"));

    PJ_LOG(3,(resolver->name.ptr, "  Name servers:"));
    for (i=0; i<resolver->ns_count; ++i) {
        char addr[PJ_INET6_ADDRSTRLEN];
        struct nameserver *ns = &resolver->ns[i];

        PJ_LOG(3,(resolver->name.ptr,
                  "   NS %d: %s:%d (state=%s until %lds, rtt=%ld ms)",
                  i,
                  pj_sockaddr_print(&ns->addr, addr, sizeof(addr), 2),
                  pj_sockaddr_get_port(&ns->addr),
                  state_names[ns->state],
                  ns->state_expiry.sec - now.sec,
                  PJ_TIME_VAL_MSEC(ns->rt_delay)));
    }

    PJ_LOG(3,(resolver->name.ptr, "  Nb. of cached responses: %u",
              pj_hash_count(resolver->hrescache)));
    if (detail) {
        pj_hash_iterator_t itbuf, *it;
        it = pj_hash_first(resolver->hrescache, &itbuf);
        while (it) {
            struct cached_res *cache;
            cache = (struct cached_res*)pj_hash_this(resolver->hrescache, it);
            PJ_LOG(3,(resolver->name.ptr, 
                      "   Type %s: %s",
                      pj_dns_get_type_name(cache->key.qtype), 
                      cache->key.name));
            it = pj_hash_next(resolver->hrescache, it);
        }
    }
    PJ_LOG(3,(resolver->name.ptr, "  Nb. of pending queries: %u (%u)",
              pj_hash_count(resolver->hquerybyid),
              pj_hash_count(resolver->hquerybyres)));
    if (detail) {
        pj_hash_iterator_t itbuf, *it;
        it = pj_hash_first(resolver->hquerybyid, &itbuf);
        while (it) {
            struct pj_dns_async_query *q;
            q = (pj_dns_async_query*) pj_hash_this(resolver->hquerybyid, it);
            PJ_LOG(3,(resolver->name.ptr, 
                      "   Type %s: %s",
                      pj_dns_get_type_name(q->key.qtype), 
                      q->key.name));
            it = pj_hash_next(resolver->hquerybyid, it);
        }
    }
    PJ_LOG(3,(resolver->name.ptr, "  Nb. of pending query free nodes: %lu",
              (unsigned long)pj_list_size(&resolver->query_free_nodes)));
    PJ_LOG(3,(resolver->name.ptr, "  Nb. of timer entries: %lu",
              (unsigned long)pj_timer_heap_count(resolver->timer)));
    PJ_LOG(3,(resolver->name.ptr, "  Pool capacity: %lu, used size: %lu",
              (unsigned long)pj_pool_get_capacity(resolver->pool),
              (unsigned long)pj_pool_get_used_size(resolver->pool)));

    pj_grp_lock_release(resolver->grp_lock);
#endif
}

