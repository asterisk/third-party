cmake_minimum_required(VERSION 3.28...4.0)

# Prefix each message() with the module it comes from, e.g. "[pjmedia] "
set(CMAKE_MESSAGE_CONTEXT_SHOW TRUE)

# Read version from version.mak
file(STRINGS "${CMAKE_CURRENT_SOURCE_DIR}/version.mak" _version_lines)
set(PJ_VERSION_SUFFIX "")
foreach(_line IN LISTS _version_lines)
  if(_line MATCHES "^export PJ_VERSION_MAJOR[ \t]*:=[ \t]*([0-9]+)")
    set(_pj_ver_major "${CMAKE_MATCH_1}")
  elseif(_line MATCHES "^export PJ_VERSION_MINOR[ \t]*:=[ \t]*([0-9]+)")
    set(_pj_ver_minor "${CMAKE_MATCH_1}")
  elseif(_line MATCHES "^export PJ_VERSION_REV[ \t]*:=[ \t]*([0-9]+)")
    set(_pj_ver_rev "${CMAKE_MATCH_1}")
  elseif(_line MATCHES "^export PJ_VERSION_SUFFIX[ \t]*:=[ \t]*([^ \t]+)")
    # e.g. -dev, for the pkg-config Version, as make
    set(PJ_VERSION_SUFFIX "${CMAKE_MATCH_1}")
  endif()
endforeach()
# CMake VERSION field only accepts numeric components
if(_pj_ver_rev)
  set(_pj_cmake_version "${_pj_ver_major}.${_pj_ver_minor}.${_pj_ver_rev}")
else()
  set(_pj_cmake_version "${_pj_ver_major}.${_pj_ver_minor}")
endif()

# With the NDK toolchain file, default to what ./configure-android builds:
# arm64-v8a, API 23 (the minimum supported, see build/android/README.md) and
# the shared C++ runtime, rather than the NDK's armeabi-v7a, its own minimum
# API level and c++_static. Set before project(), where the toolchain file
# reads them, and only when none of the toolchain's alternatives is given.
if(CMAKE_TOOLCHAIN_FILE MATCHES "(^|/)android\\.toolchain\\.cmake$")
  if(NOT ANDROID_ABI AND NOT ANDROID_TOOLCHAIN_NAME)
    set(ANDROID_ABI arm64-v8a CACHE STRING "Android ABI to build for")
  endif()
  if(NOT ANDROID_PLATFORM AND NOT ANDROID_NATIVE_API_LEVEL)
    set(ANDROID_PLATFORM android-23 CACHE STRING
      "Android API level to build for"
    )
  endif()
  # The NDK's default (legacy) toolchain file ignores CMAKE_ANDROID_STL_TYPE,
  # so pass one given that way on as ANDROID_STL, which both read
  if(NOT DEFINED ANDROID_STL)
    if(DEFINED CMAKE_ANDROID_STL_TYPE)
      set(_pj_stl "${CMAKE_ANDROID_STL_TYPE}")
    else()
      set(_pj_stl c++_shared)
    endif()
    set(ANDROID_STL ${_pj_stl} CACHE STRING "Android C++ runtime")
    unset(_pj_stl)
  endif()
endif()

project(pjproject
  VERSION ${_pj_cmake_version}
  DESCRIPTION "Multimedia communication library"
  HOMEPAGE_URL "http://www.pjsip.org"
  LANGUAGES C
)

# For iOS, default to the deployment target ./configure-iphone builds for
# (15.0, the oldest the current Xcode supports) rather than CMake's, the SDK
# version, which apps targeting any older iOS warn about when linking. Set
# after project(), so that it also covers iOS set by a toolchain file, and
# only on a build folder's first configure, when none was given.
if(IOS AND pjproject_IS_TOP_LEVEL AND NOT CMAKE_OSX_DEPLOYMENT_TARGET AND
   NOT DEFINED _PJ_CONFIGURED_CMAKE_OSX_DEPLOYMENT_TARGET)
  set(CMAKE_OSX_DEPLOYMENT_TARGET 15.0 CACHE STRING
    "Minimum iOS version to build for" FORCE
  )
endif()

# By default each optional library prints one line, "Checking if <X> is
# available - yes/no". --log-level=VERBOSE (or CMAKE_MESSAGE_LOG_LEVEL) adds
# what each search found and its link test.
cmake_language(GET_MESSAGE_LOG_LEVEL _pj_log_level)
if(_pj_log_level MATCHES "^(VERBOSE|DEBUG|TRACE)$")
  set(PJ_FIND_QUIET "")
else()
  set(PJ_FIND_QUIET QUIET)
endif()
unset(_pj_log_level)

# Set by toolchains whose programs cannot be linked without the application's
# startup code, e.g. cmake/toolchains/arm-none-eabi.cmake
if(CMAKE_TRY_COMPILE_TARGET_TYPE STREQUAL "STATIC_LIBRARY")
  message(STATUS "[!] CMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY: the "
    "library link tests only compile, so a library found may still fail to "
    "link")
endif()

# The libraries mark nothing for export, which GNU ld's automatic export
# covers for MinGW but MSVC has no equivalent of: its DLLs would export
# nothing and get no import library. No pjproject build makes MSVC DLLs of
# them; the SWIG bindings link them statically into one DLL instead. Inside
# another project, whose own libraries may well be shared, build pjproject's
# static rather than stop.
if(MSVC AND BUILD_SHARED_LIBS)
  if(NOT pjproject_IS_TOP_LEVEL)
    set(BUILD_SHARED_LIBS OFF)
    message(STATUS
      "[!] MSVC: pjproject's libraries are built static; they export no "
      "symbols for a DLL")
  else()
    message(FATAL_ERROR
      "BUILD_SHARED_LIBS=ON is not supported with MSVC: the pjproject "
      "libraries export no symbols. Build them static (the default), or use "
      "the SWIG bindings (PJ_BUILD_SWIG_CSHARP, PJ_BUILD_SWIG_JAVA, "
      "PJ_BUILD_SWIG_PYTHON) for a single DLL.")
  endif()
endif()

# Configure-check results and found library paths are cached per build folder
# and never redone, so they go stale when the target changes without a new
# compiler (an NDK API level selects other headers and libraries, e.g.
# getifaddrs() exists from API 24). CMake starts afresh on its own only when
# the compiler changes; do the same for these by asking for it.
set(_pj_target_vars
  CMAKE_SYSROOT CMAKE_OSX_SYSROOT CMAKE_OSX_DEPLOYMENT_TARGET
  CMAKE_OSX_ARCHITECTURES
)
if(ANDROID)
  list(APPEND _pj_target_vars ANDROID_ABI ANDROID_PLATFORM)
endif()
foreach(_var IN LISTS _pj_target_vars)
  set(_value "${${_var}}")
  if(_var STREQUAL "ANDROID_PLATFORM")
    # the level the toolchain file settled on (the legacy one sets
    # CMAKE_SYSTEM_VERSION to 1)
    if(DEFINED ANDROID_PLATFORM_LEVEL)
      set(_value "android-${ANDROID_PLATFORM_LEVEL}")
    else()
      set(_value "android-${CMAKE_SYSTEM_VERSION}")
    endif()
  endif()
  if(NOT DEFINED _PJ_CONFIGURED_${_var})
    set(_PJ_CONFIGURED_${_var} "${_value}" CACHE INTERNAL "")
  elseif(NOT _PJ_CONFIGURED_${_var} STREQUAL _value)
    message(FATAL_ERROR
      "${_var} changed from \"${_PJ_CONFIGURED_${_var}}\" to \"${_value}\" "
      "in a build folder configured for the former; its cached configure "
      "checks and library paths would be wrong. Reconfigure with "
      "'cmake --fresh' or use a new build folder.")
  endif()
endforeach()
unset(_pj_target_vars)
unset(_var)
unset(_value)

# A package installed with only Debug and Release builds (vcpkg's SDL2 found
# through CMAKE_PREFIX_PATH) would give MinSizeRel and RelWithDebInfo its
# Debug library and C runtime. Use the configuration itself when the package
# has it, else Release. Visual Studio generates every configuration, so each
# list ends with what CMake would pick without one: the other optimized build,
# the configuration-less one, Debug. Set before any package is searched; a
# value given is kept.
if(MSVC)
  foreach(_cfg MinSizeRel RelWithDebInfo)
    string(TOUPPER ${_cfg} _upper)
    if(_cfg STREQUAL "MinSizeRel")
      set(_other RelWithDebInfo)
    else()
      set(_other MinSizeRel)
    endif()
    if(NOT DEFINED CMAKE_MAP_IMPORTED_CONFIG_${_upper})
      set(CMAKE_MAP_IMPORTED_CONFIG_${_upper} ${_cfg} Release ${_other} "" Debug)
    endif()
  endforeach()
  unset(_cfg)
  unset(_upper)
  unset(_other)
endif()

# C++ is needed only by pjsua2 and a few backends (WebRTC AEC3, libyuv, Lyra,
# OpenH264, Oboe, WASAPI, DirectShow, Android MediaCodec), by pjlib's
# atomic_queue.cpp, which only those backends use, and by WebRTC's CPU
# detection on x86. Off, the build is pure C, which is what an embedded
# toolchain without a C++ runtime needs.
option(PJ_WITH_CXX "Build the C++ components (pjsua2 and C++ backends)" ON)
if(PJ_WITH_CXX)
  enable_language(CXX)
endif()

# pjsua2 alone, keeping the C++ backends: autoconf's --disable-pjsua2
include(CMakeDependentOption)
cmake_dependent_option(PJ_BUILD_PJSUA2 "Build the pjsua2 C++ library" ON
  "PJ_WITH_CXX" OFF
)

# As autoconf: -Wall everywhere, and -O2 when neither a build type nor an -O
# flag is given. Not a CMake build type, as those define NDEBUG, which would
# turn off pj_assert() and PJ_DEBUG. MSVC is left alone (clang-cl reads -Wall
# as -Weverything).
get_property(_pj_multi_config GLOBAL PROPERTY GENERATOR_IS_MULTI_CONFIG)
foreach(_lang C CXX)
  if(NOT CMAKE_${_lang}_COMPILER_LOADED OR MSVC
     OR NOT CMAKE_${_lang}_COMPILER_ID MATCHES "GNU|Clang")
    continue()
  endif()
  add_compile_options($<$<COMPILE_LANGUAGE:${_lang}>:-Wall>)
  if(NOT _pj_multi_config AND NOT CMAKE_BUILD_TYPE
     AND NOT CMAKE_${_lang}_FLAGS MATCHES "(^| )-O")
    add_compile_options($<$<COMPILE_LANGUAGE:${_lang}>:-O2>)
  endif()
endforeach()
unset(_pj_multi_config)

# project modules
list(INSERT CMAKE_MODULE_PATH 0 "${CMAKE_CURRENT_SOURCE_DIR}/cmake")

# PJ_SKIP_EXPERIMENTAL_NOTICE silenced a notice that is gone. Read it, so that
# builds still passing it get no "not used by the project" warning.
set(_pj_unused "${PJ_SKIP_EXPERIMENTAL_NOTICE}")
unset(_pj_unused)

# ##############################################################################
# Testing support

if(CMAKE_PROJECT_NAME STREQUAL PROJECT_NAME)
  # make builds no executable on Android, the test programs included. Off on
  # iOS too, where a command line program cannot run on a device.
  if(ANDROID OR IOS)
    option(BUILD_TESTING "Build the testing tree." OFF)
  endif()
  include(CTest)
endif()

if(BUILD_TESTING)
  if(CMAKE_SYSTEM_NAME MATCHES "rtems")
    set(PJ_TEST_MAIN "main_rtems.c")
  else()
    set(PJ_TEST_MAIN "main.c")
  endif()
endif()

# ##############################################################################
# Installation preparation

include(GNUInstallDirs)

# add `$ORIGIN` to targets' RPATH
if(BUILD_SHARED_LIBS)
  if(APPLE)
    list(APPEND CMAKE_INSTALL_RPATH
      "@loader_path"
      "@executable_path/../${CMAKE_INSTALL_LIBDIR}"
    )
  elseif(UNIX)
    list(APPEND CMAKE_INSTALL_RPATH
      "$ORIGIN"
      "$ORIGIN/../${CMAKE_INSTALL_LIBDIR}"
    )
  endif()
endif()

# ##############################################################################
# Sub-directories

# For pj_pc_remember_imported_targets(), which the sub-directories that find
# dependencies call for the pkg-config file
include(Pj/PkgConfig)

# The sample applications are command line executables: pjsip-apps, and the
# TURN client and server in pjnath. Off by default on Android, as make excludes
# them there, and on iOS, where they cannot run on a device; an iOS consumer
# links the libraries into an app of their own.
# Nor does firmware for a target CMake calls Generic, with no OS or with an
# RTOS such as Zephyr, so the applications can be left out there. Off also
# when pjproject is built inside another project (add_subdirectory(),
# FetchContent), which wants the libraries, as the tests are.
if(ANDROID OR IOS OR NOT CMAKE_PROJECT_NAME STREQUAL PROJECT_NAME)
  set(_pj_build_apps_default OFF)
else()
  set(_pj_build_apps_default ON)
endif()
option(PJ_BUILD_APPS "Build pjsua and the sample applications"
  ${_pj_build_apps_default})
unset(_pj_build_apps_default)

# The pjsua2 SWIG bindings, see pjsip-apps/src/swig. Off by default, as they
# need SWIG (and a JDK or the Python headers); Gradle turns Java on. Defined
# here, before the libraries, because the bindings link them into a shared
# library, so they must be built position independent.
cmake_dependent_option(PJ_BUILD_SWIG_JAVA
  "Build the pjsua2 Java bindings with SWIG" OFF
  "PJ_BUILD_PJSUA2;NOT IOS" OFF
)
cmake_dependent_option(PJ_BUILD_SWIG_PYTHON
  "Build the pjsua2 Python module with SWIG" OFF
  "PJ_BUILD_PJSUA2;NOT ANDROID;NOT IOS" OFF
)
cmake_dependent_option(PJ_BUILD_SWIG_CSHARP
  "Build the pjsua2 C# bindings with SWIG" OFF
  "PJ_BUILD_PJSUA2" OFF
)
# The bindings' native library has to hold the pjproject libraries: iOS apps
# link it statically (DllImport("__Internal")), and Android, which does not
# version library names, would name pjproject's shared pjsua2 library
# libpjsua2.so, as the bindings' own (C# and Java)
if((IOS OR ANDROID) AND (PJ_BUILD_SWIG_CSHARP OR PJ_BUILD_SWIG_JAVA)
   AND BUILD_SHARED_LIBS)
  message(FATAL_ERROR
    "The pjsua2 bindings on ${CMAKE_SYSTEM_NAME} need static libraries: "
    "the bindings' native library (libpjsua2.a on iOS, libpjsua2.so on "
    "Android) has to hold the pjproject libraries. Set BUILD_SHARED_LIBS=OFF, "
    "or turn off the bindings (PJ_BUILD_SWIG_CSHARP, PJ_BUILD_SWIG_JAVA).")
endif()
if(PJ_BUILD_SWIG_JAVA OR PJ_BUILD_SWIG_PYTHON OR PJ_BUILD_SWIG_CSHARP)
  set(CMAKE_POSITION_INDEPENDENT_CODE ON)
endif()

# On iOS, build the executables (applications and tests, when turned on) as
# plain command line programs, as make does, runnable in the Simulator with
# `xcrun simctl spawn`. CMake would otherwise make each an app bundle, which
# needs an install destination.
if(IOS)
  set(CMAKE_MACOSX_BUNDLE OFF)
endif()

# Xcode's own signing needs a signing team on iOS, and on macOS it breaks
# when the install rewrites the rpaths, so macOS kills the installed
# programs at launch. Without it the binaries keep the linker's signature,
# which the rewrite redoes. On macOS, a signing team or identity given asks
# for Xcode's signing.
if(APPLE)
  if(NOT DEFINED CMAKE_XCODE_ATTRIBUTE_CODE_SIGNING_ALLOWED AND
     NOT(CMAKE_SYSTEM_NAME STREQUAL "Darwin" AND
        (CMAKE_XCODE_ATTRIBUTE_DEVELOPMENT_TEAM OR
         CMAKE_XCODE_ATTRIBUTE_CODE_SIGN_IDENTITY)))
    set(CMAKE_XCODE_ATTRIBUTE_CODE_SIGNING_ALLOWED NO)
  endif()

  # Sources for other platforms compile to empty objects, which Xcode's
  # libtool warns about. The ar and ranlib of the other generators do not,
  # and take these flags as ar's.
  if(CMAKE_GENERATOR STREQUAL "Xcode")
    string(APPEND CMAKE_STATIC_LINKER_FLAGS " -no_warning_for_no_symbols")
  endif()
endif()

# A cross toolchain searches only under its sysroot, a given <X>_ROOT included.
# An explicit root is where the user's build of that library is, so search it.
if(CMAKE_CROSSCOMPILING)
  option(PJ_USE_ROOTS_IN_FIND
    "Search the given <X>_ROOT folders when the cross toolchain limits searches to its sysroot"
    ON
  )
  if(PJ_USE_ROOTS_IN_FIND)
    include(Pj/PackageRoot)
    pj_add_package_roots_to_find_root()
  endif()
endif()

# pj_add_subdirectory(): an option a subdirectory switches off, for a library
# not found or not usable, is then seen as off by the directories after it
# and by the package files below, also when pjproject is built inside
# another project
include(Pj/Option)

pj_warn_if_changed(CMAKE_PREFIX_PATH "${CMAKE_PREFIX_PATH}"
  "CMAKE_PREFIX_PATH")
pj_warn_if_changed(ENV_CMAKE_PREFIX_PATH "$ENV{CMAKE_PREFIX_PATH}"
  "The CMAKE_PREFIX_PATH environment variable")

# base library
pj_add_subdirectory(pjlib)

# third-party libraries
pj_add_subdirectory(third_party)

# remaning libraries
pj_add_subdirectory(pjlib-util)
pj_add_subdirectory(pjnath)
pj_add_subdirectory(pjmedia)
pj_add_subdirectory(pjsip)

# Always added: besides the applications, it holds the pjsua2 JNI bindings,
# which make builds in a step of their own regardless of the applications.
pj_add_subdirectory(pjsip-apps)

# The iOS sample applications are Xcode projects rather than CMake targets,
# and they link the static libraries from beside their own sources under the
# names the GNU makefiles produce. Mirror what pjsip-apps/build/Makefile does
# for $(PJSUA_EXE) on iOS, so the sample projects can be opened and built
# after a CMake build too. CMake's own library names differ from the GNU ones
# for a few targets, hence the mapping rather than a plain copy.
if(IOS)
  # On by default so the Xcode sample projects work straight after a build,
  # which is the whole point of them. It writes into the source tree, so it
  # turns itself off when that tree is not writable rather than failing an
  # otherwise valid out-of-source build.
  option(PJ_IOS_SAMPLE_LIBS
    "Link the built libraries into the iOS sample app projects" ON
  )

  # The projects link static archives and embed nothing, so an app linked
  # against shared libraries would build but not start.
  if(PJ_IOS_SAMPLE_LIBS AND BUILD_SHARED_LIBS)
    set(PJ_IOS_SAMPLE_LIBS OFF)
    message(STATUS
      "[!] the iOS sample projects need static libraries, so this shared "
      "build is not linked into them."
    )
  endif()

  if(PJ_IOS_SAMPLE_LIBS)
    execute_process(
      COMMAND "${CMAKE_COMMAND}" -E touch
              "${PROJECT_SOURCE_DIR}/pjsip-apps/src/.pj_write_probe"
      RESULT_VARIABLE _pj_src_writable
      ERROR_QUIET
    )
    if(_pj_src_writable EQUAL 0)
      file(REMOVE "${PROJECT_SOURCE_DIR}/pjsip-apps/src/.pj_write_probe")
    else()
      set(PJ_IOS_SAMPLE_LIBS OFF)
      message(STATUS
        "[!] the source tree is not writable, so the iOS sample projects will "
        "not be given the built libraries. The libraries themselves are "
        "unaffected."
      )
    endif()
    unset(_pj_src_writable)
  endif()
endif()

if(IOS AND PJ_IOS_SAMPLE_LIBS)
  set(_pj_ios_sample_dirs
    "${PROJECT_SOURCE_DIR}/pjsip-apps/src/pjsua/ios"
    "${PROJECT_SOURCE_DIR}/pjsip-apps/src/pjsua/ios-swift/Libraries"
    "${PROJECT_SOURCE_DIR}/pjsip-apps/src/pjsua2/ios-swift-pjsua2/Libraries"
  )

  # <cmake target>|<file name the Xcode projects link>
  set(_pj_ios_sample_libs
    pjlib|libpj.a
    pjlib-util|libpjlib-util.a
    pjnath|libpjnath.a
    pjmedia|libpjmedia.a
    pjmedia-codec|libpjmedia-codec.a
    pjmedia-audiodev|libpjmedia-audiodev.a
    pjmedia-videodev|libpjmedia-videodev.a
    pjsip|libpjsip.a
    pjsip-simple|libpjsip-simple.a
    pjsip-ua|libpjsip-ua.a
    pjsua-lib|libpjsua.a
    pjsua2|libpjsua2.a
    Pj::Dep::G7221|libg7221codec.a
    Pj::Dep::GSM|libgsmcodec.a
    Pj::Dep::iLBC|libilbccodec.a
    Pj::Dep::Resample|libresample.a
    Pj::Dep::Speex|libspeex.a
    Pj::Dep::SRTP|libsrtp.a
    Pj::Dep::WebRTC|libwebrtc.a
    Pj::Dep::YUV|libyuv.a
  )

  # The Xcode projects include the pjproject headers straight from the source
  # tree, where the autotools build also writes the five headers it generates.
  # CMake generates them under the build directory instead, so pj/config.h
  # fails on a missing pj/compat/os_auto.h. Copy rather than symlink: a later
  # ./aconfigure writes to these exact paths and would otherwise write through
  # the link into the build directory.
  #
  # The libraries search their build directory ahead of the source one, so
  # these copies do not affect a later build from this tree. A consumer that
  # includes from the source tree, as these projects do, gets whatever was
  # copied last. Turn this off to leave the source tree untouched.
  cmake_dependent_option(PJ_IOS_SAMPLE_HEADERS
    "Copy the generated headers into the source tree for the iOS samples" ON
    "PJ_IOS_SAMPLE_LIBS" OFF
  )

  set(_pj_ios_generated_headers
    pjlib/include/pj/compat/os_auto.h
    pjlib/include/pj/compat/m_auto.h
    pjmedia/include/pjmedia/config_auto.h
    pjmedia/include/pjmedia-codec/config_auto.h
    pjsip/include/pjsip/sip_autoconf.h
  )

  # The Xcode projects link a fixed list of archives, including ones this
  # configuration may not build -- any codec or WebRTC can be switched off.
  # The matching feature is compiled out of the headers too, so nothing
  # references those symbols and an empty archive satisfies the link. Without
  # it the projects fail with "library not found".
  set(_pj_ios_placeholder_src "${PROJECT_BINARY_DIR}/pj_ios_placeholder.c")
  file(WRITE "${_pj_ios_placeholder_src}"
    "/* Stands in for a library this configuration does not build.\n"
    " * Its feature is compiled out, so nothing refers to its symbols. */\n"
    "int pj_ios_placeholder(void);\n"
    "int pj_ios_placeholder(void) { return 0; }\n"
  )
  add_library(pj-ios-placeholder STATIC "${_pj_ios_placeholder_src}")

  add_custom_target(pj-ios-sample-libs ALL
    COMMENT "Linking libraries into the iOS sample app projects"
  )
  add_dependencies(pj-ios-sample-libs pj-ios-placeholder)

  if(PJ_IOS_SAMPLE_HEADERS)
    foreach(_pj_hdr IN LISTS _pj_ios_generated_headers)
      add_custom_command(TARGET pj-ios-sample-libs POST_BUILD
        COMMAND "${CMAKE_COMMAND}" -E copy_if_different
                "${PROJECT_BINARY_DIR}/${_pj_hdr}" "${PROJECT_SOURCE_DIR}/${_pj_hdr}"
      )
    endforeach()
  endif()
  foreach(_dir IN LISTS _pj_ios_sample_dirs)
    add_custom_command(TARGET pj-ios-sample-libs PRE_BUILD
      COMMAND "${CMAKE_COMMAND}" -E make_directory "${_dir}"
    )
  endforeach()

  get_property(_pj_used_deps GLOBAL PROPERTY PJ_USED_DEPS)
  foreach(_entry IN LISTS _pj_ios_sample_libs)
    string(REPLACE "|" ";" _parts "${_entry}")
    list(GET _parts 0 _pj_tgt)
    list(GET _parts 1 _pj_name)

    # The third-party entries are the provider-agnostic Pj::Dep:: aliases, so
    # a system provider is staged as readily as a bundled one. Only a library
    # this configuration genuinely does not have, or does not link and so does
    # not build, falls back to the placeholder, and it says so rather than
    # leaving the sample to fail with unresolved symbols later.
    string(REGEX REPLACE "^Pj::Dep::" "" _pj_dep "${_pj_tgt}")
    if(TARGET ${_pj_tgt} AND
       (_pj_dep STREQUAL _pj_tgt OR _pj_dep IN_LIST _pj_used_deps))
      if(NOT _pj_tgt MATCHES "^Pj::")
        add_dependencies(pj-ios-sample-libs ${_pj_tgt})
      endif()
      set(_pj_src "$<TARGET_FILE:${_pj_tgt}>")
    else()
      set(_pj_src "$<TARGET_FILE:pj-ios-placeholder>")
      message(STATUS
        "[!] ${_pj_name} is not built by this configuration; the iOS sample "
        "projects get an empty archive in its place"
      )
    endif()

    foreach(_dir IN LISTS _pj_ios_sample_dirs)
      add_custom_command(TARGET pj-ios-sample-libs POST_BUILD
        COMMAND "${CMAKE_COMMAND}" -E create_symlink
                "${_pj_src}" "${_dir}/${_pj_name}"
      )
    endforeach()
  endforeach()

  unset(_pj_ios_sample_dirs)
  unset(_pj_ios_sample_libs)
  unset(_pj_ios_generated_headers)
  unset(_pj_hdr)
  unset(_pj_src)
  unset(_pj_ios_placeholder_src)
  unset(_pj_tgt)
  unset(_pj_dep)
  unset(_pj_used_deps)
  unset(_pj_name)
  unset(_parts)
endif()

# ##############################################################################
# Output directories

# Every directory of the build, for the output directories and the
# Windows DLL path below
set(_pj_all_dirs "")
set(_pj_dirs "${PROJECT_SOURCE_DIR}")
while(_pj_dirs)
  list(POP_FRONT _pj_dirs _pj_dir)
  list(APPEND _pj_all_dirs "${_pj_dir}")
  get_property(_pj_subdirs DIRECTORY "${_pj_dir}" PROPERTY SUBDIRECTORIES)
  list(APPEND _pj_dirs ${_pj_subdirs})
endwhile()
unset(_pj_dirs)
unset(_pj_subdirs)

# Each module's programs in <build>/<module>/bin and its libraries (DLLs too)
# in <build>/<module>/lib, the layout make uses in the source tree. A
# multi-config generator (Visual Studio, Xcode) puts every configuration in the
# same folders, with the configuration in the file name (libpj-Debug.lib), as
# pjproject's own Visual Studio projects do. Left alone: targets given an
# output directory already, by a parent project's CMAKE_*_OUTPUT_DIRECTORY or
# in their own CMakeLists (SWIG modules, cmp_wav), and the SWIG modules, whose
# names their language loads them by. A pass over the targets rather than
# CMAKE_<KIND>_OUTPUT_DIRECTORY set per module: on Windows a DLL is a RUNTIME
# output like a program, so a variable cannot put programs in bin and DLLs in
# lib, where make puts them.
get_property(_pj_multi_config GLOBAL PROPERTY GENERATOR_IS_MULTI_CONFIG)
foreach(_pj_dir IN LISTS _pj_all_dirs)
  file(RELATIVE_PATH _pj_rel "${PROJECT_SOURCE_DIR}" "${_pj_dir}")
  if(_pj_rel STREQUAL "" OR _pj_rel MATCHES "^pjsip-apps/src/swig(/|$)")
    continue()
  endif()
  string(REGEX REPLACE "/.*" "" _pj_module "${_pj_rel}")
  set(_pj_bin "${PROJECT_BINARY_DIR}/${_pj_module}/bin")
  set(_pj_lib "${PROJECT_BINARY_DIR}/${_pj_module}/lib")

  get_property(_pj_targets DIRECTORY "${_pj_dir}" PROPERTY BUILDSYSTEM_TARGETS)
  foreach(_pj_tgt IN LISTS _pj_targets)
    get_target_property(_pj_type ${_pj_tgt} TYPE)
    if(NOT _pj_type MATCHES "^(EXECUTABLE|STATIC_LIBRARY|SHARED_LIBRARY|MODULE_LIBRARY)$")
      continue()
    endif()
    set(_pj_set FALSE)
    foreach(_pj_kind RUNTIME LIBRARY ARCHIVE)
      get_target_property(_pj_out ${_pj_tgt} ${_pj_kind}_OUTPUT_DIRECTORY)
      if(_pj_out)
        set(_pj_set TRUE)
      endif()
    endforeach()
    if(_pj_set)
      continue()
    endif()

    if(_pj_type STREQUAL "EXECUTABLE")
      get_target_property(_pj_sub ${_pj_tgt} PJ_OUTPUT_SUBDIR)
      if(_pj_sub)
        set(_pj_out "${_pj_bin}/${_pj_sub}")
      else()
        set(_pj_out "${_pj_bin}")
      endif()
    else()
      set(_pj_out "${_pj_lib}")
    endif()
    # A generator expression keeps a multi-config generator from adding a
    # per-configuration subdirectory
    if(_pj_multi_config)
      set(_pj_out "$<1:${_pj_out}>")
      foreach(_pj_cfg IN LISTS CMAKE_CONFIGURATION_TYPES)
        string(TOUPPER "${_pj_cfg}" _pj_cfg_upper)
        set_target_properties(${_pj_tgt} PROPERTIES
          ${_pj_cfg_upper}_POSTFIX "-${_pj_cfg}"
        )
      endforeach()
      set_target_properties(${_pj_tgt} PROPERTIES PJ_CONFIG_POSTFIX TRUE)
    endif()
    set_target_properties(${_pj_tgt} PROPERTIES
      RUNTIME_OUTPUT_DIRECTORY "${_pj_out}"
      LIBRARY_OUTPUT_DIRECTORY "${_pj_out}"
      ARCHIVE_OUTPUT_DIRECTORY "${_pj_out}"
    )
  endforeach()
endforeach()
unset(_pj_multi_config)
unset(_pj_dir)
unset(_pj_rel)
unset(_pj_module)
unset(_pj_bin)
unset(_pj_lib)
unset(_pj_targets)
unset(_pj_tgt)
unset(_pj_type)
unset(_pj_set)
unset(_pj_kind)
unset(_pj_out)
unset(_pj_sub)
unset(_pj_cfg)
unset(_pj_cfg_upper)

# A Windows program finds its DLLs only beside it or on PATH, and each
# module's DLLs are in its own lib folder: give the tests those folders
if(WIN32 OR CYGWIN)
  set(_pj_dll_path "")
  set(_pj_tests "")
  foreach(_pj_dir IN LISTS _pj_all_dirs)
    get_property(_pj_targets DIRECTORY "${_pj_dir}" PROPERTY BUILDSYSTEM_TARGETS)
    foreach(_pj_tgt IN LISTS _pj_targets)
      get_target_property(_pj_type ${_pj_tgt} TYPE)
      if(_pj_type STREQUAL "SHARED_LIBRARY")
        list(APPEND _pj_dll_path
          "PATH=path_list_prepend:$<TARGET_FILE_DIR:${_pj_tgt}>")
      endif()
    endforeach()
    get_property(_pj_dir_tests DIRECTORY "${_pj_dir}" PROPERTY TESTS)
    foreach(_pj_test IN LISTS _pj_dir_tests)
      list(APPEND _pj_tests "${_pj_dir}|${_pj_test}")
    endforeach()
  endforeach()
  if(_pj_dll_path)
    foreach(_pj_entry IN LISTS _pj_tests)
      string(REPLACE "|" ";" _pj_entry "${_pj_entry}")
      list(GET _pj_entry 0 _pj_dir)
      list(GET _pj_entry 1 _pj_test)
      set_property(TEST "${_pj_test}" DIRECTORY "${_pj_dir}"
        APPEND PROPERTY ENVIRONMENT_MODIFICATION ${_pj_dll_path}
      )
    endforeach()
  endif()
  unset(_pj_dll_path)
  unset(_pj_tests)
  unset(_pj_dir)
  unset(_pj_targets)
  unset(_pj_tgt)
  unset(_pj_type)
  unset(_pj_dir_tests)
  unset(_pj_test)
  unset(_pj_entry)
endif()
unset(_pj_all_dirs)

# ##############################################################################
# Installation

set(install_targets
  pjlib
  pjlib-ssl
  pjlib++
  pjlib-util
  pjnath
  pjmedia
  pjmedia-codec
  pjmedia-audiodev
  pjmedia-videodev
  pjsip
  pjsip-simple
  pjsip-ua
  pjsua-lib
)

# optional targets: pjsua2 needs PJ_BUILD_PJSUA2, pjsua PJ_BUILD_APPS
foreach(target pjsua2 pjsua)
  if(TARGET ${target})
    list(APPEND install_targets ${target})
  endif()
endforeach()

# The names find_package(Pj) gives, also for a project that builds pjproject
# itself with add_subdirectory() or FetchContent
foreach(target IN LISTS install_targets)
  get_target_property(_type ${target} TYPE)
  if(_type STREQUAL "EXECUTABLE")
    add_executable(Pj::${target} ALIAS ${target})
  else()
    add_library(Pj::${target} ALIAS ${target})
  endif()
endforeach()
unset(_type)

# set `VERSION` and `SO_VERSION`
foreach(target IN LISTS install_targets)
  set_target_properties(${target} PROPERTIES
    VERSION ${PROJECT_VERSION}
    SOVERSION ${PROJECT_VERSION_MAJOR}
  )
endforeach()

# lib<name> on MSVC too (libpj.lib, libpj.dll), as on every other platform
if(MSVC)
  foreach(target IN LISTS install_targets)
    get_target_property(_pj_type ${target} TYPE)
    if(_pj_type MATCHES "^(STATIC|SHARED)_LIBRARY$")
      set_target_properties(${target} PROPERTIES PREFIX lib IMPORT_PREFIX lib)
    endif()
  endforeach()
  unset(_pj_type)
endif()

# install targets
install(
  TARGETS ${install_targets}
  EXPORT PjTargets

  FILE_SET HEADERS
    DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}"
    COMPONENT PjDevelopment
  FILE_SET config_headers
    DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}"
    COMPONENT PjDevelopment
  RUNTIME
    DESTINATION "${CMAKE_INSTALL_BINDIR}"
    COMPONENT PjRuntime
  LIBRARY
    DESTINATION "${CMAKE_INSTALL_LIBDIR}"
    COMPONENT PjRuntime
    NAMELINK_COMPONENT PjDevelopment
  ARCHIVE
    DESTINATION "${CMAKE_INSTALL_LIBDIR}"
    COMPONENT PjDevelopment
)

# ##############################################################################
# CMAKe Package config

include(CMakePackageConfigHelpers)

set(PJ_CMAKE_INSTALL_DIR         "${CMAKE_INSTALL_LIBDIR}/cmake/Pj")
set(PJ_CMAKE_TARGETS_FILE        "PjTargets.cmake")
set(PJ_CMAKE_CONFIG_FILE         "PjConfig.cmake")
set(PJ_CMAKE_CONFIG_VERSION_FILE "PjConfigVersion.cmake")

# Whether the bundled srtp links OpenSSL, set by it only. Once a cache entry,
# which outlived a switch to the system srtp. Only when pjmedia links srtp at
# all: with PJMEDIA_WITH_SRTP off it is neither linked nor installed.
unset(PJ_SRTP_WITH_OPENSSL CACHE)
get_property(PJ_SRTP_WITH_OPENSSL GLOBAL PROPERTY PJ_SRTP_WITH_OPENSSL)
get_property(_pj_used_deps GLOBAL PROPERTY PJ_USED_DEPS)
if(NOT "SRTP" IN_LIST _pj_used_deps)
  set(PJ_SRTP_WITH_OPENSSL OFF)
endif()
unset(_pj_used_deps)

# install exports
install(
  EXPORT      PjTargets
  NAMESPACE   Pj::
  FILE        "${PJ_CMAKE_TARGETS_FILE}"
  DESTINATION "${PJ_CMAKE_INSTALL_DIR}"
  COMPONENT   PjDevelopment
)

# APPLE is empty rather than 0 off Apple platforms, and PjConfig.cmake.in
# substitutes it into an if() condition, where an empty operand beside AND is
# a hard error.
if(APPLE)
  set(PJ_APPLE 1)
else()
  set(PJ_APPLE 0)
endif()

# The FFmpeg components pjmedia links, for PjConfig.cmake.in to require
set(PJ_FFMPEG_COMPONENTS)
foreach(_lib avutil swscale avcodec avformat avdevice)
  string(TOUPPER "${_lib}" _lib_upper)
  if(PJMEDIA_WITH_FFMPEG_${_lib_upper})
    list(APPEND PJ_FFMPEG_COMPONENTS ${_lib})
  endif()
endforeach()

# write package config
configure_package_config_file(
  "${CMAKE_CURRENT_SOURCE_DIR}/cmake/Pj/${PJ_CMAKE_CONFIG_FILE}.in"
  "${CMAKE_CURRENT_BINARY_DIR}/${PJ_CMAKE_CONFIG_FILE}"

  INSTALL_DESTINATION "${PJ_CMAKE_INSTALL_DIR}"
)

# write package config version
write_basic_package_version_file(
  "${PJ_CMAKE_CONFIG_VERSION_FILE}"

  COMPATIBILITY SameMajorVersion
)

# collect third-party dependency provider info for PjDeps.cmake
set(PJ_BUNDLED_DEPS "")
set(PJ_SYSTEM_DEPS "")

set(_pj_all_deps G7221 GSM iLBC Resample Speex SRTP YUV WebRTC WebRTC_AEC3)

# Go by the target rather than the PJ_DEP_<X> cache entry, which outlives a
# dependency that a later configure (PJ_WITH_CXX=OFF, provider none) left out,
# and only for what pjmedia links: a bundled library it does not is not built.
get_property(_pj_used_deps GLOBAL PROPERTY PJ_USED_DEPS)
foreach(_dep IN LISTS _pj_all_deps)
  if(TARGET Pj::Dep::${_dep} AND _dep IN_LIST _pj_used_deps)
    get_target_property(_dep_provider Pj::Dep::${_dep} PJ_DEP_PROVIDER)
    if(_dep_provider STREQUAL "bundled")
      list(APPEND PJ_BUNDLED_DEPS "${_dep}")
      get_target_property(_dep_target Pj::Dep::${_dep} ALIASED_TARGET)
      pj_install_bundled_dep(${_dep_target})
    elseif(_dep_provider STREQUAL "system")
      list(APPEND PJ_SYSTEM_DEPS "${_dep}")
    endif()
  endif()
endforeach()
unset(_dep_provider)
unset(_dep_target)
unset(_pj_used_deps)
unset(_pj_all_deps)

list(JOIN PJ_BUNDLED_DEPS ";" PJ_BUNDLED_DEPS_STR)
list(JOIN PJ_SYSTEM_DEPS ";" PJ_SYSTEM_DEPS_STR)

configure_file(
  "${CMAKE_CURRENT_SOURCE_DIR}/cmake/Pj/PjDeps.cmake.in"
  "${CMAKE_CURRENT_BINARY_DIR}/PjDeps.cmake"
  @ONLY
)

# Install custom Find modules needed by enabled dependencies.
# CMake built-in modules (Threads, OpenSSL, GnuTLS, ALSA, OpenGL, SDL2)
# do not need to be installed.
set(_pj_find_modules)

# Helper: append a Find module if the feature is enabled and the file exists
macro(_pj_collect_find_module _condition _package)
  if(${_condition})
    set(_fm "${CMAKE_CURRENT_SOURCE_DIR}/cmake/Find${_package}.cmake")
    if(EXISTS "${_fm}")
      list(APPEND _pj_find_modules "${_fm}")
    endif()
    unset(_fm)
  endif()
endmacro()

# System third-party deps (bundled deps use Pj::Dep:: aliases instead)
set(_pj_pkg_G7221    "G7221")
set(_pj_pkg_GSM      "GSM")
set(_pj_pkg_Resample "Resample")
set(_pj_pkg_Speex    "Speex")
set(_pj_pkg_SRTP     "SRTP")
set(_pj_pkg_YUV      "YUV")
set(_pj_pkg_WebRTC   "WebRTC")
set(_pj_pkg_WebRTC_AEC3 "WebRTC_AEC3")
foreach(_dep IN LISTS PJ_SYSTEM_DEPS)
  if(DEFINED _pj_pkg_${_dep})
    _pj_collect_find_module(TRUE ${_pj_pkg_${_dep}})
  endif()
endforeach()

# Platform libs and optional features with custom Find modules
_pj_collect_find_module(PJLIB_WITH_LIBUUID               UUID)
_pj_collect_find_module(PJNATH_WITH_UPNP                 UPNP)
_pj_collect_find_module(PJMEDIA_WITH_AUDIODEV_COREAUDIO   CoreAudio)
_pj_collect_find_module(PJMEDIA_WITH_AUDIODEV_OBOE        Oboe)
_pj_collect_find_module(PJMEDIA_WITH_AUDIODEV_WASAPI      WASAPI)
_pj_collect_find_module(PJMEDIA_WITH_AUDIODEV_PORTAUDIO   PortAudio)
_pj_collect_find_module(PJMEDIA_WITH_VIDEODEV_V4L2        V4L2)
# PJ_OPENGL_PACKAGE is the name PjConfig.cmake.in calls find_dependency with,
# so keying off it keeps the two from drifting apart. Only the OpenGLES module
# is ours; FindOpenGL is a built-in and needs no installing.
if(PJ_OPENGL_PACKAGE STREQUAL "OpenGLES")
  _pj_collect_find_module(PJMEDIA_WITH_VIDEODEV_OPENGL    OpenGLES)
endif()
_pj_collect_find_module(PJMEDIA_WITH_VIDEODEV_DARWIN      AVFoundation)
_pj_collect_find_module(PJMEDIA_WITH_VIDEODEV_METAL       Metal)
_pj_collect_find_module(PJMEDIA_WITH_VID_TOOLBOX_CODEC    VideoToolbox)
_pj_collect_find_module(APPLE                             AppleFoundation)
_pj_collect_find_module(PJMEDIA_WITH_ILBC_CODEC           AudioToolbox)
if(PJMEDIA_WITH_RESAMPLE STREQUAL "libsamplerate")
  _pj_collect_find_module(TRUE SampleRate)
endif()
_pj_collect_find_module(PJMEDIA_NEEDS_SPEEXDSP            SpeexDSP)
_pj_collect_find_module(PJMEDIA_WITH_FFMPEG               FFMPEG)
_pj_collect_find_module(PJMEDIA_WITH_OPENCORE_AMRNB_CODEC OpenCoreAMRNB)
_pj_collect_find_module(PJMEDIA_WITH_OPENCORE_AMRWB_CODEC OpenCoreAMRWB)
_pj_collect_find_module(PJMEDIA_WITH_OPENCORE_AMRWB_CODEC VisualOnAMRWBEnc)
_pj_collect_find_module(PJMEDIA_WITH_SILK_CODEC           Silk)
_pj_collect_find_module(PJMEDIA_WITH_OPUS_CODEC           OPUS)
_pj_collect_find_module(PJMEDIA_WITH_BCG729_CODEC         BCG729)
_pj_collect_find_module(PJMEDIA_WITH_INTEL_IPP            IPP)
_pj_collect_find_module(PJMEDIA_WITH_LYRA_CODEC           Lyra)
_pj_collect_find_module(PJMEDIA_WITH_VPX_CODEC            VPX)
_pj_collect_find_module(PJMEDIA_WITH_OPEN_H264_CODEC      OpenH264)
_pj_collect_find_module(PJMEDIA_WITH_ANDROID_MEDIACODEC_CODEC MediaNDK)

if(_pj_find_modules)
  list(REMOVE_DUPLICATES _pj_find_modules)
  install(FILES ${_pj_find_modules}
    DESTINATION "${PJ_CMAKE_INSTALL_DIR}"
    COMPONENT PjDevelopment
  )
  # Helpers the Find modules include as Pj/<name>
  install(FILES
    "${CMAKE_CURRENT_SOURCE_DIR}/cmake/Pj/CheckLibraryUsable.cmake"
    "${CMAKE_CURRENT_SOURCE_DIR}/cmake/Pj/DebugLibrary.cmake"
    "${CMAKE_CURRENT_SOURCE_DIR}/cmake/Pj/GetMacroValue.cmake"
    DESTINATION "${PJ_CMAKE_INSTALL_DIR}/Pj"
    COMPONENT PjDevelopment
  )
endif()
# PjConfig.cmake includes it whatever is found
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/cmake/Pj/PackageRoot.cmake"
  DESTINATION "${PJ_CMAKE_INSTALL_DIR}/Pj"
  COMPONENT PjDevelopment
)

# What each dependency PjConfig.cmake looks up was found as here: the
# <Pkg>_LIBRARY, <Pkg>_INCLUDE_DIR, <Pkg>_DIR, ... cache entries. PjConfig.cmake
# hands them to the consumer's search, which would otherwise start afresh and
# could settle on another copy, e.g. the shared library beside the static one
# given with -D<Pkg>_LIBRARY.
set(_pj_found_pkgs)
foreach(_fm IN LISTS _pj_find_modules)
  cmake_path(GET _fm STEM _pkg)
  string(REGEX REPLACE "^Find" "" _pkg "${_pkg}")
  list(APPEND _pj_found_pkgs ${_pkg})
endforeach()
# and the ones CMake's own modules find
# OpenSSL: also for a static system libsrtp built with it
set(_pj_srtp_links "")
get_property(_pj_used_deps GLOBAL PROPERTY PJ_USED_DEPS)
if(TARGET SRTP::SRTP AND "SRTP" IN_LIST _pj_used_deps)
  get_target_property(_pj_srtp_links SRTP::SRTP INTERFACE_LINK_LIBRARIES)
endif()
unset(_pj_used_deps)
if(PJ_SSL_BACKEND STREQUAL "openssl" OR PJ_SRTP_WITH_OPENSSL
   OR _pj_srtp_links MATCHES "OpenSSL::")
  # with LIB_EAY* and SSL_EAY* on Windows, see pj_package_owns_var()
  list(APPEND _pj_found_pkgs OpenSSL)
endif()
unset(_pj_srtp_links)
if(PJ_SSL_BACKEND STREQUAL "gnutls")
  list(APPEND _pj_found_pkgs GnuTLS)
elseif(PJ_SSL_BACKEND STREQUAL "mbedtls")
  list(APPEND _pj_found_pkgs MbedTLS)
endif()
if(PJMEDIA_WITH_AUDIODEV_ALSA)
  list(APPEND _pj_found_pkgs ALSA)
endif()
if(PJMEDIA_WITH_VIDEODEV_OPENGL AND PJ_OPENGL_PACKAGE STREQUAL "OpenGL")
  list(APPEND _pj_found_pkgs OpenGL)
endif()
if(PJMEDIA_WITH_VIDEODEV_SDL)
  list(APPEND _pj_found_pkgs SDL2)
endif()

include(Pj/PackageRoot)

# CMake leaves the folders of dependencies out of the installed libraries'
# RPATH, so a dependency taken from a root is not found there unless asked
if(BUILD_SHARED_LIBS AND UNIX AND NOT CMAKE_CROSSCOMPILING
   AND NOT DEFINED CMAKE_INSTALL_RPATH_USE_LINK_PATH)
  set(_pj_rooted "")
  foreach(_pkg IN LISTS _pj_found_pkgs)
    pj_package_root_given(${_pkg} _root)
    if(_root)
      list(APPEND _pj_rooted ${_pkg})
    endif()
  endforeach()
  if(CMAKE_PREFIX_PATH)
    list(APPEND _pj_rooted "CMAKE_PREFIX_PATH")
  endif()
  if(_pj_rooted)
    list(JOIN _pj_rooted ", " _pj_rooted)
    message(STATUS "[!] The installed shared libraries will not find the "
      "dependencies from a root (${_pj_rooted}); "
      "set CMAKE_INSTALL_RPATH_USE_LINK_PATH=ON to record their folders")
  endif()
  unset(_pj_rooted)
  unset(_root)
endif()

set(_pj_found_paths "")
get_cmake_property(_pj_cache_vars CACHE_VARIABLES)
foreach(_var IN LISTS _pj_cache_vars)
  get_property(_type CACHE ${_var} PROPERTY TYPE)
  get_property(_value CACHE ${_var} PROPERTY VALUE)
  if(NOT _type MATCHES "^(FILEPATH|PATH)$" OR _value STREQUAL ""
     OR _value MATCHES "-NOTFOUND$")
    continue()
  endif()
  # Not what the toolchain provides (Apple SDK frameworks, the NDK or a cross
  # sysroot): there is one of each, and the consumer may build with another SDK
  set(_in_sysroot FALSE)
  if(CMAKE_SYSROOT)
    cmake_path(IS_PREFIX CMAKE_SYSROOT "${_value}" NORMALIZE _in_sysroot)
  endif()
  if(_in_sysroot OR _value MATCHES "/System/Library/Frameworks/")
    continue()
  endif()
  # FindFFMPEG finds more components than pjmedia links
  if(_var MATCHES "^FFMPEG_([A-Za-z0-9]+)_"
     AND NOT CMAKE_MATCH_1 IN_LIST PJ_FFMPEG_COMPONENTS)
    continue()
  endif()
  # Find modules name their entries in either case: OPUS_LIBRARY, UUID_...
  foreach(_pkg IN LISTS _pj_found_pkgs)
    pj_package_owns_var(${_pkg} ${_var} _owns)
    if(_owns)
      # A bracket the value cannot close
      set(_eq "=")
      string(FIND "${_value}]" "]${_eq}]" _pos)
      while(NOT _pos EQUAL -1)
        string(APPEND _eq "=")
        string(FIND "${_value}]" "]${_eq}]" _pos)
      endwhile()
      string(APPEND _pj_found_paths
        "_pj_use_found(${_pkg} ${_var} [${_eq}[${_value}]${_eq}])\n"
      )
      break()
    endif()
  endforeach()
endforeach()
# Written as it is (a substitution pass could alter a path with "@" in it),
# and only when changed
set(_pj_found_paths
  "# Generated by the pjproject build; see PjConfig.cmake\n${_pj_found_paths}")
set(_pj_found_paths_file "${CMAKE_CURRENT_BINARY_DIR}/PjFoundPaths.cmake")
set(_previous "")
if(EXISTS "${_pj_found_paths_file}")
  file(READ "${_pj_found_paths_file}" _previous)
endif()
if(NOT _pj_found_paths STREQUAL _previous)
  file(WRITE "${_pj_found_paths_file}" "${_pj_found_paths}")
endif()
unset(_previous)
unset(_pj_found_paths_file)
unset(_pj_found_paths)
unset(_pj_found_pkgs)
unset(_pj_cache_vars)
unset(_owns)
unset(_in_sysroot)
unset(_type)
unset(_value)
unset(_pkg)
unset(_eq)
unset(_pos)

install(FILES
  "${CMAKE_CURRENT_BINARY_DIR}/${PJ_CMAKE_CONFIG_FILE}"
  "${CMAKE_CURRENT_BINARY_DIR}/${PJ_CMAKE_CONFIG_VERSION_FILE}"
  "${CMAKE_CURRENT_BINARY_DIR}/PjDeps.cmake"
  "${CMAKE_CURRENT_BINARY_DIR}/PjFoundPaths.cmake"

  DESTINATION "${PJ_CMAKE_INSTALL_DIR}"
  COMPONENT PjDevelopment
)

# ##############################################################################
# pkg-config file

# The libraries in link order; pjsua2 needs PJ_BUILD_PJSUA2
set(_pj_pc_libs
  pjsua-lib pjsip-ua pjsip-simple pjsip
  pjmedia-codec pjmedia-videodev pjmedia-audiodev pjmedia
  pjnath pjlib-util pjlib
)
if(TARGET pjsua2)
  list(PREPEND _pj_pc_libs pjsua2)
endif()
pj_generate_pkgconfig(
  "${CMAKE_CURRENT_SOURCE_DIR}/libpjproject.pc.in"
  "${CMAKE_INSTALL_LIBDIR}/pkgconfig"
  ${_pj_pc_libs}
)

# ##############################################################################
# Convenience targets, as make's. Only in a build of pjproject itself: inside
# another project (add_subdirectory(), FetchContent) these global names could
# clash with the parent's own, and its install manifest is the parent's.
if(pjproject_IS_TOP_LEVEL)
  # lib: the libraries only, without the applications and tests
  add_custom_target(lib DEPENDS ${_pj_pc_libs})

  # uninstall: remove what `cmake --install` installed
  add_custom_target(uninstall
    COMMAND "${CMAKE_COMMAND}"
      "-DPJ_INSTALL_MANIFEST=${CMAKE_CURRENT_BINARY_DIR}/install_manifest.txt"
      -P "${CMAKE_CURRENT_SOURCE_DIR}/cmake/Pj/Uninstall.cmake"
    VERBATIM
  )
endif()
unset(_pj_pc_libs)

# A <Pkg>_ROOT is searched first, not only: point out what came from elsewhere
include(Pj/PackageRoot)
pj_warn_outside_package_roots()
# and when cross-compiling, a root outside the find root is not searched at all
pj_warn_rerooted_package_roots()
